import {all} from 'redux-saga/effects';
import authSaga from './Auth/redux/saga';
import citySaga from './Cities/redux/saga';
export default function* rootSaga() {
  yield all([authSaga(), citySaga()]);
}
