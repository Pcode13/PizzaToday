import {createSelector} from 'reselect';
const getState = state => state;
export const isLoading = () =>
  createSelector([getState], store => {
    let loading = false;
    Object.keys(store).forEach(element => {
      if (element.isFetching) {
        return element.isFetching;
      }
    });
    return loading;
  });
