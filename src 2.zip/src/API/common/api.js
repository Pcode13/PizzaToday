import axios from 'axios';
import {getHeaders} from './utils/headers';

export const apiCall = async (
  requestType,
  endPoint,
  params,
  headers = getHeaders(),
) => {
  let response = {};
  switch (requestType) {
    case 'GET':
      response = await getApiCall(endPoint, headers, params);
      break;
    case 'POST':
      response = await postApiCall(endPoint, headers, params);
      break;
    case 'DELETE':
      response = await deleteApiCall(endPoint, headers, params);
      break;
    case 'PUT':
      response = await putApiCall(endPoint, headers, params);
      break;
    default:
      response = await getApiCall(endPoint, headers, params);
  }
  return response;
};

async function getApiCall(endPoint, headers, params) {
  try {
    return await axios({
      method: 'get',
      url: endPoint,
      data: params,
      headers: headers,
    });
  } catch (e) {
    throw e?.response?.data;
  }
}

async function postApiCall(endPoint, headers, params) {
  try {
    return await axios({
      method: 'post',
      url: endPoint,
      data: params,
      headers: headers,
    });
  } catch (e) {
    throw e?.response?.data;
  }
}

async function deleteApiCall(endPoint, headers, params) {
  try {
    return await axios({
      method: 'delete',
      url: endPoint,
      data: params,
      headers: headers,
    });
  } catch (e) {
    throw e?.response?.data;
  }
}

async function putApiCall(endPoint, headers, params) {
  try {
    return await axios({
      method: 'put',
      url: endPoint,
      data: params,
      headers: headers,
    });
  } catch (e) {
    throw e?.response?.data;
  }
}
