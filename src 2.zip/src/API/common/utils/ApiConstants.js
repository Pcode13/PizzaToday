export const API_PARAMS = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  DELETE: 'DELETE',
};

export const MAIN_URL = 'https://v2.pizzatoday.in/';

// Auth end points
export const REGISTER_URL = 'api/register';
export const SEND_OTP_URL = 'api/send-otp';
export const VERIFY_OTP_URL = 'api/verify-otp';
export const LOGIN_URL = 'api/login';

export const GET_CITIES_URL = 'api/cities';
export const GET_AREAS_URL = 'api/city';
export const GET_DEAL_OFFER_HOME_URL = 'api/get/deals-and-offers';
