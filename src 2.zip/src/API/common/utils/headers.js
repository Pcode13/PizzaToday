export const getHeaders = () => {
  return {
    'Content-Type': 'application/json',
  };
};
