import {apiCall} from '../../common/api';
import {
  API_PARAMS,
  GET_AREAS_URL,
  GET_CITIES_URL,
  GET_DEAL_OFFER_HOME_URL,
  MAIN_URL,
} from '../../common/utils/ApiConstants';

export function getCitiesApi() {
  let apiEndPoint = `${MAIN_URL}${GET_CITIES_URL}`;
  return apiCall(API_PARAMS.GET, apiEndPoint);
}

export function getAreasApi(requestParams) {
  let apiEndPoint = `${MAIN_URL}${GET_AREAS_URL}/${requestParams}/area`;
  return apiCall(API_PARAMS.GET, apiEndPoint);
}

export function getDealAndOffersHomeApi() {
  let apiEndPoint = `${MAIN_URL}${GET_DEAL_OFFER_HOME_URL}`;
  return apiCall(API_PARAMS.GET, apiEndPoint);
}
