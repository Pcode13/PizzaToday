import {
  createSignalAction,
  createDeltaAction,
  createActionCreator,
} from '../../common/actions';

export const GET_CITIES_API = createSignalAction('GET_CITIES_API');
export const GET_CITIES = createDeltaAction('GET_CITIES');
export const getCities = createActionCreator(GET_CITIES);

export const GET_AREAS_API = createSignalAction('GET_AREAS_API');
export const GET_AREAS = createDeltaAction('GET_AREAS');
export const getAreas = createActionCreator(GET_AREAS);

export const GET_DEAL_OFFER_HOME_API = createSignalAction(
  'GET_DEAL_OFFER_HOME_API',
);
export const GET_DEAL_OFFER_HOME = createDeltaAction('GET_DEAL_OFFER_HOME');
export const getDealAndOffersHome = createActionCreator(GET_DEAL_OFFER_HOME);
