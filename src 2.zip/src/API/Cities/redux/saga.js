import {call, put, takeEvery, takeLatest} from 'redux-saga/effects';
import * as actions from './actions';
import * as api from '../api/api';

export function* getCitiesSaga(mainParams) {
  try {
    yield put(actions.GET_CITIES_API.request());
    const mainResponse = yield call(api.getCitiesApi);
    yield put(actions.GET_CITIES_API.success(mainResponse?.data));
    mainParams?.data?.onSuccess(mainResponse?.data);
    return mainResponse;
  } catch (err) {
    yield put(actions.GET_CITIES_API.failure(err));
    mainParams?.data?.onFailure(err);
  }
}

export function* getAreasSaga(mainParams) {
  try {
    yield put(actions.GET_AREAS_API.request());
    const mainResponse = yield call(
      api.getAreasApi,
      mainParams?.data?.params?.cityId,
    );
    yield put(actions.GET_AREAS_API.success(mainResponse?.data));
    mainParams?.data?.onSuccess(mainResponse?.data);
    return mainResponse;
  } catch (err) {
    yield put(actions.GET_AREAS_API.failure(err));
    mainParams?.data?.onFailure(err);
  }
}

export function* getDealAndOffersHomeReducerSaga(mainParams) {
  try {
    yield put(actions.GET_DEAL_OFFER_HOME_API.request());
    const mainResponse = yield call(api.getDealAndOffersHomeApi);
    yield put(actions.GET_DEAL_OFFER_HOME_API.success(mainResponse?.data));
    mainParams?.data?.onSuccess(mainResponse?.data);
    return mainResponse;
  } catch (err) {
    yield put(actions.GET_DEAL_OFFER_HOME_API.failure(err));
    mainParams?.data?.onFailure(err);
  }
}

export default function* watchers() {
  yield takeLatest(actions.GET_CITIES, getCitiesSaga);
  yield takeEvery(actions.GET_AREAS, getAreasSaga);
  yield takeEvery(actions.GET_DEAL_OFFER_HOME, getDealAndOffersHomeReducerSaga);
}
