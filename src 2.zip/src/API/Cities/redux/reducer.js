import {createReducer} from '../../common/genericReducer';
import {GET_AREAS, GET_CITIES, GET_DEAL_OFFER_HOME} from './const';
import * as apiActions from './actions';

const getCitiesReducer = createReducer(apiActions.GET_CITIES_API);
const getAreasReducer = createReducer(apiActions.GET_AREAS_API);
const getDealAndOffersHomeReducer = createReducer(
  apiActions.GET_DEAL_OFFER_HOME_API,
);

export default {
  [GET_CITIES]: getCitiesReducer,
  [GET_AREAS]: getAreasReducer,
  [GET_DEAL_OFFER_HOME]: getDealAndOffersHomeReducer,
};
