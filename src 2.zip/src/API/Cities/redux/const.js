export const GET_CITIES = 'getCities';
export const GET_AREAS = 'getAreas';
export const GET_DEAL_OFFER_HOME = 'getDealAndOffersHome';
