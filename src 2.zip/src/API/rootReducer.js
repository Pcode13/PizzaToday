import {combineReducers} from 'redux';
import authReducer from './Auth/redux/reducers';
import citiesReducer from './Cities/redux/reducer';

export default combineReducers({
  ...authReducer,
  ...citiesReducer,
});
