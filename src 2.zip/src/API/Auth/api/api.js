import {apiCall} from '../../common/api';
import {
  API_PARAMS,
  LOGIN_URL,
  MAIN_URL,
  REGISTER_URL,
  SEND_OTP_URL,
  VERIFY_OTP_URL,
} from '../../common/utils/ApiConstants';

export function registerApi(requestParams) {
  let apiEndPoint = `${MAIN_URL}${REGISTER_URL}`;
  return apiCall(API_PARAMS.POST, apiEndPoint, requestParams);
}

export function sendOtpApi(requestParams) {
  let apiEndPoint = `${MAIN_URL}${SEND_OTP_URL}`;
  return apiCall(API_PARAMS.POST, apiEndPoint, requestParams);
}

export function verifyOtpApi(requestParams) {
  let apiEndPoint = `${MAIN_URL}${VERIFY_OTP_URL}`;
  return apiCall(API_PARAMS.POST, apiEndPoint, requestParams);
}

export function loginApi(requestParams) {
  let apiEndPoint = `${MAIN_URL}${LOGIN_URL}`;
  return apiCall(API_PARAMS.POST, apiEndPoint, requestParams);
}
