import {
  createSignalAction,
  createDeltaAction,
  createActionCreator,
} from '../../common/actions';

export const REGISTER_API = createSignalAction('REGISTER_API');
export const REGISTER = createDeltaAction('REGISTER');
export const register = createActionCreator(REGISTER);

export const SEND_OTP_API = createSignalAction('SEND_OTP_API');
export const SEND_OTP = createDeltaAction('SEND_OTP');
export const sendOtp = createActionCreator(SEND_OTP);

export const VERIFY_OTP_API = createSignalAction('VERIFY_OTP_API');
export const VERIFY_OTP = createDeltaAction('VERIFY_OTP');
export const verifyOtp = createActionCreator(VERIFY_OTP);

export const LOGIN_API = createSignalAction('LOGIN_API');
export const LOGIN = createDeltaAction('LOGIN');
export const login = createActionCreator(LOGIN);
