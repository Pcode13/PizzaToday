import {createReducer} from '../../common/genericReducer';
import {LOGIN, REGISTER, SEND_OTP, VERIFY_OTP} from './const';
import * as apiActions from './actions';

const registerReducer = createReducer(apiActions.REGISTER_API);
const sendOtpReducer = createReducer(apiActions.SEND_OTP_API);
const verifyOtpReducer = createReducer(apiActions.VERIFY_OTP_API);
const loginReducer = createReducer(apiActions.LOGIN_API);

export default {
  [REGISTER]: registerReducer,
  [SEND_OTP]: sendOtpReducer,
  [VERIFY_OTP]: verifyOtpReducer,
  [LOGIN]: loginReducer,
};
