export const REGISTER = 'register';
export const SEND_OTP = 'sendOtp';
export const VERIFY_OTP = 'verifyOtp';
export const LOGIN = 'login';
