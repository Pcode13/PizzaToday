import {call, put, takeEvery, takeLatest} from 'redux-saga/effects';
import * as actions from './actions';
import * as api from '../api/api';

export function* registerSaga(mainParams) {
  try {
    yield put(actions.REGISTER_API.request());
    const mainResponse = yield call(api.registerApi, mainParams?.data?.params);
    yield put(actions.REGISTER_API.success(mainResponse?.data));
    mainParams?.data?.onSuccess(mainResponse?.data);
    return mainResponse;
  } catch (err) {
    yield put(actions.REGISTER_API.failure(err));
    mainParams?.data?.onFailure(err);
  }
}

export function* sendOtpSaga(mainParams) {
  try {
    yield put(actions.SEND_OTP_API.request());
    const mainResponse = yield call(api.sendOtpApi, mainParams?.data?.params);
    yield put(actions.SEND_OTP_API.success(mainResponse?.data));
    mainParams?.data?.onSuccess(mainResponse?.data);
    return mainResponse;
  } catch (err) {
    yield put(actions.SEND_OTP_API.failure(err));
    mainParams?.data?.onFailure(err);
  }
}

export function* verifyOtpSaga(mainParams) {
  try {
    yield put(actions.VERIFY_OTP_API.request());
    const mainResponse = yield call(api.verifyOtpApi, mainParams?.data?.params);
    yield put(actions.VERIFY_OTP_API.success(mainResponse?.data));
    mainParams?.data?.onSuccess(mainResponse?.data);
    return mainResponse;
  } catch (err) {
    yield put(actions.VERIFY_OTP_API.failure(err));
    mainParams?.data?.onFailure(err);
  }
}

export function* loginSaga(mainParams) {
  try {
    yield put(actions.LOGIN_API.request());
    const mainResponse = yield call(api.loginApi, mainParams?.data?.params);
    yield put(actions.LOGIN_API.success(mainResponse?.data));
    mainParams?.data?.onSuccess(mainResponse?.data);
    return mainResponse;
  } catch (err) {
    yield put(actions.LOGIN_API.failure(err));
    mainParams?.data?.onFailure(err);
  }
}

export default function* watchers() {
  yield takeLatest(actions.REGISTER, registerSaga);
  yield takeLatest(actions.SEND_OTP, sendOtpSaga);
  yield takeLatest(actions.VERIFY_OTP, verifyOtpSaga);
  yield takeLatest(actions.LOGIN, loginSaga);
}
