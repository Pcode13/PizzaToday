import {connect} from 'react-redux';
import {compose} from 'recompose';
import {bindActionCreators} from 'redux';
import {createStructuredSelector} from 'reselect';

import * as cityActions from '../../API/Cities/redux/actions';

export const mapStateToProps = createStructuredSelector({});

function mapDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      getCities: cityActions.getCities,
      getAreas: cityActions.getAreas,
      getDealAndOffersHome: cityActions.getDealAndOffersHome,
    },
    dispatch,
  );
}

const container = compose(connect(mapStateToProps, mapDispatchToProps));
export default container;
