import {connect} from 'react-redux';
import {compose} from 'recompose';
import {bindActionCreators} from 'redux';
import {createStructuredSelector} from 'reselect';

import * as authActions from '../../API/Auth/redux/actions';
import {isLoading} from '../../API/common/selector';

export const mapStateToProps = createStructuredSelector({
  isLoading: isLoading(),
});

function mapDispatchToProps(dispatch) {
  return bindActionCreators(
    {
      register: authActions.register,
      sendOtp: authActions.sendOtp,
      verifyOtp: authActions.verifyOtp,
      login: authActions.login,
    },
    dispatch,
  );
}

const container = compose(connect(mapStateToProps, mapDispatchToProps));
export default container;
