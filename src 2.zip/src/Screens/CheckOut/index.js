import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useRef, useState} from 'react';
import {
  APP_BACK_IMAGE,
  COD,
  GPAY,
  GREEN_CHECK,
  MASTERCARD,
  PAYTM,
  PHONEPE,
  RAZOR_PAY,
  SALE,
} from '../../common/Assets/Constants';
import SubmitButton from '../../common/Components/SubmitButton';
import Header from '../../common/Components/Header';
import DropShadow from 'react-native-drop-shadow';
import AddressCard from '../../common/Components/AddressCard';
import address from '../ChangeAddress/addresses.json';
import OfferPopUp from '../../common/Components/OfferPopUp';
const CheckOut = ({navigation}) => {
  const paymentMethods = [
    {
      id: '1',
      paymantName: 'COD',
      logo: COD,
    },
    {
      id: '2',
      paymantName: 'Razor Pay',
      logo: RAZOR_PAY,
    },
    {
      id: '3',
      paymantName: 'Paytm',
      logo: PAYTM,
    },
    {
      id: '4',
      paymantName: 'Google Pay',
      logo: GPAY,
    },
    {
      id: '5',
      paymantName: 'PhonePe',
      logo: PHONEPE,
    },
    {
      id: '6',
      paymantName: 'Master Card',
      logo: MASTERCARD,
    },
  ];
  const [paymentMethod, setPaymentMethod] = useState('');
  const [appliedCoupan, setAppliedCoupan] = useState({});
  const [addressData, setAddressData] = useState(address);
  const [selectedAddress, setSelectedAddress] = useState(addressData[0]);
  const [showThankuPopup, setShowThankuPopup] = useState(false);
  const scrollRef = useRef();
  function onPressOffers() {
    navigation.navigate('Offers', {
      onAppliedCoupon: data => {
        setAppliedCoupan(data);
      },
    });
  }
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView
          showsVerticalScrollIndicator={false}
          bounces={false}
          ref={scrollRef}>
          <View style={styles.space} />
          <Text style={styles.likeTxt}>Check Out</Text>
          <AddressCard
            onChange={() =>
              navigation.navigate('ChangeAddress', {
                addressData: addressData,
                onSelectAddress: data => {
                  let allAdd = addressData.map(item => {
                    if (item.id === data.id) {
                      return {...item, isSelected: true};
                    } else {
                      return {...item, isSelected: false};
                    }
                  });
                  setAddressData(allAdd);
                  setSelectedAddress(data);
                },
              })
            }
            showChange={true}
            address={selectedAddress?.address}
            phno={selectedAddress?.phno}
            toPerson={selectedAddress?.toPerson}
          />
          <DropShadow style={styles.shadow2}>
            <TouchableOpacity style={styles.offerView} onPress={onPressOffers}>
              <Image source={SALE} />
              <Text style={styles.offerShowTxt}>
                CLICK HERE TO VIEW ALL COUPONS
              </Text>
            </TouchableOpacity>
          </DropShadow>
          <Text style={styles.billTxt}>Bill Detail</Text>
          <DropShadow style={styles.shadow}>
            <View style={styles.billView}>
              <View style={styles.billItemView}>
                <Text style={styles.billItem}>Item Total</Text>
                <Text style={styles.billItem2}>₹ 529</Text>
              </View>
              <View style={styles.billItemView}>
                <Text style={styles.billItem}>Delivery Fee</Text>
                <Text style={styles.billItem2}>₹ 30</Text>
              </View>
              {Object.keys(appliedCoupan).length > 0 && (
                <View style={styles.billItemView}>
                  <Text style={styles.billItem}>
                    Coupon{' '}
                    {appliedCoupan?.offerName
                      ? `(${appliedCoupan?.offerName})`
                      : ''}
                  </Text>
                  <Text style={styles.billItem2}>₹ 30</Text>
                </View>
              )}
              <View style={styles.billItemView}>
                <Text style={styles.billItem}>You Save</Text>
                <Text style={styles.billItem2}>₹ 30</Text>
              </View>
              <View style={styles.divider} />
              <View style={styles.billItemView}>
                <Text style={styles.billItem}>Total</Text>
                <Text style={styles.billItem2}>₹ 599</Text>
              </View>
            </View>
          </DropShadow>
          <Text style={styles.billTxt}>Select Payment Option</Text>
          <View style={styles.paymentsView}>
            {paymentMethods.map((item, index) => {
              const selected = paymentMethod === item.paymantName;
              const borderWidth = selected ? 1.5 : 0;
              const borderColor = selected ? '#25A140' : null;
              return (
                <DropShadow style={styles.shadow} key={index}>
                  <TouchableOpacity
                    onPress={() => setPaymentMethod(item.paymantName)}
                    style={[styles.paymentCardBtn, {borderWidth, borderColor}]}>
                    <Image source={item.logo} />
                  </TouchableOpacity>
                  {selected && (
                    <Image source={GREEN_CHECK} style={styles.checkIcon} />
                  )}
                </DropShadow>
              );
            })}
          </View>
        </ScrollView>
        <View style={styles.margin10} />
        <SubmitButton
          onPress={() => {
            if (paymentMethod === '') {
              scrollRef.current.scrollToEnd({animated: true});
            } else {
              setShowThankuPopup(true);
            }
          }}
          customTitleStyle={styles.addToCart}
          customBtnStyle={styles.addToCartTxt}
          title={paymentMethod === 'COD' ? 'Proceed' : 'Proceed'}
        />
        <View style={styles.marginBottom} />
        <OfferPopUp
          visible={showThankuPopup}
          isApplied={false}
          code={'Thank You!'}
          discription={'You Will Receive A Confirmation Email Shortly'}
          showThankIcon={true}
          onPress={() => {
            setShowThankuPopup(false);
            navigation.push('Home');
          }}
        />
      </ImageBackground>
    </SafeAreaView>
  );
};

export default CheckOut;

const styles = StyleSheet.create({
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3,
    shadowOffset: {
      height: 2,
      width: 2,
    },
  },
  marginBottom: {marginBottom: 10},
  margin10: {marginTop: 10},
  shadow2: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 5,
    shadowOffset: {
      height: 2,
      width: 2,
    },
    marginTop: 25,
  },
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  cakeContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  priceView: {
    flexDirection: 'row',
    width: '88%',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 12,
  },
  totalTxt: {
    fontSize: 17,
    fontWeight: '500',
    color: '#212121',
  },
  price: {
    fontSize: 15,
    fontWeight: '800',
    color: '#000000',
  },
  addToCart: {
    color: 'white',
    fontSize: 17,
    fontWeight: 'bold',
  },
  addToCartTxt: {
    marginBottom: 5,
    width: '90%',
    alignSelf: 'center',
    height: 52,
  },
  proceedBtnView: {
    height: 90,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#CED4DA',
    alignItems: 'center',
    justifyContent: 'center',
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
    marginHorizontal: 1,
  },
  likeTxt: {
    fontSize: 24,
    color: '#000000DE',
    fontWeight: 'bold',
    marginVertical: 14,
    alignSelf: 'center',
  },
  space: {
    height: 10,
  },
  billView: {
    width: '85%',
    borderColor: '#CED4DA',
    // height: 136,
    borderWidth: 1,
    backgroundColor: 'white',
    alignSelf: 'center',
    paddingHorizontal: 10,
    paddingTop: 10,
    borderRadius: 8,
  },
  offerView: {
    width: '85%',
    borderStyle: 'dashed',
    borderColor: '#CED4DA',
    height: 120,
    borderWidth: 1,
    backgroundColor: 'white',
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
  },
  offerShowTxt: {
    marginTop: 18,
    color: '#000000CC',
    fontSize: 15,
    fontWeight: '700',
  },
  billTxt: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000000DE',
    alignSelf: 'center',
    marginBottom: 17,
    marginTop: 30,
  },
  billItem: {
    fontSize: 15,
    fontWeight: '500',
    color: '#212121',
  },
  billItem2: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#000000',
    marginBottom: 12,
  },
  billItemView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  addressView: {
    width: '85%',
    backgroundColor: 'white',
    alignSelf: 'center',
    paddingHorizontal: 12,
    paddingVertical: 20,
  },
  addressFiels: {height: 70, paddingTop: 10},
  divider: {
    height: 1,
    backgroundColor: '#CED4DA',
    width: '100%',
    marginBottom: 10,
  },
  paymentCardBtn: {
    height: 50,
    width: 100,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  paymentsView: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignSelf: 'center',
    width: '90%',
    marginBottom: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkIcon: {
    position: 'absolute',
    marginLeft: 85,
    marginTop: 5,
  },
});
