import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React from 'react';
import {
  APP_BACK_IMAGE,
  CARD,
  CART,
  WALLET,
} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import DropShadow from 'react-native-drop-shadow';

const About = ({navigation}) => {
  const services = [
    {
      serviceName: 'Delivery or Takeaway',
      icon: CART,
    },
    {
      serviceName: 'Secure card payment',
      icon: CARD,
    },
    {
      serviceName: 'Cash payment',
      icon: WALLET,
    },
  ];
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView showsVerticalScrollIndicator={false} bounces={true}>
          <Text style={styles.headerTxt}>Our History</Text>
          <DropShadow style={styles.shadow}>
            <View style={styles.aboutView}>
              <Text style={styles.subTxt}>Overview</Text>
              <Text style={styles.subDetails}>
                {
                  'We are proud to Introduce ourselves as PizzaToday India™ brand run by PizzaToday Inndia Food & Beverages based at Singrauli, Madhya Pradesh. PizzaToday India™ is a proud Indian pizza chain & one of the leading Pizza Chain in India. Founded on 08 dec 2015. PizzaToday India™ is known for its Taste & Variety of Fresh Pizzas. PizzaToday India has a wide product portfolio of pizzas and its best in Vegetarian & Non vegetarian .'
                }
              </Text>
              <Text style={styles.subTxt}>ABOUT CEO</Text>
              <Text style={styles.subDetails}>
                {
                  'The man standing behind the success of PizzaToday India™ is RAJESH KUMAR SONI who has a great passion for cooking. His vast experience in various business makes him a unique Entrepreneur, but his love for food Industry started from indian sub continent since 09 years and now he has applied all his expertise to his own venture and now his main aim is to benefit and to Inspire young generation who have flair to grow individually as a young Male and Female Entrepreneurs.'
                }
              </Text>
              <Text style={styles.subTxt}>Vision</Text>
              <Text style={styles.subDetails}>
                {
                  'Our motto is to generate business opportunity to people who can be self employed & can create platform of job opportunities to others. PizzaToday India™ recipes are unique and blended well as per the Indian taste buds so from kids to elders our rates are pocket friendly.'
                }
              </Text>
            </View>
          </DropShadow>
          {services.map((item, index) => {
            return (
              <DropShadow key={index} style={styles.shadow}>
                <View style={styles.serviceView}>
                  <Image source={item.icon} />
                  <Text style={styles.serviceTxt}>{item.serviceName}</Text>
                </View>
              </DropShadow>
            );
          })}
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default About;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3,
    shadowOffset: {
      height: 1,
      width: 1,
    },
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000DE',
    marginVertical: 30,
    alignSelf: 'center',
  },
  aboutView: {
    // height: 300,
    width: '85%',
    backgroundColor: 'white',
    alignSelf: 'center',
    padding: 15,
    marginBottom: 20,
    borderRadius: 8,
  },
  subTxt: {
    color: '#000000DE',
    fontSize: 17,
    fontWeight: '600',
    marginBottom: 5,
  },
  subDetails: {
    color: '#000000CC',
    fontSize: 14,
    lineHeight: 21,
    fontWeight: '400',
    textAlign: 'justify',
    marginBottom: 20,
  },
  serviceView: {
    backgroundColor: 'white',
    height: 132,
    width: '85%',
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderRadius: 8,
  },
  serviceTxt: {
    marginTop: 12,
    fontSize: 17,
    color: '#000000CC',
    fontWeight: '400',
  },
});
