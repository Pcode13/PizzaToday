import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import DropShadow from 'react-native-drop-shadow';
import {APP_BACK_IMAGE, BACK_ICON} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import OrderList from '../../common/Components/OrderList';

const BillDetails = ({navigation}) => {
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView showsVerticalScrollIndicator={false} bounces={true}>
          <View style={styles.margin30} />
          <View style={styles.topView}>
            <TouchableOpacity
              style={styles.backBtnView}
              onPress={() => navigation.goBack()}>
              <Image source={BACK_ICON} style={styles.backBtn} />
            </TouchableOpacity>
            <Text style={styles.headerTxt}>Bill Details</Text>
          </View>
          <DropShadow style={styles.shadow}>
            <View style={[styles.subContainer]}>
              <Text style={[styles.shopNameTxt, styles.margin30]}>
                Shop Details :
              </Text>
              <Text style={styles.shopNameTxt}>Pizza Today</Text>
              <Text style={styles.shopAddress}>
                Newjeevan bihar sec 1 waidhan singrauli m.p. 486886
              </Text>
              <Text style={styles.mobTxt}>M: 9742519103</Text>
            </View>
          </DropShadow>
          <DropShadow style={styles.shadow}>
            <View style={[styles.subContainer]}>
              <Text style={[styles.shopNameTxt, styles.margin30]}>
                Customer Details :
              </Text>
              <Text style={styles.shopNameTxt}>Anubhav Shah</Text>
              <Text style={styles.shopAddress}>
                Banglore 3rd stage, sec 1 KA 573636
              </Text>
              <Text style={styles.mobTxt}>M: 98983732443</Text>
            </View>
          </DropShadow>
          <DropShadow style={styles.shadow}>
            <View style={styles.subContainer}>
              <View style={styles.orderTxt}>
                <Text style={styles.title}>Order Details</Text>
              </View>
              <View style={styles.devider1} />
              <OrderList itemName={'Butter Paneer Pizza'} isVeg={true} />
              <View style={styles.devider1} />
              <OrderList itemName={'Butter Chicken Pizza'} isVeg={false} />
              <View style={styles.devider1} />
              <OrderList itemName={'Veg Massroom Pizza'} isVeg={true} />
              <View style={styles.devider1} />
              <View style={styles.cardView}>
                <View style={styles.txtView}>
                  <Text style={styles.txttitle}>Item total</Text>
                  <Text style={styles.txttitle}>₹ 199.00</Text>
                </View>
                <View style={styles.txtView}>
                  <Text style={styles.txttitleblue}>Coupon -(TRYNEW)</Text>
                  <Text style={styles.txttitleblue}>You saved ₹ 19.00</Text>
                </View>
                <View style={styles.txtView}>
                  <Text style={styles.txttitle}>Taxes</Text>
                  <Text style={styles.txttitle}>₹ 7.48</Text>
                </View>
                <View style={styles.txtView}>
                  <Text style={styles.txttitle}>Delivery Charge</Text>
                  <Text style={styles.txttitle}>₹ 40.00</Text>
                </View>
                <View style={styles.txtView}>
                  <Text style={styles.txttitle}>Container Charge</Text>
                  <Text style={styles.txttitle}>₹ 21.00</Text>
                </View>
                <View style={styles.devider1} />
                <View style={styles.txtViewTotalview}>
                  <Text style={styles.txttitleTotal}>Grand Total</Text>
                  <Text style={styles.txttitleTotal}>₹121.00</Text>
                </View>

                {/* <View style={styles.txtViewBlue}> */}
                <View style={styles.txtViewBlueView}>
                  <Text style={styles.txttitleBlueView}>
                    Your total savings
                  </Text>
                  <Text style={styles.txttitleBlueView}>₹19.00</Text>
                </View>
                {/* </View> */}
                <View style={styles.orderViewblack}>
                  <Text style={styles.txttitleblack}>ORDER NUMBER</Text>
                  <Text style={styles.txttitleblack2}>4254816918</Text>
                  <Text style={styles.txttitleblack}>PAYMENT</Text>
                  <Text style={styles.txttitleblack2}>Paid :Using Upi</Text>
                </View>
              </View>
            </View>
          </DropShadow>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default BillDetails;

const styles = StyleSheet.create({
  shopAddress: {
    marginTop: 3,
    fontSize: 13,
    fontWeight: '400',
    color: 'black',
  },
  shopNameTxt: {
    fontSize: 16,
    fontWeight: '600',
    color: 'black',
  },
  mobTxt: {
    marginTop: 3,
    fontSize: 13,
    fontWeight: '500',
    color: 'black',
  },
  divider: {
    height: 1,
    backgroundColor: 'black',
    width: '100%',
  },
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000DE',
    // marginVertical: 0,
    marginBottom: 15,
    alignSelf: 'center',
    // fontFamily: 'Roboto Slab',
  },
  subContainer: {
    padding: 15,
    backgroundColor: 'white',

    width: '92%',
    borderWidth: 1,
    borderColor: '#CED4DA',

    alignSelf: 'center',
    marginBottom: 20,
    borderRadius: 8,
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: {
      height: 3,
      width: 3,
    },
  },
  backBtnView: {position: 'absolute', left: 0, marginLeft: 20},
  topView: {
    flexDirection: 'row',
    justifyContent: 'center',
    // alignItems: 'center',
    // borderWidth: 1,
  },
  margin30: {
    marginBottom: 10,
  },
  backBtn: {
    height: 20,
    width: 30,
    marginTop: 4,
    position: 'absolute',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: 'black',
    textAlign: 'center',
    // marginTop: 8,
  },

  devider: {
    height: 1,
    width: '100%',
    backgroundColor: '#AAAAAA',
    marginVertical: 10,
  },
  devider1: {
    height: 1,
    width: '100%',
    backgroundColor: '#AAAAAA',
    marginTop: 10,
    alignSelf: 'center',
  },
  orderTxt: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 8,
  },
  customBtnStyle: {
    width: '40%',
    height: 25,
    backgroundColor: '#f2e9e9',
  },
  customTitleStyle: {
    color: 'red',
    fontSize: 12,
  },
  cardView: {
    width: '100%',
    // height: '18%',
    // backgroundColor: 'red',
    marginTop: 20,
  },
  txtView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 10,
  },
  txt: {
    fontSize: 12,
    paddingHorizontal: 10,
  },
  txttitle: {
    fontSize: 12,
    color: 'black',
    lineHeight: 16,
  },
  txttitleblue: {
    fontSize: 12,
    color: '#2862ad',
    lineHeight: 16,
  },
  txttitleTotal: {
    fontSize: 15,
    fontWeight: '600',
    color: 'black',
    marginBottom: 8,
  },
  txtViewTotalview: {
    padding: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  txtViewBlueView: {
    padding: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#e1e9f2',
    width: '95%',
    alignContent: 'center',
    borderColor: '#2862ad',
    borderWidth: 1,
    borderRadius: 8,
    alignSelf: 'center',
  },
  txttitleBlueView: {
    fontSize: 15,
    color: '#2862ad',
    fontWeight: '700',
  },
  txttitleOrder: {
    fontSize: 18,
    fontWeight: '500',
    color: 'black',
  },
  txttitleblack: {
    fontSize: 12,
    color: 'black',
    fontWeight: '600',
  },
  txttitleblack2: {
    fontSize: 12,
    color: 'black',
    fontWeight: '600',
    marginBottom: 8,
  },
  orderViewblack: {marginTop: 25, padding: 10},
  // txtViewBlue: {justifyContent: 'center', alignItems: 'center'},
});
