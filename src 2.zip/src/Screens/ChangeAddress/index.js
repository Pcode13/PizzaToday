import {
  Alert,
  ImageBackground,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import {APP_BACK_IMAGE} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import AddressCard from '../../common/Components/AddressCard';
import SubmitButton from '../../common/Components/SubmitButton';

const ChangeAddress = props => {
  const {navigation} = props;
  const [addressData, setAddressData] = useState(
    props.route?.params?.addressData,
  );
  const [selectedAddress, setSelectedAddress] = useState({});
  useEffect(() => {
    let selectedAdd = props.route?.params?.addressData?.find(
      item => item.isSelected,
    );
    setSelectedAddress(selectedAdd);
  }, [props.route?.params?.addressData]);
  function onRemoveAddress(item) {
    Alert.alert('Remove Address', 'Are you sure Want to Remove', [
      {
        text: 'Cancel',
        onPress: () => console.log('Ask me later pressed'),
        style: 'cancel',
      },
      {
        text: 'Remove',
        onPress: () => {
          let newAddresssList = addressData?.filter(i => i.id !== item.id);
          setAddressData(newAddresssList);
        },
        style: 'cancel',
      },
    ]);
  }
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
          <View style={styles.headerView}>
            <Text style={styles.headerTxt}>Select Address</Text>
            <TouchableOpacity onPress={() => navigation.navigate('AddAddress')}>
              <Text style={styles.addBtn}>+ Add New</Text>
            </TouchableOpacity>
          </View>
          {addressData?.map(item => {
            return (
              <AddressCard
                key={item?.id}
                selected={selectedAddress === item}
                onPress={() => setSelectedAddress(item || {})}
                showChange={false}
                address={item?.address}
                phno={item?.phno}
                toPerson={item?.toPerson}
                onRemove={() => onRemoveAddress(item)}
                showRemove={selectedAddress !== item}
              />
            );
          })}
        </ScrollView>
        <View style={styles.proceedBtnView}>
          <SubmitButton
            onPress={() => {
              props.route?.params?.onSelectAddress(selectedAddress);
              navigation.goBack();
            }}
            customTitleStyle={styles.addToCart}
            customBtnStyle={styles.addToCartTxt}
            title={'Select'}
          />
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default ChangeAddress;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  addToCart: {
    color: 'white',
    fontSize: 17,
    fontWeight: 'bold',
  },
  addToCartTxt: {
    marginBottom: 5,
    width: '90%',
    alignSelf: 'center',
    height: 52,
  },
  proceedBtnView: {
    height: 90,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#CED4DA',
    alignItems: 'center',
    justifyContent: 'center',
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
    marginHorizontal: 1,
  },
  headerView: {
    flexDirection: 'row',
    marginBottom: 20,
    marginTop: 30,
    width: '85%',
    justifyContent: 'space-between',
    alignItems: 'center',
    alignSelf: 'center',
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000DE',
  },
  addBtn: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#25A140',
  },
});
