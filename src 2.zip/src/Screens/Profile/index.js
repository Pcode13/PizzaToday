import {
  Dimensions,
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {APP_BACK_IMAGE, SALE} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import ProfileCards from '../../common/Components/Profilecards';
import OrderCards from '../../common/Components/OrderCards';
import SubmitButton from '../../common/Components/SubmitButton';
import DropShadow from 'react-native-drop-shadow';
import addressData from '../ChangeAddress/addresses.json';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
const Tab = createMaterialTopTabNavigator();
const ProfileDashboard = ({navigation, route}) => {
  function RenderDashboard() {
    return (
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.mainView}>
            <Text style={styles.headerTxt}>Dashboard</Text>
            <ProfileCards />
            <DropShadow style={styles.shadow2}>
              <TouchableOpacity style={styles.offerView}>
                <Image source={SALE} style={{tintColor: 'black'}} />
                <Text style={styles.offerShowTxt}>Offers For You</Text>
              </TouchableOpacity>
            </DropShadow>
            <Text style={styles.headerTxt}>Recent Order</Text>
            <OrderCards
              onPress={() => navigation.navigate('BillDetails')}
              customStyle={styles.margin10}
              status={'Completed'}
            />
            <OrderCards
              onPress={() => navigation.navigate('BillDetails')}
              customStyle={styles.margin10}
              status={'Pending'}
            />
            <OrderCards
              onPress={() => navigation.navigate('BillDetails')}
              customStyle={styles.margin30}
              status={'Cancelled'}
            />
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }

  function RenderMyOrders() {
    return (
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.mainView}>
            <Text style={styles.headerTxt}>My Order</Text>

            <OrderCards
              onPress={() => navigation.navigate('BillDetails')}
              customStyle={styles.margin10}
              visibletext={false}
            />
            <OrderCards
              onPress={() => navigation.navigate('BillDetails')}
              customStyle={styles.margin10}
              visibletext={false}
            />
            <OrderCards
              onPress={() => navigation.navigate('BillDetails')}
              customStyle={styles.margin30}
              visibletext={false}
            />
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }

  function RenderProfile() {
    return (
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.mainView}>
            <Text style={[styles.headerTxt, styles.margin30]}>Profile</Text>
            <SubmitButton
              onPress={() => navigation.navigate('UpdateProfile')}
              customBtnStyle={styles.changePass}
              title={'Update Profile'}
            />
            <SubmitButton
              onPress={() => navigation.navigate('ChangePassword')}
              customBtnStyle={styles.changePass}
              title={'Change Password'}
            />
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }

  function RenderAddress() {
    return (
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.mainView}>
            <Text style={styles.headerTxt}>Billing Address</Text>
            <DropShadow style={styles.shadow}>
              <View style={styles.subContainer}>
                <Text style={styles.boldtxt}> Ashish Singh </Text>
                <View style={styles.data}>
                  <Text style={styles.simpleTxt}>Address : </Text>
                  <Text style={styles.boldtxt}>
                    Nawjeevan bihar sec 1 waidhan singrauli m.p. 486886
                  </Text>
                </View>

                <View style={styles.data}>
                  <Text style={styles.simpleTxt}>Landmark : </Text>
                  <Text style={styles.boldtxt}>waidhan</Text>
                </View>

                <View style={styles.data}>
                  <Text style={styles.simpleTxt}>Mobile No : </Text>
                  <Text style={styles.boldtxt}>+91 123 456 7890</Text>
                </View>
                <View style={styles.data}>
                  <Text style={styles.simpleTxt}>Email : </Text>
                  <Text style={styles.boldtxt}>ashish@gmail.com</Text>
                </View>
              </View>
            </DropShadow>
            <SubmitButton
              onPress={() => {
                navigation.navigate('ChangeAddress', {
                  addressData: addressData,
                  onSelectAddress: data => {
                    console.log(data);
                  },
                });
              }}
              title={'Change Address'}
              customBtnStyle={styles.savebtn}
            />
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
      <Header navigation={navigation} />
      <Tab.Navigator
        screenOptions={({route}) => ({
          tabBarScrollEnabled: true,
          tabBarStyle: styles.tabBarStyle,
          tabBarLabelStyle: styles.tabBarLabelStyle,
          tabBarItemStyle: styles.tabBarItemStyle,
          tabBarShowLabel: true,
          // tabBarPressOpacity: 1,
          tabBarIndicatorStyle: styles.tabBarIndicatorStyle,
        })}>
        <Tab.Screen
          key={'Dashboard'}
          name={'Dashboard'}
          component={RenderDashboard}
          options={{tabBarLabel: 'Dashboard'}}
        />
        <Tab.Screen
          key={'My Order'}
          name={'My Order'}
          component={RenderMyOrders}
          options={{tabBarLabel: 'My Order'}}
        />
        <Tab.Screen
          key={'Profile'}
          name={'Profile'}
          component={RenderProfile}
          options={{tabBarLabel: 'Profile'}}
        />
        <Tab.Screen
          key={'Address'}
          name={'Address'}
          component={RenderAddress}
          options={{tabBarLabel: 'Address'}}
        />
      </Tab.Navigator>
    </SafeAreaView>
  );
};

export default ProfileDashboard;

const styles = StyleSheet.create({
  headerStyle: {
    color: '#495057',
    fontSize: 13,
    fontWeight: 'bold',
  },
  changePass: {
    width: '60%',
    alignSelf: 'center',
    marginBottom: 40,
  },
  mainView: {width: '85%', alignSelf: 'center', marginTop: 35},
  shadow2: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 5,
    shadowOffset: {
      height: 2,
      width: 2,
    },
    marginTop: 25,
  },
  offerView: {
    width: '100%',
    borderStyle: 'dashed',
    borderColor: '#CED4DA',
    height: 120,
    borderWidth: 1,
    backgroundColor: 'white',
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    marginBottom: 30,
    marginTop: 15,
  },
  offerShowTxt: {
    marginTop: 18,
    color: '#000000CC',
    fontSize: 15,
    fontWeight: '700',
  },
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  buttonBtn: {
    width: '50%',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'black',
  },
  buttonTxt: {
    color: 'white',
    fontSize: 17,
    fontWeight: '600',
  },
  navContainer: {
    flexDirection: 'row',
    width: '100%',
    backgroundColor: 'black',
    borderTopWidth: 2,
    borderTopColor: 'white',
    // marginBottom: 35,
  },
  cakeContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000DE',
    // marginVertical: 0,
    marginBottom: 15,
    alignSelf: 'center',
    // fontFamily: 'Roboto Slab',
  },
  subContainer: {
    padding: 15,
    backgroundColor: 'white',

    width: '100%',
    borderWidth: 1,
    borderColor: '#CED4DA',

    alignSelf: 'center',
    marginBottom: 20,
    borderRadius: 8,
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: {
      height: 3,
      width: 3,
    },
  },
  btnStyle: {
    marginBottom: 10,
  },
  otpBtn: {
    backgroundColor: '#F5F5F5',
  },
  otpTxt: {
    color: '#495057',
  },
  boldtxt: {
    flexShrink: 1,
    fontWeight: '700',
    color: 'black',
    marginBottom: 10,
  },
  simpleTxt: {color: 'black'},
  savebtn: {
    alignSelf: 'center',
    width: '100%',
    height: 40,
  },
  margin10: {
    marginBottom: 30,
  },
  margin30: {
    marginBottom: 30,
  },
  chooseFileView: {
    marginTop: -15,
    marginBottom: 25,
  },
  chooseFiletxt: {
    textAlign: 'center',
  },
  data: {
    flexDirection: 'row',
  },
  tabBarStyle: {
    height: 43,
    backgroundColor: 'black',
    borderTopWidth: 2,
    borderTopColor: 'white',
  },
  tabBarLabelStyle: {
    fontSize: 17,
    width: Dimensions.get('screen').width * 0.25,
    color: 'white',
    textTransform: 'capitalize',
    paddingHorizontal: 0,
    alignSelf: 'center',
    alignContent: 'center',
    marginTop: 0,
  },
  tabBarItemStyle: {
    height: 43,
    width: Dimensions.get('screen').width * 0.25,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabBarIndicatorStyle: {
    backgroundColor: '#25A140',
    height: '100%',
  },
});
