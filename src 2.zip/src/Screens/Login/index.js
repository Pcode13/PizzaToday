import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {
  APP_BACK_IMAGE,
  APP_LOGO,
  BACK_ICON,
} from '../../common/Assets/Constants';
import TextInputWithTitle from '../../common/Components/TextInput';
import SubmitButton from '../../common/Components/SubmitButton';
import {setLoggedUserData} from '../../common/Utils/localStrorageUtils';
import {ShowToast} from '../../common/Utils/toastUtils';
import container from '../../Container/AuthContainer';
import {compose} from 'recompose';

const Login = props => {
  const {navigation} = props;
  const [emailPhone, setEmailPhone] = useState('');
  const [emailPhoneError, setEmailPhoneError] = useState('');
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  useEffect(() => {
    setEmailPhone('');
    setEmailPhoneError('');
    setPassword('');
    setPasswordError('');
  }, []);
  function validateFields() {
    let isError = false;
    if (emailPhone === '') {
      setEmailPhoneError('This Field is Requried');
      isError = true;
    } else {
      setEmailPhoneError('');
    }
    if (password === '') {
      setPasswordError('Please Enter Password');
      isError = true;
    } else {
      setPasswordError('');
    }
    return !isError;
  }

  function handleLogin() {
    if (validateFields()) {
      let data = {
        password: password,
      };
      let mobReg = /^[6-9]{1}[0-9]{9}$/;
      let emailReg = /\S+@\S+\.\S+/;
      if (mobReg.test(emailPhone) === true) {
        data.login_id = emailPhone;
      } else if (emailReg.test(emailPhone) === true) {
        data.email = emailPhone;
      } else {
        setEmailPhoneError('Please Enter Valid Email/Mobile');
        return;
      }
      console.log('datadata', data);
      props.login({
        params: data,
        onSuccess: response => {
          if (response?.status === 1) {
            let loggedUserData = {
              ...response?.data,
              token: response?.token,
            };
            setLoggedUserData(loggedUserData).then(res => {
              if (res === 'success') {
                ShowToast({
                  type: 'success',
                  text1: response?.message || 'Login Successfully',
                });
                if (props.route?.params?.onLogin) {
                  props?.route?.params?.onLogin();
                } else {
                  navigation.replace('Home');
                }
              }
            });
          } else {
            ShowToast({
              type: 'error',
              text1: response?.message || 'Login Failed',
            });
          }
        },
        onFailure: err => {
          ShowToast({
            type: 'error',
            text1: err?.message || 'Login Failed',
          });
        },
      });
    }
  }

  return (
    <ImageBackground
      source={APP_BACK_IMAGE}
      resizeMode="cover"
      style={styles.image}>
      <SafeAreaView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false} bounces={false} sty>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Image source={BACK_ICON} style={styles.backBtn} />
          </TouchableOpacity>
          <Image source={APP_LOGO} style={styles.appLogo} />
          <Text style={styles.welcomeTxt}>Welcome Back!</Text>
          <Text style={styles.subTxt}>Login To Your Account</Text>
          <View style={styles.subContainer}>
            <TextInputWithTitle
              errorMsg={emailPhoneError}
              error={emailPhoneError !== ''}
              value={emailPhone}
              onChangeText={setEmailPhone}
              title={'Email / Mobile No.'}
              placeholder={'Enter Email or Mobile No.'}
            />
            <TextInputWithTitle
              errorMsg={passwordError}
              error={passwordError !== ''}
              value={password}
              onChangeText={setPassword}
              title={'Password'}
              placeholder={'Enter Password'}
              secureTextEntry={true}
            />
            <TouchableOpacity onPress={() => navigation.push('ResetPassword')}>
              <Text style={styles.resetBtn}>Reset Password?</Text>
            </TouchableOpacity>
            <SubmitButton
              onPress={handleLogin}
              title={'Submit'}
              customBtnStyle={styles.btnStyle}
            />
            <Text style={styles.orTxt}>OR</Text>
            <SubmitButton
              onPress={() => navigation.navigate('LoginWithOTP')}
              title={'Login With OTP'}
              customBtnStyle={styles.otpBtn}
              customTitleStyle={styles.otpTxt}
            />
            <TouchableOpacity onPress={() => navigation.navigate('Register')}>
              <Text style={styles.registerLink}>
                New to PizzaToday? Create an account
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default compose(container)(Login);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  welcomeTxt: {
    // fontFamily: 'RobotoSlab-Bold',
    fontSize: 28,
    color: '#000000',
    fontWeight: 'bold',
    alignSelf: 'center',
    marginTop: 12,
  },
  subTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 14,
    color: '#090909',
    fontWeight: '600',
    alignSelf: 'center',
    marginTop: 10,
  },
  appLogo: {
    width: 88,
    height: 53,
    alignSelf: 'center',
    marginTop: 30,
  },
  subContainer: {
    padding: 30,
    backgroundColor: 'white',
    marginVertical: 30,
    width: '90%',
    borderWidth: 1,
    borderColor: '#CED4DA',
    borderRadius: 10,
    alignSelf: 'center',
  },
  btnStyle: {
    marginTop: 20,
  },
  resetBtn: {
    alignSelf: 'flex-end',
    color: '#767676',
    fontSize: 14,
    fontWeight: '600',
  },
  otpBtn: {
    backgroundColor: '#F5F5F5',
  },
  otpTxt: {
    color: '#495057',
    fontSize: 14,
    fontWeight: 'bold',
  },
  orTxt: {
    color: '#495057',
    fontWeight: 'bold',
    fontSize: 17,
    alignSelf: 'center',
    marginVertical: 15,
  },
  backBtn: {
    height: 20,
    width: 30,
    margin: 20,
  },
  registerLink: {
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 30,
    alignSelf: 'center',
    color: '#25A140',
  },
});
