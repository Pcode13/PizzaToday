import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {
  APP_BACK_IMAGE,
  FACEBOOK,
  INSTAGRAM,
  TWITTER,
} from '../../common/Assets/Constants';
import TextInputWithTitle from '../../common/Components/TextInput';
import SubmitButton from '../../common/Components/SubmitButton';
import Recaptca from '../../common/Components/Recaptca';
import DropShadow from 'react-native-drop-shadow';
import LinkCard from '../../common/Components/LinkCard';
import Header from '../../common/Components/Header';

const QuickMsg = ({navigation}) => {
  const [userName, setUserName] = useState('');
  const [captchaVerified, setCaptchaVerified] = useState(false);
  function renderFooterSection() {
    return (
      <View style={styles.footerContainer}>
        <LinkCard
          title={'Quick Links'}
          subLinks={[
            {
              linkName: 'About us',
              onPress: () => null,
            },
            {
              linkName: 'Contacts',
              onPress: () => null,
            },
            {
              linkName: 'Terms and conditions',
              onPress: () => null,
            },
          ]}
        />
        <LinkCard
          title={'Head Office'}
          subLinks={[
            {
              linkName: 'Nawjeevan bihar sec 1 waidhan singrauli m.p. 486886',
              onPress: () => null,
            },
            {
              linkName: '8989586868',
              onPress: () => null,
            },
          ]}
        />
        <LinkCard
          title={'Corporate Office'}
          subLinks={[
            {
              linkName: 'Nawjeevan bihar sec 1 waidhan singrauli m.p. 486886',
              onPress: () => null,
            },
            {
              linkName: '8989586868',
              onPress: () => null,
            },
          ]}
        />
        <View style={styles.socialContainer}>
          <TouchableOpacity>
            <Image source={FACEBOOK} style={styles.socialIcon} />
          </TouchableOpacity>
          <TouchableOpacity>
            <Image source={INSTAGRAM} style={styles.socialIcon} />
          </TouchableOpacity>
          <TouchableOpacity>
            <Image source={TWITTER} style={styles.socialIcon} />
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <ImageBackground
      source={APP_BACK_IMAGE}
      resizeMode="cover"
      style={styles.image}>
      <SafeAreaView style={styles.container}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView showsVerticalScrollIndicator={false}>
          <Text style={styles.headerTxt}>Send Us a Quick Message</Text>
          <DropShadow style={styles.shadow}>
            <View style={styles.subContainer}>
              <TextInputWithTitle
                title={'User Name'}
                placeholder={'Enter User Name'}
              />
              <TextInputWithTitle
                title={'Email Id.'}
                placeholder={'Enter Email Id'}
              />
              <TextInputWithTitle
                // defaultValue={'+91'}
                isMobile={true}
                title={'Mobile No.'}
                placeholder={'Enter Mobile No'}
              />
              <TextInputWithTitle
                title={'Subject'}
                placeholder={'Enter the Subject'}
              />
              <TextInputWithTitle
                title={'Message'}
                placeholder={'Enter the Message'}
                customStyle={styles.addresstxt}
                multiline={true}
                numberOfLines={4}
              />
              <TextInputWithTitle
                title={'Address'}
                placeholder={'Store Location Where You Want to Open'}
                secureTextEntry={true}
              />
              <TouchableOpacity style={styles.chooseFileView}>
                <Text style={styles.chooseFiletxt}>
                  + Choose files (No File Choosen).
                </Text>
              </TouchableOpacity>

              <Recaptca onVerfied={() => setCaptchaVerified(true)} />
              <SubmitButton
                title={'Send'}
                customBtnStyle={styles.btnStyle}
                // onPress={() => navigation.navigate('Home')}
              />
            </View>
          </DropShadow>
          <Text style={styles.pdfname}> Get In Touch</Text>
          <DropShadow style={styles.shadow}>
            <View style={styles.subContainerPDF}>
              <Text style={styles.txt}>
                By simply doing business with us, we will ​guarantee our service
                response to you within 24hrs.
              </Text>
              <Text style={styles.pdfdes}>Address</Text>
              <Text style={styles.txt}>
                Nawjeevan bihar sec 1 waidhan singrauli m.p. 486886
              </Text>
              <Text style={styles.pdfdes}>Email</Text>
              <Text style={styles.txt}>info@pizzatoday.in</Text>
              <Text style={styles.pdfdes}>Phone</Text>
              <Text style={styles.txt}>8989586868</Text>
            </View>
          </DropShadow>
          {renderFooterSection()}
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default QuickMsg;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: '100%',
  },

  subTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 14,
    color: '#090909',
    fontWeight: '600',
    alignSelf: 'center',
    marginTop: 10,
  },
  appLogo: {
    width: 88,
    height: 53,
    alignSelf: 'center',
    marginTop: 30,
  },
  subContainer: {
    backgroundColor: 'white',
    // marginVertical: 30,
    width: '85%',

    borderWidth: 1,
    borderColor: '#CED4DA',

    alignSelf: 'center',
    padding: 15,
    borderRadius: 8,
  },
  btnStyle: {
    marginTop: 5,
  },
  recaptcaView: {
    height: 67,
    borderWidth: 1,
    borderColor: '#CED4DA',
    backgroundColor: '#F9F9F9',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    marginBottom: 20,
  },
  checkBtn: {
    height: 30,
    width: 30,
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: '#CED4DA',
    borderRadius: 5,
  },
  captcaIcon: {
    width: 60,
    height: 60,
  },
  otpBtn: {
    backgroundColor: '#F5F5F5',
  },
  otpTxt: {
    color: '#495057',
    fontSize: 14,
    fontWeight: 'bold',
  },
  orTxt: {
    color: '#495057',
    fontWeight: 'bold',
    fontSize: 20,
    alignSelf: 'center',
    marginVertical: 20,
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000DE',
    marginVertical: 20,
    marginBottom: 25,
    alignSelf: 'center',
    // fontFamily: 'Roboto Slab',
  },
  chooseFileView: {
    marginTop: -15,
    marginBottom: 25,
  },
  chooseFiletxt: {
    textAlign: 'center',
    fontSize: 12,
    // fontFamily: 'Poppins',
    color: '#484848',
  },
  subContainerPDF: {
    borderRadius: 8,
    padding: 10,
    backgroundColor: 'white',
    width: '85%',
    borderWidth: 1,
    borderColor: '#CED4DA',

    alignSelf: 'center',
    marginBottom: 20,
  },

  pdfname: {
    alignSelf: 'center',
    fontSize: 24,
    color: '#000000DE',
    fontWeight: '700',
    marginVertical: 15,
    marginTop: 20,
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: {
      height: 3,
      width: 3,
    },
  },
  addresstxt: {
    // width: 275,
    height: 70,
    padding: 10,
  },
  addresstxtconfirm: {
    width: 250,
    height: 63,
  },

  pdfTitle: {
    fontSize: 15,
    color: '#000000CC',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  pdfdes: {
    fontSize: 16,
    color: '#000000CC',
    alignItems: 'flex-start',
    fontWeight: '700',
    marginTop: 20,
  },
  txt: {
    fontSize: 15,
    alignItems: 'flex-start',
    color: '#000000CC',
    // marginBottom: 8,
    textAlign: 'justify',
    lineHeight: 22,
  },
  footerContainer: {
    backgroundColor: 'black',
  },
  socialContainer: {
    flexDirection: 'row',
    paddingVertical: 20,
    justifyContent: 'center',
  },
  socialIcon: {
    marginHorizontal: 10,
  },
  activeDotStyle: {
    backgroundColor: 'green',
  },
  dotStyle: {
    backgroundColor: 'white',
  },
});
