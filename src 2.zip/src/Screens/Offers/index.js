import {
  Image,
  ImageBackground,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import {APP_BACK_IMAGE, BACK_ICON} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import OfferCard from '../../common/Components/OfferCard';
import offers from './offers.json';
import OfferPopUp from '../../common/Components/OfferPopUp';
// props.route.params?onAppliedCoupon
const Offers = props => {
  const {navigation} = props;
  const [selectedCoupan, setSelectedCoupan] = useState({});
  const [showOfferPopup, setShowOfferPopup] = useState(false);
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Image source={BACK_ICON} style={styles.backBtn} />
          </TouchableOpacity>
          <Text style={styles.header}>Available Coupons</Text>
          {offers?.map(item => {
            return (
              <OfferCard
                onApply={() => {
                  setSelectedCoupan(item);
                  setShowOfferPopup(true);
                }}
                key={item.id}
                offerName={item.offerName}
                offerDiscription={item.offerDiscription}
              />
            );
          })}
        </ScrollView>
        {showOfferPopup && (
          <OfferPopUp
            visible={showOfferPopup}
            isApplied={selectedCoupan?.applicable}
            code={selectedCoupan.offerName}
            discription={selectedCoupan.offerDiscription}
            onPress={() => {
              if (!selectedCoupan?.applicable) {
                navigation.goBack();
              } else if (props.route.params?.onAppliedCoupon) {
                props.route.params?.onAppliedCoupon(selectedCoupan);
                navigation.goBack();
              }
            }}
          />
        )}
        <OfferPopUp
          visible={false}
          isApplied={false}
          code={'BONZA01'}
          discription={'Your Coupon Code expired'}
        />
      </ImageBackground>
    </SafeAreaView>
  );
};

export default Offers;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  addToCart: {
    color: 'white',
    fontSize: 17,
    fontWeight: '900',
  },
  addToCartTxt: {
    marginTop: 40,
    marginBottom: 5,
    width: '100%',
    alignSelf: 'center',
    height: 52,
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: '900',
    color: '#000000DE',
    alignSelf: 'center',
    margin: 25,
  },
  backBtn: {
    height: 20,
    width: 30,
    margin: 20,
    marginLeft: 30,
    position: 'absolute',
  },
  header: {
    fontSize: 24,
    color: '#000000',
    fontWeight: 'bold',
    alignSelf: 'center',
    marginTop: 16,
    margin: 20,
  },
});
