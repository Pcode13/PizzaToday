import {
  ImageBackground,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import Header from '../../common/Components/Header';
import masterData from '../Menu/masterData.json';
import ItemCard from '../../common/Components/ItemCard';
import DealsCard from '../../common/Components/DealsCard';
import {APP_BACK_IMAGE} from '../../common/Assets/Constants';
import Loader from '../../common/Components/Loader';
import ViewCart from '../../common/Components/ViewCart';
const Tab = createMaterialTopTabNavigator();

function RenderScreen(params) {
  return (
    <ImageBackground
      source={APP_BACK_IMAGE}
      resizeMode="cover"
      style={styles.image}>
      <ScrollView showsVerticalScrollIndicator={false} bounces={true}>
        <View style={styles.cakeContainer}>
          {params?.route?.params?.itemName !== 'DEALS' &&
            params?.route?.params?.menuData?.map((item, index) => {
              return (
                <ItemCard
                  item={item}
                  isPizza={params?.route?.params?.itemName === 'PIZZAS'}
                  key={index}
                  itemName={item?.product_name}
                  imgUrl={item?.image}
                  price={item?.default_price}
                  isVeg={item?.foodType === 'veg'}
                />
              );
            })}
        </View>
        {params.route.params.itemName === 'DEALS' &&
          params.route.params?.menuData?.map((item, index) => {
            return (
              <DealsCard
                key={index}
                dealName={item?.name || ''}
                dealDiscription={item.description}
                price={item.amount}
                onPress={() =>
                  params.navigation.navigate('DealsDetails', {
                    dealsData: item,
                  })
                }
              />
            );
          })}
      </ScrollView>
    </ImageBackground>
  );
}
function MenuTab({navigation}) {
  const [menuItems, setMenuData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showViewCart, setShowViewCart] = useState(false);
  useEffect(() => {
    let dummyMenu = [];
    if (masterData?.data?.offers.length) {
      dummyMenu.push({
        itemName: 'DEALS',
        menuData: masterData?.data?.offers,
      });
    }
    if (masterData?.data?.categories?.length > 0) {
      masterData?.data?.categories.forEach((element, index) => {
        dummyMenu.push({
          itemName: element?.name,
          menuData: element.category_products,
        });
      });
    }
    setMenuData(dummyMenu);
    setLoading(false);
  }, []);
  function renderButtomBtns() {
    return (
      <View style={{flexDirection: 'row'}}>
        <TouchableOpacity style={styles.buttonBtn}>
          <Text style={styles.buttonTxt}>Your Order : 0</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setShowViewCart(true)}
          style={[styles.buttonBtn, {backgroundColor: '#25A140'}]}>
          <Text style={styles.buttonTxt}>View Cart</Text>
        </TouchableOpacity>
      </View>
    );
  }
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
      <Header navigation={navigation} />
      {!loading ? (
        <Tab.Navigator
          screenOptions={({route}) => ({
            tabBarScrollEnabled: true,
            tabBarStyle: styles.tabBarStyle,
            tabBarLabelStyle: styles.tabBarLabelStyle,
            tabBarItemStyle: styles.tabBarItemStyle,
            tabBarShowLabel: true,
            tabBarPressOpacity: 1,
            tabBarIndicatorStyle: styles.tabBarIndicatorStyle,
          })}>
          {menuItems?.map((item, index) => {
            return (
              <Tab.Screen
                initialParams={item}
                key={index}
                name={item?.itemName}
                component={RenderScreen}
                options={{tabBarLabel: item?.itemName}}
                params={item}
              />
            );
          })}
        </Tab.Navigator>
      ) : (
        <Loader loading={loading} />
      )}
      {renderButtomBtns()}
      {showViewCart && (
        <ViewCart
          visible={showViewCart}
          onHide={() => setShowViewCart(false)}
          navigation={navigation}
        />
      )}
    </SafeAreaView>
  );
}

export default MenuTab;

const styles = StyleSheet.create({
  mapcontainer: {
    height: 300,
    width: '100%',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  container: {
    flex: 1,
    backgroundColor: 'black',
    width: '100%',
  },
  cakeContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 35,
  },
  tabBarStyle: {
    height: 43,
    backgroundColor: 'black',
    borderTopWidth: 2,
    borderTopColor: 'white',
  },
  tabBarLabelStyle: {
    fontSize: 17,
    width: 'auto',
    color: 'white',
    textTransform: 'capitalize',
    paddingHorizontal: 0,
    alignSelf: 'center',
    alignContent: 'center',
    marginTop: 0,
  },
  tabBarItemStyle: {
    height: 43,
    width: 'auto',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabBarIndicatorStyle: {
    backgroundColor: '#25A140',
    height: '100%',
  },
  buttonBtn: {
    width: '50%',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'black',
  },
  buttonTxt: {
    color: 'white',
    fontSize: 17,
    fontWeight: '600',
  },
});
