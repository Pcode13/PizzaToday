import {
  Image,
  ImageBackground,
  Keyboard,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {
  APP_BACK_IMAGE,
  APP_LOGO,
  BACK_ICON,
} from '../../common/Assets/Constants';
import SubmitButton from '../../common/Components/SubmitButton';
import OTPTextView from 'react-native-otp-textinput';
import {ShowToast} from '../../common/Utils/toastUtils';
const OtpVerfication = props => {
  const {navigation} = props;
  const [otp, setOtp] = useState('');
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  const [marginTop, setMarginTop] = useState(0);
  const {initialMinute = 1, initialSeconds = 0} = props;
  const [minutes, setMinutes] = useState(initialMinute);
  const [seconds, setSeconds] = useState(initialSeconds);
  useEffect(() => {
    let myInterval = setInterval(() => {
      if (seconds > 0) {
        setSeconds(seconds - 1);
      }
      if (seconds === 0) {
        if (minutes === 0) {
          clearInterval(myInterval);
        } else {
          setMinutes(minutes - 1);
          setSeconds(59);
        }
      }
    }, 1000);
    return () => {
      clearInterval(myInterval);
    };
  });
  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => {
        setKeyboardVisible(true); // or some other action
      },
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        setKeyboardVisible(false); // or some other action
      },
    );

    return () => {
      keyboardDidHideListener.remove();
      keyboardDidShowListener.remove();
    };
  }, []);
  useEffect(() => {
    if (isKeyboardVisible) {
      setMarginTop(-70);
    } else {
      setMarginTop(0);
    }
  }, [isKeyboardVisible]);

  function renderOtpSection() {
    return (
      <>
        <Text style={styles.otpHeaderTxt}>OTP</Text>
        <OTPTextView
          containerStyle={styles.textInputContainer}
          textInputStyle={styles.roundedTextInput}
          handleTextChange={text => {
            setOtp(text);
          }}
          inputCount={6}
          keyboardType="numeric"
          tintColor={'#D0DAE4'}
          offTintColor={'#D0DAE4'}
        />
        <SubmitButton
          title={'Continue'}
          customBtnStyle={styles.continueBtn}
          onPress={() => {
            if (otp?.length === 6) {
              props.route.params?.onOtpEntered(otp);
            } else {
              ShowToast({
                type: 'error',
                text1: 'Please Enter the Otp',
              });
            }
          }}
        />
        <View style={styles.txtContainer}>
          <Text style={styles.dontTxt}>Don't received code</Text>
          {minutes === 0 && seconds === 0 ? (
            <TouchableOpacity
              onPress={() => {
                props.route.params?.onResendOtp(otp);
              }}>
              <Text style={[styles.resendTxt, {color: 'blue'}]}>Resend</Text>
            </TouchableOpacity>
          ) : (
            <Text style={styles.resendTxt}>
              Resend in {minutes}:{seconds < 10 ? `0${seconds}` : seconds}
            </Text>
          )}
        </View>
      </>
    );
  }
  return (
    <ImageBackground
      source={APP_BACK_IMAGE}
      resizeMode="cover"
      style={styles.image}>
      <SafeAreaView style={[styles.container, {marginTop}]}>
        <ScrollView showsVerticalScrollIndicator={false} bounces={true}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={styles.btnView}>
            <Image source={BACK_ICON} style={styles.backBtn} />
          </TouchableOpacity>
          <Image source={APP_LOGO} style={styles.appLogo} />
          <Text style={styles.welcomeTxt}>{'Verification'}</Text>

          <>
            <Text style={styles.subTxt}>
              Please Enter Verification Code Sent to
            </Text>
            <Text style={styles.subTxt}>
              {props.route.params?.mobileNumber || ''}
            </Text>
          </>

          <View style={styles.subContainer}>{renderOtpSection()}</View>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default OtpVerfication;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  welcomeTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 28,
    color: '#000000',
    fontWeight: 'bold',
    alignSelf: 'center',
    marginTop: 12,
  },
  subTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 14,
    color: '#000000CC',
    fontWeight: '400',
    alignSelf: 'center',
    padding: 3,
  },
  appLogo: {
    width: 88,
    height: 53,
    alignSelf: 'center',
    marginTop: 70,
  },
  subContainer: {
    padding: 30,
    backgroundColor: 'white',
    marginVertical: 30,
    width: '90%',
    borderWidth: 1,
    borderColor: '#CED4DA',
    borderRadius: 10,
    alignSelf: 'center',
  },
  btnStyle: {
    marginTop: 20,
  },
  resetBtn: {
    alignSelf: 'flex-end',
    color: '#767676',
    fontSize: 14,
    fontWeight: '600',
  },
  otpBtn: {
    backgroundColor: '#F5F5F5',
  },
  otpTxt: {
    color: '#495057',
    fontSize: 14,
    fontWeight: 'bold',
  },
  orTxt: {
    color: '#495057',
    fontWeight: 'bold',
    fontSize: 20,
    alignSelf: 'center',
    marginVertical: 30,
  },
  textInputContainer: {
    margin: 0,
    marginHorizontal: -5,
  },
  roundedTextInput: {
    height: 38,
    width: 40,
    borderRadius: 4,
    borderWidth: 1,
    color: '#495057',
    fontSize: 14,
    borderBottomWidth: 1,
  },
  dontTxt: {
    fontSize: 14,
    color: '#767676',
    fontWeight: '600',
    marginRight: 5,
  },
  resendTxt: {
    fontSize: 14,
    color: '#EA0F0E',
    fontWeight: 'bold',
  },
  txtContainer: {
    flexDirection: 'row',
    marginTop: 10,
    alignSelf: 'center',
  },
  otpHeaderTxt: {
    color: '#495057',
    fontSize: 13,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  continueBtn: {
    marginTop: 40,
  },
  backBtn: {
    height: 20,
    width: 30,
    margin: 20,
    // position: 'absolute',
  },
  btnView: {position: 'absolute', top: 0, zIndex: 2},
});
