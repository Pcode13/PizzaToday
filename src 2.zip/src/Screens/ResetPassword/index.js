import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {
  APP_BACK_IMAGE,
  APP_LOGO,
  BACK_ICON,
} from '../../common/Assets/Constants';
import TextInputWithTitle from '../../common/Components/TextInput';
import SubmitButton from '../../common/Components/SubmitButton';
import OTPTextView from 'react-native-otp-textinput';
const ResetPassword = ({navigation}) => {
  useEffect(() => {
    toggleSection(true, false, false);
  }, []);
  const [newPassword, setNewPassword] = useState('');
  const [showInputSection, setShowInputSection] = useState(true);
  const [showNewPasswordSection, setShowNewPasswordSection] = useState(false);
  const [showOtpSection, setShowOtpSection] = useState(false);
  function toggleSection(input, otp, password) {
    setShowInputSection(input);
    setShowNewPasswordSection(password);
    setShowOtpSection(otp);
  }
  function renderInputSection() {
    return (
      <>
        <TextInputWithTitle title={'Email'} placeholder={'Enter Email'} />
        <TextInputWithTitle
          title={'Mobile No.'}
          placeholder={'Enter Mobile No.'}
          secureTextEntry={true}
        />
        <SubmitButton
          title={'Send OTP'}
          customBtnStyle={styles.btnStyle}
          onPress={() => toggleSection(false, true, false)}
        />
      </>
    );
  }
  function renderNewPasswordSection() {
    return (
      <>
        <TextInputWithTitle
          value={newPassword}
          onChangeText={setNewPassword}
          title={'New Password'}
          placeholder={'Enter New Password'}
          secureTextEntry={true}
        />
        <TextInputWithTitle
          title={'Re-enter Password'}
          placeholder={'Enter New Password Again'}
          secureTextEntry={true}
        />
        <SubmitButton
          title={'Save'}
          customBtnStyle={styles.btnStyle}
          onPress={() => navigation.navigate('Login')}
        />
      </>
    );
  }
  function renderOtpSection() {
    return (
      <>
        <Text style={styles.otpHeaderTxt}>OTP</Text>
        <OTPTextView
          containerStyle={styles.textInputContainer}
          textInputStyle={styles.roundedTextInput}
          handleTextChange={text => {
            // onChangeText(text);
          }}
          inputCount={6}
          keyboardType="numeric"
          tintColor={'#D0DAE4'}
          offTintColor={'#D0DAE4'}
        />
        <SubmitButton
          title={'Continue'}
          customBtnStyle={styles.continueBtn}
          onPress={() => toggleSection(false, false, true)}
        />
        <View style={styles.txtContainer}>
          <Text style={styles.dontTxt}>Don't received code</Text>
          <Text style={styles.resendTxt}>Resend in 00:05</Text>
        </View>
      </>
    );
  }
  function handleBackPress() {
    if (showOtpSection) {
      toggleSection(true, false, false);
    } else if (showNewPasswordSection) {
      toggleSection(false, true, false);
    } else if (showInputSection) {
      navigation.goBack();
    }
  }
  return (
    <ImageBackground
      source={APP_BACK_IMAGE}
      resizeMode="cover"
      style={styles.image}>
      <SafeAreaView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
          <TouchableOpacity onPress={handleBackPress}>
            <Image source={BACK_ICON} style={styles.backBtn} />
          </TouchableOpacity>

          <Image source={APP_LOGO} style={styles.appLogo} />
          <Text style={styles.welcomeTxt}>
            {showOtpSection ? 'Verification' : 'Reset Password'}
          </Text>
          {showOtpSection && (
            <>
              <Text style={styles.subTxt}>
                Please Enter Verification Code Sent to
              </Text>
              <Text style={styles.subTxt}>Your Mobile Or Email</Text>
            </>
          )}
          <View style={styles.subContainer}>
            {showInputSection
              ? renderInputSection()
              : showOtpSection
              ? renderOtpSection()
              : renderNewPasswordSection()}
          </View>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default ResetPassword;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  welcomeTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 28,
    color: '#000000',
    fontWeight: 'bold',
    alignSelf: 'center',
    marginTop: 12,
  },
  subTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 14,
    color: '#000000CC',
    fontWeight: '400',
    alignSelf: 'center',
    padding: 3,
  },
  appLogo: {
    width: 88,
    height: 53,
    alignSelf: 'center',
    marginTop: 30,
  },
  subContainer: {
    padding: 30,
    backgroundColor: 'white',
    marginVertical: 30,
    width: '90%',
    borderWidth: 1,
    borderColor: '#CED4DA',
    borderRadius: 10,
    alignSelf: 'center',
  },
  btnStyle: {
    marginTop: 20,
  },
  resetBtn: {
    alignSelf: 'flex-end',
    color: '#767676',
    fontSize: 14,
    fontWeight: '600',
  },
  otpBtn: {
    backgroundColor: '#F5F5F5',
  },
  otpTxt: {
    color: '#495057',
    fontSize: 14,
    fontWeight: 'bold',
  },
  orTxt: {
    color: '#495057',
    fontWeight: 'bold',
    fontSize: 20,
    alignSelf: 'center',
    marginVertical: 30,
  },
  textInputContainer: {
    margin: 0,
    marginHorizontal: -5,
  },
  roundedTextInput: {
    height: 38,
    width: 40,
    borderRadius: 4,
    borderWidth: 1,
    color: '#495057',
    fontSize: 14,
    borderBottomWidth: 1,
  },
  dontTxt: {
    fontSize: 14,
    color: '#767676',
    fontWeight: '600',
    marginRight: 5,
  },
  resendTxt: {
    fontSize: 14,
    color: '#EA0F0E',
    fontWeight: 'bold',
  },
  txtContainer: {
    flexDirection: 'row',
    marginTop: 10,
    alignSelf: 'center',
  },
  otpHeaderTxt: {
    color: '#495057',
    fontSize: 13,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  continueBtn: {
    marginTop: 40,
  },
  backBtn: {
    height: 20,
    width: 30,
    margin: 20,
  },
});
