import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {
  APP_BACK_IMAGE,
  BACK_ICON,
  CALENDAR,
} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import TextInputWithTitle from '../../common/Components/TextInput';
import SubmitButton from '../../common/Components/SubmitButton';
import DatePicker from 'react-native-date-picker';
import DropShadow from 'react-native-drop-shadow';
import moment from 'moment';

const UpdateProfile = ({navigation}) => {
  const [date, setDate] = useState(new Date());
  const [open, setOpen] = useState(false);
  const [isDateSelected, setIsDateSelected] = useState(false);
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView showsVerticalScrollIndicator={false} bounces={true}>
          <View style={styles.margin30} />
          <View style={styles.topView}>
            <TouchableOpacity
              style={styles.backBtnView}
              onPress={() => navigation.goBack()}>
              <Image source={BACK_ICON} style={styles.backBtn} />
            </TouchableOpacity>
            <Text style={styles.headerTxt}>Update Profile</Text>
          </View>

          <DropShadow style={styles.shadow}>
            <View style={styles.subContainer}>
              <TextInputWithTitle
                title={'User Name'}
                placeholder={'Enter the User Name.'}
              />
              <TextInputWithTitle
                title={'Email Id'}
                placeholder={'Enter the Email Id'}
              />
              <TextInputWithTitle
                title={'Mobile No'}
                placeholder={'Enter the Mobile No'}
              />
              <Text style={styles.headerStyle}>{'Date Of Birth'}</Text>
              <TouchableOpacity
                style={styles.dateview}
                onPress={() => setOpen(true)}>
                <Text style={styles.dateTxt}>
                  {!isDateSelected
                    ? 'Select Date'
                    : moment(date).format('DD-MM-YYYY')}
                </Text>
                <Image source={CALENDAR} />
              </TouchableOpacity>
              <DatePicker
                mode={'date'}
                modal
                open={open}
                date={date}
                onConfirm={date => {
                  setIsDateSelected(true);
                  setOpen(false);
                  setDate(date);
                }}
                onCancel={() => {
                  setOpen(false);
                }}
              />
              <TextInputWithTitle
                title={'Upload Photo'}
                placeholder={'Choose File'}
              />
              <TouchableOpacity style={styles.chooseFileView}>
                <Text style={styles.chooseFiletxt}>No File Choosen</Text>
              </TouchableOpacity>
              <SubmitButton
                title={'Save Changes'}
                customBtnStyle={styles.btnStyle}
              />

              <SubmitButton
                title={'Cancel'}
                customBtnStyle={styles.otpBtn}
                customTitleStyle={styles.otpTxt}
              />
            </View>
          </DropShadow>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default UpdateProfile;

const styles = StyleSheet.create({
  backBtnView: {position: 'absolute', left: 0, marginLeft: 20},
  topView: {flexDirection: 'row', justifyContent: 'center'},
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  margin30: {
    marginBottom: 30,
  },
  otpBtn: {
    backgroundColor: '#F5F5F5',
  },
  otpTxt: {
    color: '#495057',
  },
  btnStyle: {
    marginBottom: 10,
  },
  chooseFileView: {
    marginTop: -15,
    marginBottom: 25,
  },
  chooseFiletxt: {
    textAlign: 'center',
  },
  dateTxt: {
    fontSize: 14,
    fontWeight: '500',
    color: '#495057',
  },
  dateview: {
    borderWidth: 1,
    height: 38,
    borderRadius: 8,
    borderColor: '#CED4DA',
    paddingHorizontal: 10,
    marginTop: 8,
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
    backgroundColor: 'white',
    width: '100%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  headerStyle: {
    color: '#495057',
    fontSize: 13,
    fontWeight: 'bold',
  },
  subContainer: {
    padding: 15,
    backgroundColor: 'white',

    width: '85%',
    borderWidth: 1,
    borderColor: '#CED4DA',

    alignSelf: 'center',
    marginBottom: 20,
    borderRadius: 8,
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: {
      height: 3,
      width: 3,
    },
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000DE',
    // marginVertical: 0,
    marginBottom: 15,
    alignSelf: 'center',
    // fontFamily: 'Roboto Slab',
    // position: 'absolute',
    alignItems: 'center',
  },
  backBtn: {
    height: 20,
    width: 30,
    // margin: 20,
    position: 'absolute',
  },
});
