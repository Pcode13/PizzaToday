import {
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {APP_BACK_IMAGE, GREEN_CHECK} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import DealsCard from '../../common/Components/DealsCard';
import ItemCard from '../../common/Components/ItemCard';
import cakeData from './cakeData.json';
import sidesData from './sidesData.json';
import burgerData from './burgerData.json';
import DealsSubCard from '../../common/Components/DealsSubCard';
import ViewCart from '../../common/Components/ViewCart';
import RenderMenuItem from '../../common/Components/RenderMenuItem';
import {useSwipe} from '../../common/Utils/Swipe';
import Loader from '../../common/Components/Loader';
import masterData from './masterData.json';
const Menu = ({navigation}) => {
  const [menuItems, setMenuData] = useState([]);
  const [selected, setSelected] = useState(
    menuItems.length ? menuItems[0].itemName : '',
  );
  const [showViewCart, setShowViewCart] = useState(false);
  const {onTouchStart, onTouchEnd} = useSwipe(onSwipeLeft, onSwipeRight, 6);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 2000);
    console.log('masterData', masterData);
    let dummyMenu = [];
    if (masterData?.data?.offers.length) {
      dummyMenu.push({
        itemName: 'DEALS',
        menuData: masterData?.data?.offers,
      });
    }
    console.log(
      'masterData?.data?.categories?.length',
      masterData?.data?.categories,
    );
    if (masterData?.data?.categories?.length > 0) {
      masterData?.data?.categories.forEach(element => {
        dummyMenu.push({
          itemName: element?.name,
          menuData: element.category_products,
        });
      });
    }
    setMenuData(dummyMenu);
    setSelected(dummyMenu[0]);
  }, []);

  function onSwipeLeft() {
    // let next =
    //   parseInt(menuItems.find(item => item.itemName === selected)?.id ?? 0) + 1;
    // setSelected(
    //   menuItems?.find(item => parseInt(item?.id) === next)?.itemName ??
    //     selected,
    // );
  }

  function onSwipeRight() {
    // let prev =
    //   parseInt(menuItems.find(item => item.itemName === selected)?.id || 0) - 1;
    // setSelected(
    //   menuItems?.find(item => parseInt(item?.id) === prev)?.itemName ||
    //     selected,
    // );
  }
  function renderButtomBtns() {
    return (
      <View style={{flexDirection: 'row'}}>
        <TouchableOpacity style={styles.buttonBtn}>
          <Text style={styles.buttonTxt}>Your Order : 0</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setShowViewCart(true)}
          style={[styles.buttonBtn, {backgroundColor: '#25A140'}]}>
          <Text style={styles.buttonTxt}>View Cart</Text>
        </TouchableOpacity>
      </View>
    );
  }
  function renderNavBar() {
    return (
      <View style={styles.navContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {menuItems.map((item, index) => {
            return (
              <RenderMenuItem
                key={index}
                title={item.itemName}
                selecteItem={selected.itemName === item.itemName}
                onPress={() => {
                  setSelected(item);
                }}
              />
            );
          })}
        </ScrollView>
      </View>
    );
  }
  function renderDeals() {
    return (
      <>
        <DealsCard onPress={() => navigation.navigate('DealsDetails')} />
        <DealsCard onPress={() => navigation.navigate('DealsDetails')} />
        <DealsCard onPress={() => navigation.navigate('DealsDetails')} />
        <DealsCard onPress={() => navigation.navigate('DealsDetails')} />
      </>
    );
  }
  function renderCakes() {
    return (
      <View style={styles.cakeContainer}>
        {cakeData.map((item, index) => {
          return (
            <ItemCard
              key={index}
              itemName={item?.cakeName}
              imgUrl={item?.imgUrl}
              price={item?.price}
              isVeg={item?.foodType === 'veg'}
            />
          );
        })}
      </View>
    );
  }
  function renderSides() {
    return (
      <View style={styles.cakeContainer}>
        {sidesData?.map((item, index) => {
          return (
            <ItemCard
              key={index}
              itemName={item?.cakeName}
              imgUrl={item?.imgUrl}
              price={item?.price}
              isVeg={item?.foodType === 'veg'}
            />
          );
        })}
      </View>
    );
  }
  function renderBurgers() {
    return (
      <View style={styles.cakeContainer}>
        {burgerData?.map((item, index) => {
          return (
            <ItemCard
              key={index}
              itemName={item?.cakeName}
              imgUrl={item?.imgUrl}
              price={item?.price}
              isVeg={item?.foodType === 'veg'}
            />
          );
        })}
      </View>
    );
  }
  function renderPizza() {
    return (
      <View style={styles.cakeContainer}>
        {burgerData?.map((item, index) => {
          return (
            <ItemCard
              isPizza={true}
              key={index}
              itemName={'SIMPLY VEG PIZZA'}
              imgUrl={
                'https://pizzatoday.in/public/web/product/ITALIAN_PIZZA.png'
              }
              price={'220'}
              isVeg={true}
            />
          );
        })}
      </View>
    );
  }
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        {renderNavBar()}
        <ScrollView
          onTouchStart={onTouchStart}
          onTouchEnd={onTouchEnd}
          showsVerticalScrollIndicator={false}
          bounces={true}>
          <View style={{marginBottom: 35}} />
          {/* {selected === 'Deal' && renderDeals()}
          {selected === 'Pizza' && renderPizza()}
          {selected === 'Burgers' && renderBurgers()}
          {selected === 'Sides' && renderSides()}
          {selected === 'Cakes..' && renderCakes()} */}
          <View style={styles.cakeContainer}>
            {menuItems.length > 1 &&
              selected.itemName !== 'DEALS' &&
              selected?.menuData?.map((item, index) => {
                return (
                  <ItemCard
                    isPizza={selected?.itemName === 'PIZZAS'}
                    key={index}
                    itemName={item?.product_name}
                    imgUrl={item?.image}
                    price={item?.default_price}
                    isVeg={item?.foodType === 'veg'}
                  />
                );
              })}
          </View>
          {menuItems.length > 1 &&
            selected.itemName === 'DEALS' &&
            selected?.menuData?.map((item, index) => {
              return (
                <DealsCard
                  dealName={item?.name || ''}
                  dealDiscription={item.description}
                  price={item.amount}
                  onPress={() => navigation.navigate('DealsDetails')}
                />
              );
            })}
        </ScrollView>
        {renderButtomBtns()}
        <ViewCart
          visible={showViewCart}
          onHide={() => setShowViewCart(false)}
          navigation={navigation}
        />
        {loading && <Loader loading={loading} />}
      </ImageBackground>
    </SafeAreaView>
  );
};

export default Menu;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  buttonBtn: {
    width: '50%',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'black',
  },
  buttonTxt: {
    color: 'white',
    fontSize: 17,
    fontWeight: '600',
  },
  navContainer: {
    flexDirection: 'row',
    width: '100%',
    backgroundColor: 'black',
    borderTopWidth: 2,
    borderTopColor: 'white',
    // marginBottom: 35,
  },
  cakeContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
});
