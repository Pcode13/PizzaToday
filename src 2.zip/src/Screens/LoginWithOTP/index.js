import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {
  APP_BACK_IMAGE,
  APP_LOGO,
  BACK_ICON,
} from '../../common/Assets/Constants';
import TextInputWithTitle from '../../common/Components/TextInput';
import SubmitButton from '../../common/Components/SubmitButton';
import {
  getRegistredUsers,
  setLoggedUserData,
} from '../../common/Utils/localStrorageUtils';
import {ShowToast} from '../../common/Utils/toastUtils';
const LoginWithOTP = ({navigation, route}) => {
  const [userData, setUserData] = useState([]);
  const [emailPhone, setEmailPhone] = useState('');
  const [emailPhoneError, setEmailPhoneError] = useState('');
  useEffect(() => {
    getRegistredUsers()
      .then(res => {
        setUserData(res);
      })
      .catch(e => {
        console.log('e', e);
      });
  }, []);
  function getUser() {
    return userData?.find(item => item?.mobileNo === emailPhone) || {};
  }
  function verifyOtp(user, otp) {
    if (otp === '123456') {
      ShowToast({
        type: 'success',
        text1: 'Login Successfully',
      });
      setLoggedUserData(user).then(res => {
        if (res === 'success') {
          if (route?.params?.onLogin) {
            route?.params?.onLogin();
          } else {
            navigation.navigate('Home');
          }
        } else {
          ShowToast({
            type: 'error',
            text1: 'Login Failed',
          });
        }
      });
    } else {
      ShowToast({
        type: 'error',
        text1: 'Invalid OTP',
      });
    }
  }
  function showUserNotExist() {
    ShowToast({
      type: 'error',
      text1: 'Mobile number not Registred',
      text2: 'Please Create an Account',
    });
  }
  function handleLoginWithOTP() {
    if (emailPhone === '') {
      setEmailPhoneError('This Field is Requried');
    } else {
      let user = getUser();
      if (Object.keys(user).length !== 0) {
        navigation.navigate('OtpVerfication', {
          mobileNumber: '9742519103',
          onOtpEntered: otp => {
            verifyOtp(user, otp);
          },
        });
      } else {
        showUserNotExist();
      }
    }
  }
  function renderInputSection() {
    return (
      <>
        <TextInputWithTitle
          error={emailPhoneError !== ''}
          errorMsg={emailPhoneError}
          value={emailPhone}
          onChangeText={setEmailPhone}
          isMobile={true}
          title={'Mobile No.'}
          placeholder={'Enter Mobile No.'}
        />
        <SubmitButton
          title={'Send OTP'}
          customBtnStyle={styles.btnStyle}
          onPress={handleLoginWithOTP}
        />
      </>
    );
  }
  function handleBackPress() {
    navigation.goBack();
  }
  return (
    <ImageBackground
      source={APP_BACK_IMAGE}
      resizeMode="cover"
      style={styles.image}>
      <SafeAreaView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
          <TouchableOpacity onPress={handleBackPress}>
            <Image source={BACK_ICON} style={styles.backBtn} />
          </TouchableOpacity>

          <Image source={APP_LOGO} style={styles.appLogo} />
          <Text style={styles.welcomeTxt}>Welcome Back!</Text>
          <Text style={styles.subTxt}>Enter Your Mobile Number</Text>
          <View style={styles.subContainer}>{renderInputSection()}</View>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default LoginWithOTP;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  welcomeTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 28,
    color: '#000000',
    fontWeight: 'bold',
    alignSelf: 'center',
    marginTop: 12,
  },
  subTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 14,
    color: '#000000CC',
    fontWeight: '400',
    alignSelf: 'center',
    padding: 3,
  },
  appLogo: {
    width: 88,
    height: 53,
    alignSelf: 'center',
    marginTop: 30,
  },
  subContainer: {
    padding: 30,
    backgroundColor: 'white',
    marginVertical: 30,
    width: '90%',
    borderWidth: 1,
    borderColor: '#CED4DA',
    borderRadius: 10,
    alignSelf: 'center',
  },
  btnStyle: {
    marginTop: 20,
  },
  resetBtn: {
    alignSelf: 'flex-end',
    color: '#767676',
    fontSize: 14,
    fontWeight: '600',
  },
  otpBtn: {
    backgroundColor: '#F5F5F5',
  },
  otpTxt: {
    color: '#495057',
    fontSize: 14,
    fontWeight: 'bold',
  },
  orTxt: {
    color: '#495057',
    fontWeight: 'bold',
    fontSize: 20,
    alignSelf: 'center',
    marginVertical: 30,
  },
  textInputContainer: {
    margin: 0,
    marginHorizontal: -5,
  },
  roundedTextInput: {
    height: 38,
    width: 40,
    borderRadius: 4,
    borderWidth: 1,
    color: '#495057',
    fontSize: 14,
    borderBottomWidth: 1,
  },
  dontTxt: {
    fontSize: 14,
    color: '#767676',
    fontWeight: '600',
    marginRight: 5,
  },
  resendTxt: {
    fontSize: 14,
    color: '#EA0F0E',
    fontWeight: 'bold',
  },
  txtContainer: {
    flexDirection: 'row',
    marginTop: 10,
    alignSelf: 'center',
  },
  otpHeaderTxt: {
    color: '#495057',
    fontSize: 13,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  continueBtn: {
    marginTop: 40,
  },
  backBtn: {
    height: 20,
    width: 30,
    margin: 20,
  },
});
