import {
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React from 'react';
import {APP_BACK_IMAGE} from '../../common/Assets/Constants';
import SubmitButton from '../../common/Components/SubmitButton';
import Header from '../../common/Components/Header';
import ProductItem from '../../common/Components/ProductItem';
import ItemCard from '../../common/Components/ItemCard';
import cakeData from '../Menu/sidesData.json';
const Cart = ({navigation}) => {
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
          <View style={styles.space} />
          <ProductItem />
          <ProductItem />
          <ProductItem />
          <ProductItem />
          <ProductItem />
          <ProductItem />
          <ProductItem />
          <ProductItem />
        </ScrollView>
        <View style={styles.mainView}>
          <Text style={styles.likeTxt}>You may also like</Text>
          <ScrollView
            horizontal
            style={styles.height}
            showsHorizontalScrollIndicator={false}>
            <View style={[styles.cakeContainer]}>
              {[...cakeData].map((item, index) => {
                return (
                  <ItemCard
                    key={index}
                    itemName={item?.cakeName}
                    imgUrl={item?.imgUrl}
                    price={item?.price}
                    isVeg={item?.foodType === 'veg'}
                    isSmallCard={true}
                  />
                );
              })}
            </View>
          </ScrollView>
          <View style={styles.proceedBtnView}>
            <View style={styles.priceView}>
              <Text style={styles.totalTxt}>Total</Text>
              <Text style={styles.price}>₹ 599</Text>
            </View>
            <SubmitButton
              onPress={() => navigation.navigate('CheckOut')}
              customTitleStyle={styles.addToCart}
              customBtnStyle={styles.addToCartTxt}
              title={'Proceed To Checkout'}
            />
          </View>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default Cart;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  mainView: {
    borderWidth: 2,
    borderColor: 'green',
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
  },
  height: {height: 120},
  image: {
    width: '100%',
    height: '100%',
  },
  cakeContainer: {
    // flexDirection: 'row',
    flexWrap: 'wrap',
    // height: 130,
  },
  priceView: {
    flexDirection: 'row',
    width: '80%',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  totalTxt: {
    fontSize: 15,
    fontWeight: '500',
    color: '#212121',
  },
  price: {
    fontSize: 13,
    fontWeight: '800',
    color: '#000000',
  },
  addToCart: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    // height: 40,
  },
  addToCartTxt: {
    marginBottom: 5,
    width: '90%',
    alignSelf: 'center',
    height: 40,
  },
  proceedBtnView: {
    // height: 100,
    // backgroundColor: 'white',
    // borderWidth: 1,
    borderColor: '#CED4DA',
    alignItems: 'center',
    justifyContent: 'center',
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
    marginHorizontal: 1,
  },
  likeTxt: {
    fontSize: 16,
    color: '#000000DE',
    fontWeight: 'bold',
    marginVertical: 12,
    alignSelf: 'center',
  },
  space: {
    height: 15,
  },
});
