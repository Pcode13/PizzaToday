import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {APP_BACK_IMAGE, BACK_ICON} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import DealsCard from '../../common/Components/DealsCard';
import DealsSubCard from '../../common/Components/DealsSubCard';

const DealsDetails = props => {
  const {navigation} = props;
  console.log('propsprops', props);
  const dealsData = props.route.params?.dealsData || {};
  const [showAddDeal, setShowAddDeal] = useState(false);
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <TouchableOpacity
          style={styles.backBtnView}
          onPress={() => navigation.goBack()}>
          <Image source={BACK_ICON} style={styles.backBtn} />
        </TouchableOpacity>
        <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
          <View>
            <DealsCard
              dealName={dealsData?.name}
              dealDiscription={dealsData?.description}
              price={dealsData?.amount}
              disabled={true}
              customStyle={styles.dealCard}
            />
            {dealsData?.items?.map((item, index) => {
              return (
                <DealsSubCard
                  key={index}
                  onItemAdd={item => {
                    setShowAddDeal(true);
                  }}
                  onDelete={() => setShowAddDeal(false)}
                  dealItem={
                    item?.menus?.length === 1
                      ? `${item?.menus[0]?.product.product_name} - Free`
                      : 'Choose a Option'
                  }
                  isIncluded={item?.menus?.length === 1}
                  menuData={item?.menus}
                />
              );
            })}
            {showAddDeal && (
              <TouchableOpacity style={styles.addDealBtn}>
                <Text style={styles.addDealTxt}>Add deal to cart</Text>
                <Text style={styles.addDealTxt}>₹ 399</Text>
              </TouchableOpacity>
            )}
          </View>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default DealsDetails;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  addDealTxt: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    textTransform: 'capitalize',
  },
  addDealBtn: {
    width: '85%',
    height: 50,
    backgroundColor: 'green',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    alignSelf: 'center',
    paddingHorizontal: 20,
    borderRadius: 8,
    marginTop: 20,
    marginBottom: 20,
  },
  dealCard: {marginTop: 20},
  backBtn: {
    height: 20,
    width: 30,
    marginLeft: 10,
    marginTop: 20,
    // position: 'absolute',
  },
});
