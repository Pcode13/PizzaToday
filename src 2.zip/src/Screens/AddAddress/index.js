import {
  ImageBackground,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import {APP_BACK_IMAGE} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import SubmitButton from '../../common/Components/SubmitButton';
import TextInputWithTitle from '../../common/Components/TextInput';

const AddAddress = ({navigation}) => {
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
          <Text style={styles.headerTxt}>Enter Address Details</Text>
          <View style={styles.addressView}>
            <TextInputWithTitle
              customStyle={styles.addressFiels}
              multiline={true}
              numberOfLines={4}
              title={'Address'}
              placeholder={'Enter Address'}
            />
            <TextInputWithTitle
              title={'Landmark'}
              placeholder={'Enter Landmark'}
            />
            <SubmitButton
              onPress={() => {
                null;
              }}
              customTitleStyle={styles.addToCart}
              customBtnStyle={styles.addToCartTxt}
              title={'Add Address'}
            />
          </View>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default AddAddress;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  addToCart: {
    color: 'white',
    fontSize: 17,
    fontWeight: 'bold',
  },
  addToCartTxt: {
    marginTop: 40,
    marginBottom: 5,
    width: '100%',
    alignSelf: 'center',
    height: 52,
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000DE',
    alignSelf: 'center',
    margin: 25,
  },
  addressView: {
    width: '85%',
    alignSelf: 'center',
    paddingHorizontal: 12,
  },
  addressFiels: {height: 70, paddingTop: 10},
});
