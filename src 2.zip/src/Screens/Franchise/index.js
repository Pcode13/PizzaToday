import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {APP_BACK_IMAGE, PDFICON} from '../../common/Assets/Constants';
import TextInputWithTitle from '../../common/Components/TextInput';
import SubmitButton from '../../common/Components/SubmitButton';
import Recaptca from '../../common/Components/Recaptca';
import DropShadow from 'react-native-drop-shadow';
import Header from '../../common/Components/Header';

const Franchise = ({navigation}) => {
  const [captchaVerified, setCaptchaVerified] = useState(false);
  return (
    <ImageBackground
      source={APP_BACK_IMAGE}
      resizeMode="cover"
      style={styles.image}>
      <SafeAreaView style={styles.container}>
        <Header navigation={navigation} />
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <ScrollView showsVerticalScrollIndicator={false}>
          <Text style={styles.headerTxt}>Franchise Enquiry Form</Text>
          <DropShadow style={styles.shadow}>
            <View style={styles.subContainer}>
              <TextInputWithTitle
                title={'User Name'}
                placeholder={'Enter User Name'}
              />
              <TextInputWithTitle
                title={'Email Id.'}
                placeholder={'Enter Email Id'}
              />
              <TextInputWithTitle
                isMobile={true}
                title={'Mobile No.'}
                placeholder={'Enter Mobile No'}
              />
              <TextInputWithTitle
                title={'Comment'}
                placeholder={'Enter the Comment'}
              />
              <TextInputWithTitle
                title={'Address'}
                placeholder={'Enter Address'}
                customStyle={styles.addresstxt}
                multiline={true}
                numberOfLines={4}
              />
              <TextInputWithTitle
                title={'Address'}
                placeholder={'Store Location Where You Want to Open'}
                secureTextEntry={true}
              />
              <TouchableOpacity style={styles.chooseFileView}>
                <Text style={styles.chooseFiletxt}>
                  + Choose files (No File Choosen).
                </Text>
              </TouchableOpacity>

              <Recaptca onVerfied={() => setCaptchaVerified(true)} />
              <SubmitButton
                title={'Send'}
                customBtnStyle={styles.btnStyle}
                onPress={() => navigation.navigate('Home')}
              />
            </View>
          </DropShadow>
          <DropShadow style={styles.shadow}>
            <View style={styles.subContainerPDF}>
              <Image style={styles.pdfimg} source={PDFICON} />
              <Text style={styles.pdfname}> Download Brochure</Text>
            </View>
          </DropShadow>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default Franchise;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: '100%',
  },

  subTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 14,
    color: '#090909',
    fontWeight: '600',
    alignSelf: 'center',
    marginTop: 10,
  },
  appLogo: {
    width: 88,
    height: 53,
    alignSelf: 'center',
    marginTop: 30,
  },
  subContainer: {
    backgroundColor: 'white',
    marginVertical: 30,
    width: '85%',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#CED4DA',

    alignSelf: 'center',
    padding: 15,
  },
  btnStyle: {
    marginTop: 5,
  },
  recaptcaView: {
    height: 67,
    borderWidth: 1,
    borderColor: '#CED4DA',
    backgroundColor: '#F9F9F9',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    marginBottom: 20,
  },
  checkBtn: {
    height: 30,
    width: 30,
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: '#CED4DA',
    borderRadius: 5,
  },
  captcaIcon: {
    width: 60,
    height: 60,
  },
  otpBtn: {
    backgroundColor: '#F5F5F5',
  },
  otpTxt: {
    color: '#495057',
    fontSize: 14,
    fontWeight: 'bold',
  },
  orTxt: {
    color: '#495057',
    fontWeight: 'bold',
    fontSize: 20,
    alignSelf: 'center',
    marginVertical: 20,
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000DE',
    // marginVertical: 30,
    marginTop: 20,
    alignSelf: 'center',
    // fontFamily: 'Roboto Slab',
  },
  chooseFileView: {
    marginTop: -15,
    marginBottom: 25,
  },
  chooseFiletxt: {
    textAlign: 'center',
    fontSize: 12,
    // fontFamily: 'Poppins',
    color: '#484848',
  },
  subContainerPDF: {
    padding: 25,
    backgroundColor: 'white',

    width: '85%',
    borderWidth: 1,
    borderColor: '#CED4DA',

    alignSelf: 'center',
    marginBottom: 20,
  },
  pdfimg: {
    alignSelf: 'center',
    marginBottom: 8,
  },
  pdfname: {
    alignSelf: 'center',
    fontSize: 17,
    color: '#000000CC',
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: {
      height: 3,
      width: 3,
    },
  },
  addresstxt: {
    // width: 275,
    height: 70,
    padding: 10,
  },
  addresstxtconfirm: {
    width: 250,
    height: 63,
  },
});
