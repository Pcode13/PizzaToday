import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {
  APP_BACK_IMAGE,
  APP_LOGO,
  BACK_ICON,
  CALENDAR,
} from '../../common/Assets/Constants';
import TextInputWithTitle from '../../common/Components/TextInput';
import SubmitButton from '../../common/Components/SubmitButton';
import Recaptca from '../../common/Components/Recaptca';
import {isValidEmailId, isValidMobileNumber} from '../../common/utils';
import {ShowToast} from '../../common/Utils/toastUtils';
import ImagePickerComp from '../../common/Components/ImagePicker';
import container from '../../Container/AuthContainer';
import {compose} from 'recompose';
import DatePicker from 'react-native-date-picker';
import moment from 'moment';

const Register = props => {
  const {navigation, register} = props;
  const [userName, setUserName] = useState('');
  const [userNameError, setUserNameError] = useState('');
  const [emailId, setEmailId] = useState('');
  const [emailIdError, setEmailIdError] = useState('');
  const [mobileNo, setMobileNo] = useState('');
  const [mobileNoError, setMobileNoError] = useState('');
  const [landmark, setLandmark] = useState('');
  const [landmarkError, setLandmarkError] = useState('');
  const [address, setAddress] = useState('');
  const [addressError, setAddressError] = useState('');
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');
  const [captchaVerified, setCaptchaVerified] = useState(false);
  const [error, setError] = useState('');
  const [isMobileNumberVerified, setIsMobileNumberVerified] = useState(false);
  const [isEmailVerified, setIsEmailVerified] = useState(false);
  const [image, setImage] = useState('');
  const [date, setDate] = useState(new Date());
  const [open, setOpen] = useState(false);
  const [isDateSelected, setIsDateSelected] = useState(false);
  const nonRequriedFields = ['emailId'];
  function validateFields() {
    let isError = false;
    const validEmailId = isValidEmailId(emailId);
    const validMobileNo = isValidMobileNumber(mobileNo);
    if (userName === '') {
      setUserNameError('Please Enter User Name');
      isError = true;
    } else {
      setUserNameError('');
    }
    if (!nonRequriedFields.includes('emailId') && emailId === '') {
      setEmailIdError('Please Enter Email Id');
      isError = true;
    } else if (
      !nonRequriedFields.includes('emailId') &&
      !validEmailId.isEmailValid
    ) {
      setEmailIdError(validEmailId.errorMessage);
    } else {
      setEmailIdError('');
    }
    if (landmark === '') {
      setLandmarkError('Please Enter Landmark');
      isError = true;
    } else {
      setLandmarkError('');
    }
    if (address === '') {
      setAddressError('Please Enter Address');
      isError = true;
    } else {
      setAddressError('');
    }
    if (mobileNo === '') {
      setMobileNoError('Please Enter Mobile number');
      isError = true;
    } else if (!validMobileNo.isMobileNoValid) {
      setMobileNoError(validMobileNo.errorMessage);
      isError = true;
    } else {
      setMobileNoError('');
    }
    if (password === '') {
      setPasswordError('Please Enter Password');
      isError = true;
    } else {
      setPasswordError('');
    }
    if (confirmPassword === '') {
      setConfirmPasswordError('Please Enter Password Again');
      isError = true;
    } else {
      setConfirmPasswordError('');
    }
    if (confirmPassword !== password) {
      isError = true;
    }
    return !isError;
  }
  useEffect(() => {
    if (password !== '' && confirmPassword !== '') {
      if (password !== confirmPassword) {
        setConfirmPasswordError('Password Not matching');
      } else {
        setConfirmPasswordError('');
      }
    }
  }, [password, confirmPassword]);
  function saveUserData() {
    const params = {
      name: userName,
      email: emailId,
      mobile: mobileNo,
      dob: moment(date).format('YYYY-MM-DD'),
      landmark: landmark,
      address: address,
      image: image?.assets?.length ? image?.assets[0]?.base64 : '',
      password: password,
      password_confirmation: confirmPassword,
    };
    console.log('datadata', params);
    register({
      params,
      onSuccess: response => {
        if (response?.status === 1) {
          ShowToast({
            type: 'success',
            text1: 'Registration is SuccessFul',
            text2: 'Please login to continue',
          });
          navigation.push('Login');
        }
      },
      onFailure: e => {
        console.log('error', e);
      },
    });
  }
  function needToVerifyEmail() {
    return false;
    // if (emailId === '') {
    //   return false;
    // } else {
    //   return !isEmailVerified;
    // }
  }
  function onSubmit() {
    if (validateFields()) {
      if (isMobileNumberVerified) {
        if (!needToVerifyEmail()) {
          if (captchaVerified) {
            saveUserData();
          } else {
            setError('Please Verify  ReCAPTCHA');
          }
        } else {
          setError('Please Verify Email');
        }
      } else {
        setError('Please Verify mobile number');
      }
    }
  }
  function checkForCaptchAndMobileVerify() {
    let errorMsg = !isMobileNumberVerified || !captchaVerified ? 'Verify' : '';
    if (isMobileNumberVerified) {
      errorMsg += '';
    } else {
      errorMsg += ' Mobile Number';
    }
    if (captchaVerified) {
      errorMsg += '';
    } else {
      errorMsg += ' ReCAPTCHA';
    }
    setError(errorMsg);
    return isMobileNumberVerified && captchaVerified;
  }
  useEffect(() => {
    if (error !== '') {
      checkForCaptchAndMobileVerify();
    }
  }, [isMobileNumberVerified, captchaVerified]);

  function otpVerificationFailed(errorMsg) {
    ShowToast({
      type: 'error',
      text1: errorMsg || 'Invalid OTP',
    });
  }
  function verifyOtp(mobileNumber, otp) {
    props.verifyOtp({
      params: {
        mobile: mobileNumber,
        otp: otp,
      },
      onSuccess: response => {
        if (response?.status === 1) {
          navigation.goBack();
          ShowToast({
            type: 'success',
            text1: response?.message || 'OTP Verified for Mobile',
          });
          setIsMobileNumberVerified(true);
        } else {
          otpVerificationFailed();
        }
      },
      onFailure: err => {
        otpVerificationFailed(err?.message || 'OTP Not Verified');
      },
    });
  }
  function verifyEmailOtp(otp) {
    if (otp === '123456') {
      ShowToast({
        type: 'success',
        text1: 'OTP Verified for Email',
      });
      navigation.goBack();
      setIsEmailVerified(true);
    } else {
      ShowToast({
        type: 'error',
        text1: 'Invalid OTP',
      });
    }
  }
  function handleResendOtp(mobileNumber) {
    props.sendOtp({
      params: {
        mobile: mobileNumber,
      },
      onSuccess: response => {
        if (response?.status === 1) {
          ShowToast({
            type: 'success',
            text1: 'Otp Resend Successfully',
          });
        } else {
          ShowToast({
            type: 'error',
            text1: 'Error in OTP Sending',
          });
        }
      },
      onFailure: err => {
        ShowToast({
          type: 'error',
          text1: err?.message || 'Error in OTP Sending',
        });
      },
    });
  }
  function handleVerifyPress() {
    props.sendOtp({
      params: {
        mobile: mobileNo,
      },
      onSuccess: response => {
        if (response?.status === 1) {
          navigation.navigate('OtpVerfication', {
            mobileNumber: mobileNo,
            onOtpEntered: otp => {
              verifyOtp(mobileNo, otp);
            },
            onResendOtp: () => {
              handleResendOtp(mobileNo);
            },
          });
        } else {
          ShowToast({
            type: 'error',
            text1: 'Error in OTP Sending',
          });
        }
      },
      onFailure: err => {
        ShowToast({
          type: 'error',
          text1: err?.message || 'Error in OTP Sending',
        });
      },
    });
  }
  function handleVerifyEmailPress() {
    navigation.navigate('OtpVerfication', {
      mobileNumber: emailId,
      onOtpEntered: otp => {
        verifyEmailOtp(otp);
      },
    });
  }
  function rightMobileTxt() {
    if (isValidMobileNumber(mobileNo).isMobileNoValid) {
      return isMobileNumberVerified ? 'Verified' : 'Verfiy';
    }
    return '';
  }
  function rightEmailTxt() {
    if (isValidEmailId(emailId).isEmailValid) {
      // return isEmailVerified ? 'Verified' : 'Verfiy';
      return '';
    }
    return '';
  }
  return (
    <ImageBackground
      source={APP_BACK_IMAGE}
      resizeMode="cover"
      style={styles.image}>
      <SafeAreaView style={styles.container}>
        <TouchableOpacity
          style={styles.backBtnView}
          onPress={() => navigation.goBack()}>
          <Image source={BACK_ICON} style={styles.backBtn} />
        </TouchableOpacity>
        <ScrollView showsVerticalScrollIndicator={false}>
          <Image source={APP_LOGO} style={styles.appLogo} />
          <Text style={styles.welcomeTxt}>Welcome!</Text>
          <Text style={styles.subTxt}>Create Your Account</Text>
          <View style={styles.subContainer}>
            <TextInputWithTitle
              errorMsg={userNameError}
              error={userNameError !== ''}
              value={userName}
              onChangeText={setUserName}
              title={'User Name'}
              placeholder={'Enter User Name'}
            />
            <TextInputWithTitle
              errorMsg={emailIdError}
              error={emailIdError !== ''}
              value={emailId}
              onChangeText={setEmailId}
              title={'Email Id.'}
              placeholder={'Enter Email Id'}
              rightTxt={rightEmailTxt()}
              onRightTxtPress={handleVerifyEmailPress}
              rightTxtDisabled={isEmailVerified}
              editable={!isEmailVerified}
              onRightTxtColor={isEmailVerified ? 'green' : 'blue'}
            />
            <TextInputWithTitle
              errorMsg={mobileNoError}
              error={mobileNoError !== ''}
              value={mobileNo}
              onChangeText={setMobileNo}
              keyboardType={'numeric'}
              isMobile={true}
              title={'Mobile No.'}
              placeholder={'Enter Mobile No'}
              rightTxt={rightMobileTxt()}
              onRightTxtPress={handleVerifyPress}
              rightTxtDisabled={isMobileNumberVerified}
              editable={!isMobileNumberVerified}
              onRightTxtColor={isMobileNumberVerified ? 'green' : 'blue'}
            />
            <Text style={styles.headerStyle}>{'Date Of Birth'}</Text>
            <TouchableOpacity
              style={styles.dateview}
              onPress={() => setOpen(true)}>
              <Text style={styles.dateTxt}>
                {!isDateSelected
                  ? 'Select Date'
                  : moment(date).format('YYYY-MM-DD')}
              </Text>
              <Image source={CALENDAR} />
            </TouchableOpacity>
            <DatePicker
              mode={'date'}
              modal
              open={open}
              date={date}
              onConfirm={d => {
                setIsDateSelected(true);
                setOpen(false);
                setDate(d);
              }}
              onCancel={() => {
                setOpen(false);
              }}
            />
            <TextInputWithTitle
              errorMsg={landmarkError}
              error={landmarkError !== ''}
              value={landmark}
              onChangeText={setLandmark}
              title={'Landmark'}
              placeholder={'Enter Landmark'}
            />
            <TextInputWithTitle
              errorMsg={addressError}
              error={addressError !== ''}
              value={address}
              onChangeText={setAddress}
              title={'Address'}
              placeholder={'Enter Address'}
            />
            <TextInputWithTitle
              errorMsg={passwordError}
              error={passwordError !== ''}
              value={password}
              onChangeText={setPassword}
              title={'Password'}
              placeholder={'Enter Password'}
              secureTextEntry={true}
            />
            <TextInputWithTitle
              errorMsg={confirmPasswordError}
              error={confirmPasswordError !== ''}
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              title={'Confirm Password'}
              placeholder={'Enter Password Again'}
              secureTextEntry={true}
            />
            <ImagePickerComp onImageCapture={data => setImage(data)} />
            <Recaptca onVerfied={() => setCaptchaVerified(true)} />
            {error && <Text style={styles.errorMsg}>{error}</Text>}
            <SubmitButton
              title={'Submit'}
              customBtnStyle={styles.btnStyle}
              onPress={onSubmit}
            />
            <Text style={styles.orTxt}>OR</Text>
            <SubmitButton
              onPress={() => navigation.navigate('Login')}
              title={'Login'}
              customBtnStyle={styles.otpBtn}
              customTitleStyle={styles.otpTxt}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default compose(container)(Register);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  welcomeTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 28,
    color: '#000000',
    fontWeight: 'bold',
    alignSelf: 'center',
    marginTop: 12,
  },
  subTxt: {
    // fontFamily: 'Roboto Slab',
    fontSize: 14,
    color: '#090909',
    fontWeight: '600',
    alignSelf: 'center',
    marginTop: 10,
  },
  appLogo: {
    width: 88,
    height: 53,
    alignSelf: 'center',
    marginTop: 30,
  },
  subContainer: {
    padding: 30,
    backgroundColor: 'white',
    marginVertical: 30,
    width: '90%',
    borderWidth: 1,
    borderColor: '#CED4DA',
    borderRadius: 10,
    alignSelf: 'center',
  },
  btnStyle: {
    marginTop: 20,
  },
  checkBtn: {
    height: 30,
    width: 30,
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: '#CED4DA',
    borderRadius: 5,
  },
  otpBtn: {
    backgroundColor: '#F5F5F5',
  },
  otpTxt: {
    color: '#495057',
    fontSize: 14,
    fontWeight: 'bold',
  },
  orTxt: {
    color: '#495057',
    fontWeight: 'bold',
    fontSize: 20,
    alignSelf: 'center',
    marginVertical: 20,
  },
  errorMsg: {
    fontSize: 12,
    fontWeight: '500',
    color: 'red',
  },
  backBtn: {
    height: 20,
    width: 30,
    marginLeft: 10,
    position: 'absolute',
  },
  backBtnView: {
    position: 'absolute',
    marginTop: 50,
    zIndex: 3,
  },
  dateTxt: {
    fontSize: 14,
    fontWeight: '500',
    color: '#495057',
  },
  dateview: {
    borderWidth: 1,
    height: 38,
    borderRadius: 8,
    borderColor: '#CED4DA',
    paddingHorizontal: 10,
    marginTop: 8,
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
    backgroundColor: 'white',
    width: '100%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  headerStyle: {
    color: '#495057',
    fontSize: 13,
    fontWeight: 'bold',
  },
});
