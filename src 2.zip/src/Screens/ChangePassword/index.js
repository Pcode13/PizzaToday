import {
  Image,
  ImageBackground,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import DropShadow from 'react-native-drop-shadow';
import TextInputWithTitle from '../../common/Components/TextInput';
import SubmitButton from '../../common/Components/SubmitButton';
import {APP_BACK_IMAGE, BACK_ICON} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';

const ChangePassword = ({navigation}) => {
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <Header navigation={navigation} />
        <ScrollView showsVerticalScrollIndicator={false} bounces={true}>
          <View style={styles.margin30} />
          <View style={styles.topView}>
            <TouchableOpacity
              style={styles.backBtnView}
              onPress={() => navigation.goBack()}>
              <Image source={BACK_ICON} style={styles.backBtn} />
            </TouchableOpacity>
            <Text style={styles.headerTxt}>Update Profile</Text>
          </View>
          <DropShadow style={styles.shadow}>
            <View style={styles.subContainer}>
              <TextInputWithTitle
                title={'New Password'}
                placeholder={''}
                secureTextEntry={true}
              />
              <TextInputWithTitle
                title={'confirm Password'}
                placeholder={''}
                secureTextEntry={true}
              />

              <SubmitButton title={'Save'} customBtnStyle={styles.btnStyle} />
            </View>
          </DropShadow>
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default ChangePassword;

const styles = StyleSheet.create({
  btnStyle: {
    marginBottom: 10,
  },
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  headerTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#000000DE',
    marginBottom: 15,
    alignSelf: 'center',
  },
  subContainer: {
    padding: 15,
    backgroundColor: 'white',

    width: '85%',
    borderWidth: 1,
    borderColor: '#CED4DA',

    alignSelf: 'center',
    marginBottom: 20,
    borderRadius: 8,
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: {
      height: 3,
      width: 3,
    },
  },
  backBtnView: {position: 'absolute', left: 0, marginLeft: 20},
  topView: {flexDirection: 'row', justifyContent: 'center'},
  margin30: {
    marginBottom: 30,
  },
  backBtn: {
    height: 20,
    width: 30,
    position: 'absolute',
  },
});
