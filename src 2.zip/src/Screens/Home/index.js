import {
  Dimensions,
  Image,
  ImageBackground,
  Linking,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {
  APP_BACK_IMAGE,
  CHECKED,
  CHECKOUT,
  FACEBOOK,
  HOME_IMAGE,
  INSTAGRAM,
  TRUCK_MOVING,
  TWITTER,
  UNCHECKED,
} from '../../common/Assets/Constants';
import Header from '../../common/Components/Header';
import SubmitButton from '../../common/Components/SubmitButton';
import DealsCard from '../../common/Components/DealsCard';
import LinkCard from '../../common/Components/LinkCard';
import AppIntroSlider from 'react-native-app-intro-slider';
import Loader from '../../common/Components/Loader';
import container from '../../Container/HomeContainer';
import {compose} from 'recompose';
import SelectList from '../../common/Components/react-native-dropdown-select-list';

const Home = props => {
  const {navigation} = props;
  const [orderType, setOrderType] = useState('');
  const [orderTypeError, setOrderTypeError] = useState('');
  const [cityNameError, setCityNameError] = useState('');
  const [areaNameError, setAreaNameError] = useState('');
  const reviewRef = useRef();
  const scrollRef = useRef();

  const [loading, setLoading] = useState(true);
  const [cityData, setCityData] = useState([]);
  const [areaData, setAreaData] = useState([]);
  const [selectedCity, setSelectedCity] = React.useState('');
  const [selectedArea, setSelectedArea] = React.useState('');

  const [dealAndOffers, setDealAndOffers] = useState([]);

  function callgetDealAndOffersHomeAPI() {
    props.getDealAndOffersHome({
      onSuccess: response1 => {
        setDealAndOffers(response1?.data?.offers);
      },
      onFailure: e => {
        console.log('error1', e);
      },
    });
  }
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 2000);
    callgetDealAndOffersHomeAPI();
    props.getCities({
      onSuccess: response => {
        if (response?.data?.length > 0) {
          let dummyData = [];
          let cities = response?.data;
          cities.forEach(element => {
            props.getAreas({
              params: {
                cityId: element?.id,
              },
              onSuccess: response1 => {
                let areaData_ = [];
                response1?.data?.forEach(element_ => {
                  areaData_.push({
                    key: element_?.id,
                    value: element_?.name,
                  });
                });
                dummyData.push({
                  key: element?.id,
                  value: element?.name,
                  areas: areaData_,
                });
              },
              onFailure: e => {
                console.log('error1', e);
              },
            });
          });
          setCityData(dummyData);
        }
      },
      onFailure: e => {
        console.log('error', e);
      },
    });
  }, [props]);
  function RenderTypeBtn({title, icon, selected, onPress}) {
    const tintColor = selected ? 'green' : '#CED4DA';
    return (
      <TouchableOpacity
        disabled={selected}
        onPress={onPress}
        style={styles.typeBtn}>
        <Image
          source={selected ? CHECKED : UNCHECKED}
          style={[styles.checkBtn, {tintColor}]}
        />
        <Image source={icon} />
        <Text style={styles.typeTitle}>{title}</Text>
      </TouchableOpacity>
    );
  }
  const orderTypes = Object.freeze({
    DELIVERY: 'online',
    TAKEAWAY: 'offline',
  });

  function validateOrderType() {
    if (orderType === '') {
      setOrderTypeError('Please Select order type');
      return true;
    } else {
      setOrderTypeError('');
      return false;
    }
  }
  useEffect(() => {
    if (orderTypeError !== '') {
      validateOrderType();
    }
  }, [orderType, orderTypeError]);
  function validateCityName() {
    if (selectedCity === '') {
      setCityNameError('Please Select City');
      return true;
    } else {
      setCityNameError('');
      return false;
    }
  }
  useEffect(() => {
    if (cityNameError !== '') {
      validateCityName();
    }
  }, [selectedCity, cityNameError]);
  function validateAreaName() {
    if (selectedArea === '') {
      setAreaNameError('Please Select Area');
      return true;
    } else {
      setAreaNameError('');
      return false;
    }
  }
  useEffect(() => {
    if (areaNameError !== '') {
      validateAreaName();
    }
  }, [selectedArea, areaNameError]);
  function validateFields() {
    let isError = false;
    if (validateOrderType()) {
      isError = validateOrderType();
    }
    if (validateCityName()) {
      isError = validateCityName();
    }
    if (validateAreaName()) {
      isError = validateAreaName();
    }
    return !isError;
  }
  function handleSearch() {
    if (validateFields()) {
      navigation.navigate('MenuTab');
    }
  }
  function renderSearchContainer() {
    return (
      <View style={styles.searchContainer}>
        <View style={styles.typeContainer}>
          <RenderTypeBtn
            onPress={() => setOrderType(orderTypes.DELIVERY)}
            selected={orderType === orderTypes.DELIVERY}
            title={'Delivery'}
            icon={TRUCK_MOVING}
          />
          <RenderTypeBtn
            onPress={() => setOrderType(orderTypes.TAKEAWAY)}
            selected={orderType === orderTypes.TAKEAWAY}
            title={'Take Away'}
            icon={CHECKOUT}
          />
        </View>
        {orderTypeError && (
          <Text style={styles.errorMsg}>{orderTypeError}</Text>
        )}
        <View style={styles.devider} />
        <Text style={styles.selectTxt}>Select Your Location For Take Away</Text>
        <SelectList
          onSelect={() => {
            let dummyAreas = cityData?.find(
              item_ => item_.key === selectedCity,
            );
            setAreaData(dummyAreas?.areas);
          }}
          setSelected={setSelectedCity}
          placeholder={'Select City'}
          data={cityData}
          inputStyles={styles.inputStyles}
          boxStyles={styles.boxStyles}
          dropdownStyles={styles.dropdownStyles}
          dropdownItemStyles={styles.dropdownItemStyles}
          maxHeight={150}
        />
        {cityNameError && <Text style={styles.errorMsg}>{cityNameError}</Text>}
        <SelectList
          onSelect={() => null}
          setSelected={setSelectedArea}
          placeholder={'Select Area'}
          data={areaData}
          inputStyles={styles.inputStyles}
          boxStyles={[styles.boxStyles, {marginTop: 20}]}
          dropdownStyles={styles.dropdownStyles}
          dropdownItemStyles={styles.dropdownItemStyles}
          maxHeight={150}
        />
        {areaNameError && <Text style={styles.errorMsg}>{areaNameError}</Text>}
        <SubmitButton
          onPress={handleSearch}
          title={'Search'}
          customBtnStyle={styles.btnStyle}
        />
      </View>
    );
  }
  function renderDealsSeaction() {
    return (
      <>
        <View style={styles.dealsContainer}>
          <Text style={styles.dealsHeaderTxt}>Deals and Offers</Text>
          <Text style={styles.subOfferTxt}>
            Choose from over 30 craveable toppings to make your perfect Food.
            Don’t love what you ordered? Let us know. We’re all about second
            chances.
          </Text>
        </View>
        {dealAndOffers?.map((item, index) => {
          return (
            <DealsCard
              key={index}
              homeDelas={true}
              onPress={() =>
                navigation.navigate('DealsDetails', {
                  dealsData: item,
                })
              }
              dealName={item?.name}
              dealDiscription={item?.description}
              price={item?.amount}
            />
          );
        })}
        {dealAndOffers?.length > 0 && (
          <SubmitButton
            title={'View All'}
            customBtnStyle={styles.viewAllBtn}
            onPress={() => {
              scrollRef.current?.scrollTo({
                y: 0,
                animated: true,
              });
            }}
          />
        )}
      </>
    );
  }
  const renderReview = item => {
    return (
      <View>
        <Text style={styles.reviewtxt}>
          ""Great pizza. Tastes so fresh and original. Beats any of the chains
          hands down. I was so glad to hear Mike’s was opening in Oregon and now
          it is a wonderful reality.""
        </Text>
        <Text style={styles.reviewBy}>Ajay</Text>
      </View>
    );
  };
  const [reviewData, setReviewData] = useState([]);
  useEffect(() => {
    setReviewData(['ajay', 'raj', 'gopal']);
  }, []);

  const reviewIndex = useRef(0);
  const timeRef = useRef(null);
  useEffect(() => {
    if (reviewData?.length && reviewRef?.current) {
      timeRef.current = setTimeout(function tick() {
        reviewRef?.current?.goToSlide(reviewIndex.current);
        reviewIndex.current += 1;
        if (reviewIndex.current === reviewData?.length) {
          reviewIndex.current = 0;
        }
        timeRef.current = setTimeout(tick, 5000);
      }, 5000);
    } else if (timeRef.current) {
      clearTimeout(timeRef.current);
    }
  }, [reviewData]);
  function renderReviewSection() {
    return (
      <View style={styles.reviewContainer}>
        <Text style={styles.reviewHeader}>What Clients Say</Text>
        <AppIntroSlider
          bounces={true}
          ref={reviewRef}
          showNextButton={false}
          showDoneButton={false}
          bottomButton={false}
          renderItem={renderReview}
          onSlideChange={index => {
            if (index === reviewData?.length - 1) {
              reviewIndex.current = 0;
            } else {
              reviewIndex.current = index + 1;
            }
          }}
          activeDotStyle={styles.activeDotStyle}
          dotStyle={styles.dotStyle}
          data={reviewData}
          pagingEnabled={true}
          renderDoneButton={null}
          renderNextButton={null}
        />
      </View>
    );
  }
  function renderFooterSection() {
    return (
      <View style={styles.footerContainer}>
        <LinkCard
          title={'Quick Links'}
          subLinks={[
            {
              linkName: 'About us',
              onPress: () => null,
            },
            {
              linkName: 'Contacts',
              onPress: () => null,
            },
            {
              linkName: 'Terms and conditions',
              onPress: () => null,
            },
          ]}
        />
        <LinkCard
          title={'Head Office'}
          subLinks={[
            {
              linkName: 'Nawjeevan bihar sec 1 waidhan singrauli m.p. 486886',
              onPress: () => null,
            },
            {
              linkName: '8989586868',
              onPress: () => Linking.openURL('tel:8989586868'),
            },
          ]}
        />
        <LinkCard
          title={'Corporate Office'}
          subLinks={[
            {
              linkName: 'Nawjeevan bihar sec 1 waidhan singrauli m.p. 486886',
              onPress: () => null,
            },
            {
              linkName: '8989586868',
              onPress: () => null,
            },
          ]}
        />
        <View style={styles.socialContainer}>
          <TouchableOpacity>
            <Image source={FACEBOOK} style={styles.socialIcon} />
          </TouchableOpacity>
          <TouchableOpacity>
            <Image source={INSTAGRAM} style={styles.socialIcon} />
          </TouchableOpacity>
          <TouchableOpacity>
            <Image source={TWITTER} style={styles.socialIcon} />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={APP_BACK_IMAGE}
        resizeMode="cover"
        style={styles.image}>
        <StatusBar backgroundColor={'black'} barStyle={'light-content'} />
        <ScrollView
          nestedScrollEnabled={true}
          showsVerticalScrollIndicator={false}
          bounces={true}
          ref={scrollRef}>
          <StatusBar barStyle={'light-content'} />
          <Header navigation={navigation} />
          <Image source={HOME_IMAGE} style={styles.homeImage} />
          {renderSearchContainer()}
          {renderDealsSeaction()}
          {loading && <Loader visible={loading} />}
        </ScrollView>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default compose(container)(Home);

const styles = StyleSheet.create({
  mapcontainer: {
    height: 300,
    width: '100%',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  StatusBar: {
    // height: Constants.statusBarHeight,
    flex: 1,
    backgroundColor: 'black',
  },
  textInput: {
    alignSelf: 'center',
    borderWidth: 2,
    width: '100%',
    borderRadius: 5,
    height: 38,
    fontSize: 14,
    fontWeight: 'bold',
    borderColor: '#CED4DA',
    paddingHorizontal: 17,

    marginTop: 20,
  },
  btnStyle: {
    width: '100%',
    alignSelf: 'center',
    marginTop: 30,
  },
  typeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkBtn: {
    height: 20,
    width: 20,
    marginRight: 10,
  },
  typeTitle: {
    fontSize: 14,
    fontWeight: '400',
    marginLeft: 5,
  },
  homeImage: {
    width: '100%',
  },
  searchContainer: {
    width: '85%',
    borderRadius: 13,
    alignSelf: 'center',
    borderWidth: 1,
    marginTop: -120,
    backgroundColor: 'white',
    padding: 30,
  },
  typeContainer: {
    flexDirection: 'row',
    alignSelf: 'center',
    width: '100%',
    justifyContent: 'space-evenly',
  },
  devider: {
    height: 1,
    width: '100%',
    backgroundColor: '#AAAAAA',
    marginVertical: 20,
  },
  selectTxt: {
    fontSize: 15,
    fontWeight: '800',
    color: '#000000DE',
    alignSelf: 'center',
    marginBottom: 15,
  },
  optionsBtn: {
    // borderWidth: 1,
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'flex-start',
    width: '95%',
    height: 30,
    paddingLeft: 10,
    marginTop: 1,
    backgroundColor: '#72b7f7',
    alignSelf: 'center',
  },
  subOfferTxt: {
    fontSize: 16,
    fontWeight: '400',
    marginBottom: 4,
    color: '#000000CC',
    alignSelf: 'center',
    textAlign: 'center',
    width: '82%',
  },
  dealsContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 40,
  },
  dealsHeaderTxt: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 35,
    color: '#000000DE',
    alignSelf: 'center',
    marginBottom: 10,
  },
  viewAllBtn: {
    width: '85%',
    alignSelf: 'center',
    marginTop: 20,
    marginBottom: 40,
  },
  reviewtxt: {
    color: 'white',
    alignSelf: 'center',
    width: '90%',
    fontSize: 16,
    marginTop: 10,
    fontWeight: '400',
    textAlign: 'center',
  },
  reviewBy: {
    color: '#FFC107',
    fontWeight: 'bold',
    fontSize: 16,
    alignSelf: 'center',
    marginVertical: 20,
  },
  reviewHeader: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    alignSelf: 'center',
    paddingTop: 20,
  },
  reviewContainer: {
    backgroundColor: 'black',
    aspectRatio: 1.65,
    width: Dimensions.get('screen').width,
  },
  footerContainer: {
    backgroundColor: 'black',
  },
  socialContainer: {
    flexDirection: 'row',
    paddingVertical: 20,
    justifyContent: 'center',
  },
  socialIcon: {
    marginHorizontal: 10,
  },
  activeDotStyle: {
    backgroundColor: 'green',
  },
  dotStyle: {
    backgroundColor: 'white',
  },
  errorMsg: {
    color: 'red',
    fontSize: 12,
    marginTop: 10,
    alignSelf: 'center',
  },
  inputStyles: {
    padding: 0,
    fontSize: 14,
    fontWeight: 'bold',
    borderColor: '#CED4DA',
    color: 'black',
  },
  boxStyles: {
    height: 38,
    paddingVertical: 0,
    alignItems: 'center',
    borderRadius: 8,
  },
  dropdownStyles: {
    width: '96%',
    alignSelf: 'center',
    paddingTop: 0,
  },
  dropdownItemStyles: {
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'flex-start',
    width: '100%',
    paddingLeft: 10,
    marginTop: 1,
    backgroundColor: '#72b7f7',
    alignSelf: 'center',
    color: 'black',
    fontWeight: '600',
  },
});
