import {
  Dimensions,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React from 'react';

const NavScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <View
        style={{
          //   marginTop: 50,
          width: '100%',
          height: '100%',
          backgroundColor: '#FEDA2A',
        }}
      />
      <View
        style={{
          marginLeft: 150,
          width: '100%',
          height: '200%',
          //   marginTop: Dimensions.get('window').height ,
          backgroundColor: 'black',
          position: 'absolute',
          //   zIndex: 1,
          //   overflow: 'scroll',
          transform: [{rotate: '15deg'}],
        }}
      />
    </SafeAreaView>
  );
};

export default NavScreen;

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    overflow: 'visible',
    // backgroundColor: 'black',
    backgroundColor: 'black',
    position: 'absolute',
    zIndex: 2,
  },
});
