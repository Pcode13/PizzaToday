/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, {useEffect, useState} from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import Splash from './Screens/Splash';
import Register from './Screens/Register';
import Login from './Screens/Login';
import ResetPassword from './Screens/ResetPassword';
import Home from './Screens/Home';
import NavScreen from './Screens/NavScreen';
import Menu from './Screens/Menu';
import DealsDetails from './Screens/DealsDetails';
import Cart from './Screens/Cart';
import CheckOut from './Screens/CheckOut';
import About from './Screens/About';
import ProfileDashboard from './Screens/Profile';
import ChangeAddress from './Screens/ChangeAddress';
import AddAddress from './Screens/AddAddress';
import OtpVerfication from './Screens/OtpVerfication';
import Toast from 'react-native-toast-message';
import Offers from './Screens/Offers';
import Franchise from './Screens/Franchise';
import QuickMsg from './Screens/QuickMessage';
import LoginWithOTP from './Screens/LoginWithOTP';
import UpdateProfile from './Screens/UpdateProfile';
import ChangePassword from './Screens/ChangePassword';
import BillDetails from './Screens/BillDetails';
import Loader from './common/Components/Loader';
import {useSelector} from 'react-redux';
import MenuTab from './Screens/MenuTab';
const Routes = () => {
  const [loading, setLoading] = useState(true);
  const Stack = createNativeStackNavigator();
  const storeData = useSelector(store => store);
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 3000);
  }, []);

  if (loading) {
    return <Splash />;
  }
  function isLoading() {
    let load = false;
    Object.keys(storeData).map(item => {
      if (item?.isFetching) {
        return item?.isFetching;
      }
    });
    return load;
  }
  return (
    <>
      <NavigationContainer>
        <Stack.Navigator
          screenOptions={{
            headerShown: false,
          }}
          initialRouteName="Home">
          <Stack.Screen name="Home" component={Home} />
          <Stack.Screen name="MenuTab" component={MenuTab} />
          <Stack.Screen name="Register" component={Register} />
          <Stack.Screen name="Login" component={Login} />
          <Stack.Screen name="ResetPassword" component={ResetPassword} />
          <Stack.Screen name="NavScreen" component={NavScreen} />
          <Stack.Screen name="Menu" component={Menu} />
          <Stack.Screen name="DealsDetails" component={DealsDetails} />
          <Stack.Screen name="Cart" component={Cart} />
          <Stack.Screen name="CheckOut" component={CheckOut} />
          <Stack.Screen name="About" component={About} />
          <Stack.Screen name="ProfileDashboard" component={ProfileDashboard} />
          <Stack.Screen name="ChangeAddress" component={ChangeAddress} />
          <Stack.Screen name="AddAddress" component={AddAddress} />
          <Stack.Screen name="OtpVerfication" component={OtpVerfication} />
          <Stack.Screen name="Offers" component={Offers} />
          <Stack.Screen name="Franchise" component={Franchise} />
          <Stack.Screen name="QuickMsg" component={QuickMsg} />
          <Stack.Screen name="LoginWithOTP" component={LoginWithOTP} />
          <Stack.Screen name="UpdateProfile" component={UpdateProfile} />
          <Stack.Screen name="ChangePassword" component={ChangePassword} />
          <Stack.Screen name="BillDetails" component={BillDetails} />
        </Stack.Navigator>
      </NavigationContainer>
      <Toast />
      {<Loader visible={true} />}
    </>
  );
};

export default Routes;
