import {
  Alert,
  Modal,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import * as ImagePicker from 'react-native-image-picker';
import {ShowToast} from '../../Utils/toastUtils';
import DropShadow from 'react-native-drop-shadow';
import SubmitButton from '../SubmitButton';
import {PERMISSIONS, request} from 'react-native-permissions';
function RenderOptions({visible, openCamera, onCancel, openGallery}) {
  return (
    <DropShadow style={styles.shadow}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={visible}
        onRequestClose={onCancel}>
        <View style={styles.mainView}>
          <View style={[styles.heightView]}>
            <Text style={styles.pickImage}>Pick an Image</Text>
            <SubmitButton
              onPress={openCamera}
              title={'Open Camera'}
              customBtnStyle={styles.openCam}
              customTitleStyle={styles.camTxt}
            />
            <SubmitButton
              onPress={openGallery}
              customBtnStyle={styles.openGal}
              title={'Select from Gallery'}
              customTitleStyle={styles.galBtn}
            />
            <SubmitButton
              onPress={onCancel}
              customBtnStyle={styles.cancelBtn}
              title={'Cancel'}
            />
          </View>
        </View>
      </Modal>
    </DropShadow>
  );
}
const ImagePickerComp = ({onImageCapture}) => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [showOptions, setShowOptions] = useState(false);
  function openGallery() {
    setShowOptions(false);
    ImagePicker.launchImageLibrary(
      {
        mediaType: 'photo',
        includeBase64: true,
        maxHeight: 200,
        maxWidth: 200,
      },
      res => {
        if (res.didCancel) {
          ShowToast({
            type: 'info',
            text1: 'User cancelled image picker',
          });
        } else if (res.error) {
          ShowToast({
            type: 'info',
            text1: res?.error || 'ImagePicker Error:',
          });
        } else if (res.customButton) {
          ShowToast({
            type: 'info',
            text1: 'User tapped custom button: ' + res?.customButton,
          });
        } else {
          setSelectedImage(res);
          onImageCapture(res);
        }
      },
    );
  }
  const cameraLaunch = () => {
    let options = {
      storageOptions: {
        skipBackup: true,
        includeBase64: true,
        path: 'images',
      },
    };

    ImagePicker.launchCamera(options, res => {
      setShowOptions(false);
      if (res.didCancel) {
        ShowToast({
          type: 'info',
          text1: 'User cancelled image picker',
        });
      } else if (res.error) {
        ShowToast({
          type: 'info',
          text1: res?.error || 'ImagePicker Error:',
        });
      } else if (res.customButton) {
        ShowToast({
          type: 'info',
          text1: 'User tapped custom button: ' + res?.customButton,
        });
      } else if (res.errorCode) {
        ShowToast({
          type: 'info',
          text1: res?.errorCode,
        });
      } else {
        setSelectedImage(res);
        onImageCapture(res);
      }
    });
  };
  const requestCameraPermission = async () => {
    try {
      const cameraPermission =
        Platform.OS === 'ios'
          ? PERMISSIONS.IOS.CAMERA
          : PERMISSIONS.ANDROID.CAMERA;
      request(cameraPermission).then(statuses => {
        if (statuses === 'granted') {
          cameraLaunch();
        } else {
          setShowOptions(false);
          Alert.alert(
            'Info',
            'Application does not have access to camera. Please give Camera permission to Application from Setting',
          );
        }
      });
    } catch (err) {
      console.warn(err);
    }
  };
  const requestStoragePermission = async () => {
    try {
      const storagePermission =
        Platform.OS === 'ios'
          ? PERMISSIONS.IOS.PHOTO_LIBRARY
          : PERMISSIONS.ANDROID.WRITE_EXTERNAL_STORAGE;
      request(storagePermission).then(statuses => {
        if (statuses === 'granted') {
          openGallery();
        } else {
          setShowOptions(false);
          Alert.alert(
            'Info',
            'Application does not have access to Storage. Please give Storage permission to Application from Setting',
          );
        }
      });
    } catch (err) {
      console.warn(err);
    }
  };
  return (
    <View style={styles.view}>
      <Text style={styles.title}>Profile Photo</Text>
      <TouchableOpacity
        disabled={selectedImage !== null}
        style={styles.btn}
        onPress={() => setShowOptions(true)}>
        <Text style={styles.placeHolder}>
          {selectedImage === null
            ? '+ Choose Image'
            : selectedImage?.assets[0]?.fileName}
        </Text>
        {selectedImage !== null && (
          <TouchableOpacity
            onPress={() => {
              setSelectedImage(null);
              onImageCapture(null);
            }}>
            <Text style={styles.clearTxt}>Clear</Text>
          </TouchableOpacity>
        )}
      </TouchableOpacity>
      {showOptions && (
        <RenderOptions
          visible={showOptions}
          onCancel={() => setShowOptions(false)}
          openGallery={requestStoragePermission}
          openCamera={requestCameraPermission}
        />
      )}
    </View>
  );
};

export default ImagePickerComp;

const styles = StyleSheet.create({
  camTxt: {color: '#0271f7'},
  galBtn: {color: '#0271f7'},
  cancelBtn: {
    width: '70%',
    alignSelf: 'center',
  },
  openCam: {
    marginBottom: 15,
    backgroundColor: 'white',
    height: 30,
  },
  openGal: {
    marginBottom: 15,
    backgroundColor: 'white',
    height: 30,
  },
  pickImage: {
    color: 'black',
    fontWeight: '600',
    fontSize: 16,
    alignSelf: 'center',
    marginBottom: 30,
  },
  placeHolder: {
    width: '85%',
    color: '#484848',
    fontWeight: '500',
    fontSize: 14,
    paddingVertical: 9,
  },
  btn: {
    borderWidth: 1,
    // height: 38,
    borderRadius: 8,
    borderColor: '#CED4DA',
    paddingHorizontal: 10,
    marginTop: 8,
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
    backgroundColor: 'white',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
  },
  title: {
    color: '#495057',
    fontSize: 13,
    fontWeight: 'bold',
  },
  view: {
    marginBottom: 20,
  },
  clearTxt: {color: 'red', fontSize: 14, paddingRight: 10},
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3,
    shadowOffset: {
      height: 2,
      width: 2,
    },
  },
  mainView: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  heightView: {
    // height: '55%',
    paddingBottom: 30,
    paddingTop: 25,
    marginTop: 'auto',
    borderWidth: 1.5,
    borderColor: '#CED4DA',
    backgroundColor: '#FFFFFF',
    padding: 10,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
});
