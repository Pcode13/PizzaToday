import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import DropShadow from 'react-native-drop-shadow';
import {GREEN_CHECK} from '../../Assets/Constants';

const AddressCard = ({
  showChange,
  toPerson,
  address,
  phno,
  onPress,
  selected = false,
  onChange,
  onRemove,
  showRemove = false,
}) => {
  const marginBottom = showChange ? 0 : 25;
  const borderWidth = selected ? 1.5 : 0;
  const borderColor = selected ? '#25A140' : null;
  return (
    <DropShadow style={styles.shadow}>
      <TouchableOpacity
        onPress={onPress}
        style={[styles.container, {marginBottom, borderWidth, borderColor}]}>
        {selected && <Image source={GREEN_CHECK} style={styles.check} />}
        {showChange && (
          <View style={styles.deliveryView}>
            <Text style={styles.deliveryTxt}>Deliver to:</Text>
            <TouchableOpacity onPress={onChange} style={styles.changeBtn}>
              <Text style={styles.changeTxt}>Change</Text>
            </TouchableOpacity>
          </View>
        )}
        <Text style={styles.nameTxt}>{toPerson}</Text>
        <Text style={styles.address}>{address}</Text>
        <View style={styles.removeView}>
          <Text style={styles.phno}>+91 {phno}</Text>
          {showRemove && (
            <TouchableOpacity onPress={onRemove}>
              <Text style={[styles.phno, styles.removeTxt]}>Remove</Text>
            </TouchableOpacity>
          )}
        </View>
      </TouchableOpacity>
    </DropShadow>
  );
};

export default AddressCard;

const styles = StyleSheet.create({
  removeView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  removeTxt: {color: 'red'},
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3,
    shadowOffset: {
      height: 2,
      width: 2,
    },
  },
  container: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#00000029',
    width: '85%',
    alignSelf: 'center',
    backgroundColor: 'white',
    borderRadius: 5,
  },
  deliveryView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  deliveryTxt: {
    fontSize: 15,
    fontWeight: 'bold',
    color: 'black',
  },
  changeBtn: {
    padding: 5,
    borderRadius: 5,
    backgroundColor: '#FFC107',
  },
  changeTxt: {
    fontSize: 12,
    fontWeight: '500',
    color: 'black',
  },
  nameTxt: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'black',
  },
  address: {
    lineHeight: 19,
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
    marginTop: 7,
  },
  phno: {
    lineHeight: 19,
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
    marginTop: 7,
  },
  check: {
    position: 'absolute',
    height: 12,
    width: 12,
    right: 10,
    top: 10,
  },
});
