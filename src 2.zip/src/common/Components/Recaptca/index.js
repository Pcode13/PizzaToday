import {
  ActivityIndicator,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {CHECKED, RECAPTCHA, UNCHECKED} from '../../Assets/Constants';

const Recaptca = ({onVerfied}) => {
  const [showActivity, setShowActivity] = useState(false);
  const [captchCapatured, setCaptchCapatured] = useState(false);
  const tintColor = captchCapatured ? '#25A140' : '#CED4DA';
  const imageStyle = {width: 25, height: 25, tintColor};
  return (
    <View style={styles.recaptcaView}>
      {!showActivity ? (
        <TouchableOpacity
          disabled={captchCapatured}
          onPress={() => {
            setShowActivity(true);
            setTimeout(() => {
              onVerfied();
              setCaptchCapatured(true);
              setShowActivity(false);
            }, 2000);
          }}>
          <Image
            source={captchCapatured ? CHECKED : UNCHECKED}
            style={imageStyle}
          />
        </TouchableOpacity>
      ) : (
        <ActivityIndicator />
      )}
      <Text>I`m not a robot</Text>
      <Image source={RECAPTCHA} style={styles.captcaIcon} />
    </View>
  );
};

export default Recaptca;

const styles = StyleSheet.create({
  recaptcaView: {
    height: 67,
    borderWidth: 1,
    borderColor: '#CED4DA',
    backgroundColor: '#F9F9F9',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    marginBottom: 20,
    borderRadius: 8,
    marginTop: 10,
  },
  captcaIcon: {
    width: 60,
    height: 60,
  },
});
