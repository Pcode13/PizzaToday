import React from 'react';
import {
  Animated,
  View,
  Image,
  StyleSheet,
  Modal,
  Dimensions,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {APP_LOGO} from '../../Assets/Constants';
import {connect} from 'react-redux';
import {createSelector} from 'reselect';
class Loader extends React.PureComponent {
  state = {
    scales: [
      new Animated.Value(0),
      new Animated.Value(0),
      new Animated.Value(0),
    ],
  };
  componentDidMount() {
    this._animation();
  }

  componentWillUnmount() {
    this.unmounted = true;
  }

  _animation = () => {
    function seq(self, i) {
      return Animated.sequence([
        Animated.timing(self.state.scales[i], {
          toValue: 1,
          duration: 300,
          delay: (i + 1) * 200,
          useNativeDriver: true,
        }),
        Animated.timing(self.state.scales[i], {
          toValue: 0,
          duration: 300,
          delay: 50,
          useNativeDriver: true,
        }),
      ]);
    }

    Animated.parallel([seq(this, 0), seq(this, 1), seq(this, 2)]).start(() => {
      if (!this.unmounted) {
        this._animation();
      }
    });
  };

  _renderCircle = i => {
    const style = {
      height: 9,
      width: 9,
      borderRadius: 4.5,
    };
    return (
      <Animated.View
        style={[
          style,
          {
            transform: [{scale: this.state.scales[i]}],
          },
        ]}>
        <LinearGradient style={style} colors={['#FFC107', '#FFCC00']} />
      </Animated.View>
    );
  };
  render() {
    const {fetching, loading} = this.props;
    if (!fetching && !loading) {
      return;
    }
    return (
      <Modal
        transparent={true}
        animationType={'none'}
        visible={true}
        style={{zIndex: 1100}}
        onRequestClose={() => {}}>
        <View style={Styles.loaderMainContainer}>
          <View style={Styles.middleContainer}>
            <Image
              source={APP_LOGO}
              style={Styles.imageStyle}
              resizeMode="contain"
            />
            <View style={Styles.main}>
              {this._renderCircle(0)}
              {this._renderCircle(1)}
              {this._renderCircle(2)}
            </View>
          </View>
        </View>
      </Modal>
    );
  }
}
const getState = state => state;
export const isFetchingSelector = createSelector([getState], state => {
  let isFetching = false;
  Object.keys(state).forEach(key => {
    if (state[key].isFetching) {
      isFetching = true;
    }
  });
  return {
    fetching: isFetching,
  };
});
export default connect(isFetchingSelector)(Loader);

const Styles = StyleSheet.create({
  middleContainer: {
    width: 90,
    height: 90,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  main: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    margin: 8,
    width: 50,
  },
  imageStyle: {
    width: 66,
    height: 56,
  },
  loaderMainContainer: {
    width: Dimensions.get('screen').width,
    height: Dimensions.get('screen').height,
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 999,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
});
