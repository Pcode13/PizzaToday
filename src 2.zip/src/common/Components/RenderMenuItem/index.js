import {Dimensions, StyleSheet, Text, TouchableOpacity} from 'react-native';
import React from 'react';

const RenderMenuItem = ({title, selecteItem, onPress, count = 5}) => {
  const backgroundColor = selecteItem ? 'green' : null;
  // const width = Dimensions.get('screen').width / count;
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.menuBtn, {backgroundColor}]}>
      <Text style={styles.menuTxt}>{title}</Text>
    </TouchableOpacity>
  );
};

export default RenderMenuItem;

const styles = StyleSheet.create({
  menuBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 43,
    paddingHorizontal: 8,
  },
  menuTxt: {
    color: 'white',
    fontSize: 17,
    fontWeight: '500',
  },
});
