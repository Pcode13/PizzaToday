import React from 'react';
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Image,
} from 'react-native';
import DropShadow from 'react-native-drop-shadow';
import {
  APP_LOGO,
  CROSS_ROUND,
  HEADER_LOGO,
  RIGHT_ROUND,
} from '../../Assets/Constants';
import ProductItem from '../ProductItem';
import SubmitButton from '../SubmitButton';

const OfferPopUp = ({
  visible,
  onHide,
  isApplied = true,
  code,
  discription,
  onPress,
  showThankIcon,
}) => {
  const tintColor = showThankIcon ? null : isApplied ? '#25A140' : '#EA0F0E';
  return (
    <DropShadow style={styles.shadow}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={visible}
        onRequestClose={onHide}>
        <View style={styles.mainView}>
          <View style={[styles.heightView]}>
            <Image
              source={
                showThankIcon ? APP_LOGO : isApplied ? RIGHT_ROUND : CROSS_ROUND
              }
              style={[styles.icon, {tintColor}]}
            />
            <Text style={styles.applyStatus}>
              {code}{' '}
              {showThankIcon ? '' : isApplied ? 'Applied' : 'Not Applied'}
            </Text>
            {discription && <Text style={styles.discrip}>{discription}</Text>}
            <SubmitButton
              onPress={onPress}
              customTitleStyle={styles.ok}
              title={showThankIcon ? 'Done' : 'OK'}
            />
          </View>
        </View>
      </Modal>
    </DropShadow>
  );
};

const styles = StyleSheet.create({
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3,
    shadowOffset: {
      height: 2,
      width: 2,
    },
  },
  mainView: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heightView: {
    width: '90%',
    borderWidth: 1.5,
    borderColor: '#CED4DA',
    backgroundColor: '#FFFFFF',
    padding: 35,
    borderRadius: 9,
  },
  icon: {
    alignSelf: 'center',
    height: 75,
    width: 75,
    resizeMode: 'contain',
  },
  applyStatus: {
    fontSize: 26,
    fontWeight: '700',
    color: '#000000',
    marginTop: 17,
    marginBottom: 10,
    alignSelf: 'center',
    textAlign: 'center',
  },
  discrip: {
    fontSize: 14,
    fontWeight: '500',
    color: '#000000',
    alignSelf: 'center',
    marginBottom: 35,
    textAlign: 'center',
  },
  ok: {fontSize: 16},
});

export default OfferPopUp;
