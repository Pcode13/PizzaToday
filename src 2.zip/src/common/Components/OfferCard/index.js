import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import DropShadow from 'react-native-drop-shadow';

const OfferCard = ({offerName, offerDiscription, onApply}) => {
  const highlightText = (string, style) =>
    string.split(' ').map((word, i) => (
      <Text key={i}>
        <Text style={style}>{word} </Text>
      </Text>
    ));
  return (
    <DropShadow style={styles.shadow}>
      <View style={styles.container}>
        <TouchableOpacity style={styles.applyBtn} onPress={onApply}>
          <Text style={styles.applyTxt}>Apply</Text>
        </TouchableOpacity>
        <Image
          source={{
            uri: 'https://pizzatoday.in/public/web/product/ITALIAN_PIZZA.png',
          }}
          style={styles.offerIcon}
        />
        <View style={styles.offerTxtView}>
          <Text style={styles.offer}>{offerName}</Text>
          <Text style={styles.offertxt}>
            Use Code
            {highlightText(` ${offerName} `, {color: 'green'})}
            {offerDiscription}
          </Text>
        </View>
      </View>
    </DropShadow>
  );
};

export default OfferCard;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    width: '85%',
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#DADADB',
    padding: 17,
    alignSelf: 'center',
    borderRadius: 8,
    marginBottom: 15,
  },
  applyBtn: {
    position: 'absolute',
    height: 25,
    width: 60,
    backgroundColor: '#25A140',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    right: 0,
    margin: 7,
    zIndex: 2,
  },
  offerIcon: {
    width: 53,
    borderColor: '#CED4DA',
    height: 53,
    borderRadius: 25,
    borderWidth: 1,
  },
  applyTxt: {
    fontSize: 13,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  offerTxtView: {
    width: '80%',
    marginLeft: 12,
  },
  offertxt: {
    fontSize: 12,
    color: '#000000DE',
    fontWeight: '600',
    lineHeight: 18,
    marginTop: 5,
  },
  offer: {
    fontSize: 18,
    color: '#000000',
    fontWeight: '700',
    lineHeight: 21,
  },
});
