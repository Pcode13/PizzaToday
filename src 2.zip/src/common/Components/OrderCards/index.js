import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import SubmitButton from '../SubmitButton';
import DropShadow from 'react-native-drop-shadow';

const OrderCards = ({
  customStyle = {},
  visibletext = true,
  status,
  onPress,
}) => {
  const firstCondition = status === 'Cancelled' ? 'red' : '#FFC107';
  const color = status === 'Completed' ? 'green' : firstCondition;
  const fontWeight = '600';
  return (
    <DropShadow style={styles.shadow}>
      <View style={[styles.contanier, customStyle]}>
        <View style={styles.orderView}>
          <Text style={styles.date}>26 Jan, 2022 11:14 AM</Text>
          {status !== 'Pending' && status !== 'Cancelled' && (
            <SubmitButton
              onPress={() => {
                if (status !== 'Pending' && status !== 'Cancelled') {
                  onPress();
                }
              }}
              customTitleStyle={styles.viewbtn}
              customBtnStyle={styles.viewbtntxt}
              title={'View'}
            />
          )}
        </View>

        <View style={styles.txtview}>
          <Text style={styles.token}>Token N0. : 1</Text>
          <Text style={styles.token}>Amount. : Rs 600</Text>
        </View>

        <View style={styles.txtstatusVuew}>
          <Text style={styles.token}>Items. : 3</Text>
          {visibletext ? (
            <View style={styles.statustext}>
              <Text style={[styles.token]}>Status. : </Text>
              <Text style={[styles.token, {color, fontWeight}]}> {status}</Text>
            </View>
          ) : (
            <Text style={styles.token}>Payment Mode. : COD</Text>
          )}
        </View>
      </View>
    </DropShadow>
  );
};

export default OrderCards;

const styles = StyleSheet.create({
  contanier: {
    width: '100%',
    // width: 315,
    // height: 114,
    backgroundColor: 'white',
    alignSelf: 'center',
    padding: 5,
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: {
      height: 3,
      width: 3,
    },
  },
  viewbtn: {
    color: 'white',
    fontSize: 13,
    fontWeight: 'bold',
  },

  viewbtntxt: {
    marginBottom: 5,
    width: 60,
    alignSelf: 'center',
    height: 25,
    borderRadius: 15,
  },
  date: {
    fontSize: 17,
    fontWeight: 'bold',
    textAlign: 'left',
    color: 'black',
    // fontFamily: 'Roboto Slab',
  },
  token: {
    fontSize: 17,
    color: 'black',
  },
  orderView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 5,
  },
  txtview: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 5,
  },
  txtstatusVuew: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 5,
  },
  statustext: {
    flexDirection: 'row',
  },
});
