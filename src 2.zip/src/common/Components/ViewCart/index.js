import React from 'react';
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Image,
} from 'react-native';
import DropShadow from 'react-native-drop-shadow';
import {CROSS} from '../../Assets/Constants';
import ProductItem from '../ProductItem';
import SubmitButton from '../SubmitButton';

const ViewCart = ({visible, onHide, navigation, cartData = [1, 2, 3]}) => {
  const twoView = cartData.length === 2 ? '45%' : '57%';
  const height = cartData.length === 1 ? '34%' : twoView;
  return (
    <DropShadow style={styles.shadow}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={visible}
        onRequestClose={onHide}>
        <View style={styles.mainView}>
          <View style={[styles.heightView, {height}]}>
            <View style={styles.orderView}>
              <Text style={styles.orderTxt}>Your Order : 1</Text>
              <TouchableOpacity onPress={onHide}>
                <Image source={CROSS} style={styles.crossIcon} />
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              <ProductItem />
              <ProductItem />
              <ProductItem />
              <ProductItem />
              <ProductItem />
            </ScrollView>
            <View style={styles.priceView}>
              <Text style={styles.totalTxt}>Total</Text>
              <Text style={styles.price}>₹ 599</Text>
            </View>
            <SubmitButton
              onPress={() => {
                onHide();
                setTimeout(() => {
                  navigation.navigate('Cart');
                }, 100);
              }}
              customTitleStyle={styles.addToCart}
              customBtnStyle={styles.addToCartTxt}
              title={'Order Now'}
            />
          </View>
        </View>
      </Modal>
    </DropShadow>
  );
};

const styles = StyleSheet.create({
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3,
    shadowOffset: {
      height: 2,
      width: 2,
    },
  },
  mainView: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  heightView: {
    height: '55%',
    paddingBottom: 30,
    paddingTop: 25,
    marginTop: 'auto',
    borderWidth: 1.5,
    borderColor: '#CED4DA',
    backgroundColor: '#FFFFFF',
    padding: 10,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  priceView: {
    flexDirection: 'row',
    width: '88%',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 9,
    marginTop: 7,
  },
  totalTxt: {
    fontSize: 17,
    fontWeight: '500',
    color: '#212121',
  },
  price: {
    fontSize: 15,
    fontWeight: '800',
    color: '#000000',
  },
  addToCart: {
    color: 'white',
    fontSize: 17,
    fontWeight: 'bold',
  },
  addToCartTxt: {
    marginBottom: 5,
    width: '90%',
    alignSelf: 'center',
    height: 52,
  },
  orderTxt: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#212121',
  },
  crossIcon: {
    width: 20,
    height: 20,
    tintColor: 'black',
  },
  orderView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 30,
    marginBottom: 20,
  },
});

export default ViewCart;
