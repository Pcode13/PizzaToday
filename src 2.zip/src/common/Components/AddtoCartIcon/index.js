import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useState} from 'react';
import {DELETE_ICON, MINUS, PLUS_ICON} from '../../Assets/Constants';

const AddtoCartIcon = ({cartCount, onDelete, isSmallCard}) => {
  const styles = Styles(isSmallCard);
  const [count, setCount] = useState(cartCount);
  function onPlusClick() {
    setCount(count + 1);
  }
  function onMinusClick() {
    if (count === 1) {
      onDelete();
    } else {
      setCount(count - 1);
    }
  }
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={onPlusClick}>
        <Image source={PLUS_ICON} style={styles.cartAddIcon} />
      </TouchableOpacity>
      <Text style={styles.cartCount}>{count}</Text>
      <TouchableOpacity onPress={onMinusClick}>
        <Image
          source={count <= 1 ? DELETE_ICON : MINUS}
          style={styles.cartAddIcon}
        />
      </TouchableOpacity>
    </View>
  );
};

export default AddtoCartIcon;

const Styles = isSmallCard =>
  StyleSheet.create({
    cartAddIcon: {
      height: isSmallCard ? 9 : 16,
      width: isSmallCard ? 10 : 16,
      resizeMode: 'contain',
      tintColor: '#000000',
    },
    container: {
      width: isSmallCard ? 60 : 80,
      height: isSmallCard ? 20 : 25,
      backgroundColor: '#F2F2F2',
      borderRadius: 15,
      flexDirection: 'row',
      justifyContent: 'space-evenly',
      alignItems: 'center',
    },
    cartCount: {
      fontSize: isSmallCard ? 10 : 13,
      fontWeight: 'bold',
      color: 'black,',
    },
  });
