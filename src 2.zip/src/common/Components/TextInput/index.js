import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';

const TextInputWithTitle = ({
  value,
  onChangeText,
  title,
  placeholder,
  keyboardType = 'default',
  secureTextEntry = false,
  defaultValue,
  customStyle = {},
  multiline = false,
  numberOfLines = 1,
  isMobile = false,
  error = false,
  errorMsg = '',
  ref,
  rightTxt = '',
  onSubmitEditing = () => {},
  rightTxtDisabled = false,
  onRightTxtPress = () => {},
  onRightTxtColor,
  editable,
  autoCapitalize = 'none',
  autoComplete = 'off',
}) => {
  const mobileStyle = isMobile ? styles.mobileStyle : {};
  const borderColor = error ? 'red' : '#CED4DA';
  const color = onRightTxtColor;
  return (
    <View>
      <Text style={styles.headerStyle}>{title}</Text>
      <View>
        {isMobile && (
          <View style={[styles.phView, {borderColor}]}>
            <Text style={styles.phtxt}>+91</Text>
          </View>
        )}
        {rightTxt !== '' && (
          <TouchableOpacity
            onPress={onRightTxtPress}
            disabled={rightTxtDisabled}
            style={styles.rightTxtView}>
            <Text style={[styles.rightTxt, {color}]}>{rightTxt}</Text>
          </TouchableOpacity>
        )}
        <TextInput
          editable={editable}
          onSubmitEditing={onSubmitEditing}
          ref={ref}
          multiline={multiline}
          numberOfLines={numberOfLines}
          defaultValue={defaultValue}
          secureTextEntry={secureTextEntry}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          autoComplete={autoComplete}
          style={[styles.inputStyle, customStyle, mobileStyle, {borderColor}]}
        />
        {error && errorMsg ? (
          <Text style={styles.errorMsg}>{errorMsg}</Text>
        ) : (
          <View style={styles.marginBottom} />
        )}
      </View>
    </View>
  );
};

export default TextInputWithTitle;

const styles = StyleSheet.create({
  inputStyle: {
    borderWidth: 1,
    height: 38,
    borderRadius: 8,
    borderColor: '#CED4DA',
    paddingHorizontal: 10,
    marginTop: 8,
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
    backgroundColor: 'white',
  },
  headerStyle: {
    color: '#495057',
    fontSize: 13,
    fontWeight: 'bold',
  },
  mobileStyle: {
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
    marginLeft: 28,
    borderLeftWidth: 0,
    borderLeftRadius: 0,
    // borderRightColor: null,
  },
  phView: {
    position: 'absolute',
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
    borderWidth: 1,
    marginTop: 8,
    paddingVertical: 10,
    borderTopLeftRadius: 8,
    borderBottomLeftRadius: 8,
    borderColor: '#CED4DA',
    borderRightWidth: 0,
    paddingLeft: 5,
  },
  phtxt: {
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
  },
  errorMsg: {
    color: 'red',
    marginBottom: 15,
    fontSize: 12,
    marginTop: 5,
  },
  marginBottom: {marginBottom: 15},
  rightTxtView: {
    position: 'absolute',
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
    marginTop: 8,
    paddingVertical: 10,
    marginRight: 10,
    right: 0,
  },
  rightTxt: {
    fontSize: 14,
    fontWeight: '600',
    color: 'green',
  },
});
