import {StyleSheet, Text, View, Image} from 'react-native';
import React from 'react';
import {NONVEG, VEG} from '../../Assets/Constants';
const OrderList = ({isVeg, itemName}) => {
  return (
    <View style={styles.cardView}>
      <View style={styles.txtView}>
        <Image
          source={isVeg ? VEG : NONVEG}
          style={
            isVeg ? styles.foodType : {...styles.foodType, ...styles.nonVeg}
          }
        />
        <Text style={styles.txttitle}>{itemName}</Text>
      </View>
      <Text style={styles.txt}>
        Size : Reguler 6 Inch , Choice Of crust For small
      </Text>
      <Text style={styles.txt}>Pizza :Reguler crust</Text>
      <View>
        <View style={[styles.boxView]}>
          <View style={styles.boxdata}>
            <View style={styles.box}>
              <Text style={styles.boxinner}>1</Text>
            </View>
            <Text style={styles.boxText}>× ₹199</Text>
          </View>
          <Text style={styles.boxtext2}>₹199.40</Text>
        </View>
      </View>
    </View>
  );
};

export default OrderList;

const styles = StyleSheet.create({
  cardView: {
    width: '100%',
    // height: '18%',
    // backgroundColor: 'red',
  },
  imgview: {
    margin: 10,
    // width: 20,
    // height: 20,
  },
  txttitle: {
    fontSize: 16,
    fontWeight: '500',
    color: 'black',
    marginTop: 5,
  },
  txtView: {
    flexDirection: 'row',
  },
  txt: {
    fontSize: 12,
    paddingHorizontal: 10,
  },
  boxView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
    alignItems: 'center',
  },
  boxdata: {
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    // marginTop: 8,
  },
  box: {
    width: 20,
    height: 20,
    backgroundColor: '#d7edd5',
    borderColor: 'green',
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  boxinner: {textAlign: 'center', color: 'green'},
  boxText: {color: 'black', marginLeft: 3},
  boxtext2: {paddingRight: 8, color: 'black'},
  foodType: {
    margin: 10,
    height: 18,
    width: 18,
    marginTop: 6,
    resizeMode: 'contain',
    // borderWidth: 1,
  },
  nonVeg: {
    height: 24,
    width: 24,
    marginTop: 3,
  },
});
