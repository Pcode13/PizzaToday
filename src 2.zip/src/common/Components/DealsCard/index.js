import {
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';
import React from 'react';
import {DEAL_CARD_LOGO} from '../../Assets/Constants';
import DropShadow from 'react-native-drop-shadow';

const DealsCard = ({
  disabled,
  onPress,
  customStyle = {},
  homeDelas = false,
  dealName,
  dealDiscription,
  price,
}) => {
  function renderSection() {
    return (
      <>
        <Image source={DEAL_CARD_LOGO} style={styles.dealLogo} />
        <Text style={styles.dealName}>{dealName}</Text>
        <Text style={styles.dealPrice}>₹ {price}</Text>
        <Text style={styles.dealDescription}>{dealDiscription}</Text>
      </>
    );
  }
  return (
    <DropShadow style={styles.shadow}>
      {homeDelas ? (
        <Pressable
          onFocus={() => alert('Akas')}
          style={[styles.container, customStyle]}
          disabled={disabled}
          onPress={onPress}>
          {renderSection()}
        </Pressable>
      ) : (
        <TouchableOpacity
          onFocus={() => alert('Akas')}
          style={[styles.container, customStyle]}
          disabled={disabled}
          onPress={onPress}>
          {renderSection()}
        </TouchableOpacity>
      )}
    </DropShadow>
  );
};

export default DealsCard;

const styles = StyleSheet.create({
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3,
    shadowOffset: {
      height: 4,
      width: 4,
    },
  },
  container: {
    width: '85%',
    alignSelf: 'center',
    borderWidth: 3,
    borderColor: 'gray',
    marginBottom: 20,
    backgroundColor: 'white',
  },
  dealLogo: {
    width: '100%',
    height: 120,
  },
  dealName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000000DE',
    marginTop: 12,
    marginBottom: 10,
    marginLeft: 20,
  },
  dealPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000000DE',
    marginBottom: 15,
    marginLeft: 20,
  },
  dealDescription: {
    fontSize: 12,
    fontWeight: '700',
    color: '#999999',
    marginBottom: 15,
    marginHorizontal: 20,
  },
});
