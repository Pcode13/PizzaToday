import React, {useState} from 'react';
import {
  Modal,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  Image,
} from 'react-native';
import DropShadow from 'react-native-drop-shadow';
import {
  CHEESE,
  CROSS,
  FIRST_BACKDROUND,
  GREEN_CHECK,
} from '../../Assets/Constants';
import SubmitButton from '../SubmitButton';

function RenderSmallCard({
  title,
  subTxt,
  seletedLength,
  onPress,
  boldPrice = false,
}) {
  const borderWidth = seletedLength ? 1.5 : 0;
  const fontWeight = boldPrice ? '700' : '600';
  const color = boldPrice ? '#000000CC' : '#00000066';
  return (
    <DropShadow style={styles.shadow1}>
      <TouchableOpacity
        onPress={onPress}
        style={[styles.sCardView, {borderWidth}]}>
        {seletedLength && (
          <Image source={GREEN_CHECK} style={styles.sCardIcon} />
        )}
        <Text style={styles.firTxt}>{title}</Text>
        <Text style={[styles.secTxt, {fontWeight, color}]}>{subTxt}</Text>
      </TouchableOpacity>
    </DropShadow>
  );
}
function RenderBigCard({title, subTxt, seletedCheese, onPress, image}) {
  const borderWidth = seletedCheese ? 1.5 : 1;
  const borderColor = seletedCheese ? '#25A140' : '#CED4DA';
  return (
    <DropShadow style={styles.shadow}>
      <TouchableOpacity
        onPress={onPress}
        style={[styles.bCardView, {borderWidth, borderColor}]}>
        {seletedCheese && (
          <Image source={GREEN_CHECK} style={styles.bCardIcon} />
        )}
        <Image
          source={image?.length ? {uri: image} : CHEESE}
          style={styles.cheeseIcon}
        />
        <View style={styles.bInnerView}>
          <Text style={styles.bfirTxt}>{title}</Text>
          <Text style={[styles.bbSecTxt]}>{subTxt}</Text>
          <SubmitButton
            onPress={onPress}
            title={seletedCheese ? 'Remove' : 'Add'}
            customBtnStyle={styles.addBtn}
          />
        </View>
      </TouchableOpacity>
    </DropShadow>
  );
}
const ModalView = ({visible, onHide}) => {
  const lengths = Object.freeze({
    L: 'L',
    M: 'M',
    R: 'R',
  });
  const pans = Object.freeze({
    PAN: 'Pan',
    THIN_CRUST: 'Thin Crust',
    CHEESE_BURST: 'Cheese Burst',
  });
  const [extraCheese, setExtraCheese] = useState([
    {
      id: '1',
      cheeseName: 'EXTRA CHEESE',
      price: '30',
      isSelected: false,
    },
    {
      id: '2',
      cheeseName: 'PANEER',
      price: '40',
      isSelected: false,
    },
  ]);
  const [nonVegToppings, setNonVegToppings] = useState([
    {
      id: '1',
      topppingName: 'CHICKEN',
      price: '30',
      isSelected: false,
    },
    {
      id: '2',
      topppingName: 'MUTTON',
      price: '40',
      isSelected: false,
    },
  ]);
  const [vegToppings, setVegToppings] = useState([
    {
      id: '1',
      topppingName: 'ONION',
      price: '30',
      isSelected: false,
    },
    {
      id: '2',
      topppingName: 'CORN',
      price: '40',
      isSelected: false,
    },
    {
      id: '3',
      topppingName: 'BLACK OLIVE',
      price: '40',
      isSelected: false,
    },
  ]);
  const [seletedLength, setSeletedLength] = useState(lengths.L);
  const [selectedPan, setSelectedPan] = useState(pans.THIN_CRUST);

  function onPressCheese(selectedItem) {
    const filteredData = extraCheese.map(item => {
      if (selectedItem.id === item.id) {
        return {...item, isSelected: !item.isSelected};
      } else {
        return item;
      }
    });
    setExtraCheese(filteredData);
  }

  function onPressToppings(selectedItem) {
    const filteredData = vegToppings.map(item => {
      if (selectedItem.id === item.id) {
        return {...item, isSelected: !item.isSelected};
      } else {
        return item;
      }
    });
    setVegToppings(filteredData);
  }
  function onPressNonVegToppings(selectedItem) {
    const filteredData = nonVegToppings.map(item => {
      if (selectedItem.id === item.id) {
        return {...item, isSelected: !item.isSelected};
      } else {
        return item;
      }
    });
    setNonVegToppings(filteredData);
  }

  return (
    <DropShadow style={styles.shadow}>
      <Modal
        animationType="slide"
        transparent={true}
        visible={visible}
        onRequestClose={onHide}>
        <View style={styles.mainView}>
          <View style={styles.heightView}>
            <ScrollView showsVerticalScrollIndicator={false}>
              <View style={styles.topView}>
                <View style={styles.pizzaImageView}>
                  <Image source={FIRST_BACKDROUND} style={styles.innerB} />
                  <Image
                    source={{
                      uri: 'https://pizzatoday.in/public/web/product/ITALIAN_PIZZA.png',
                    }}
                    style={styles.outerB}
                  />
                </View>
                <Text style={styles.heading}>SIMPLY VEG PIZZA</Text>
                <View style={styles.crossView}>
                  <TouchableOpacity onPress={onHide}>
                    <Image source={CROSS} style={styles.crossImage} />
                  </TouchableOpacity>
                </View>
              </View>
              <Text style={styles.heading}>SELECT YOUR SIZE</Text>
              <View style={[styles.sizeView, styles.smallView]}>
                <RenderSmallCard
                  subTxt={'Serve 4 Person'}
                  title={lengths.L}
                  seletedLength={seletedLength === lengths.L}
                  onPress={() => setSeletedLength(lengths.L)}
                />
                <RenderSmallCard
                  subTxt={'Serve 2 Person'}
                  title={lengths.M}
                  seletedLength={seletedLength === lengths.M}
                  onPress={() => setSeletedLength(lengths.M)}
                />
                <RenderSmallCard
                  subTxt={'Serve 1 Person'}
                  title={lengths.R}
                  seletedLength={seletedLength === lengths.R}
                  onPress={() => setSeletedLength(lengths.R)}
                />
              </View>
              <Text style={styles.heading}>SELECT YOUR CRUST</Text>
              <View style={[styles.sizeView, styles.smallView]}>
                <RenderSmallCard
                  boldPrice={true}
                  subTxt={'₹ 529'}
                  title={pans.PAN}
                  seletedLength={pans.PAN === selectedPan}
                  onPress={() => setSelectedPan(pans.PAN)}
                />
                <RenderSmallCard
                  boldPrice={true}
                  subTxt={'₹ 529'}
                  title={pans.THIN_CRUST}
                  seletedLength={pans.THIN_CRUST === selectedPan}
                  onPress={() => setSelectedPan(pans.THIN_CRUST)}
                />
                <RenderSmallCard
                  boldPrice={true}
                  subTxt={'₹ 529'}
                  title={pans.CHEESE_BURST}
                  seletedLength={pans.CHEESE_BURST === selectedPan}
                  onPress={() => setSelectedPan(pans.CHEESE_BURST)}
                />
              </View>
              <Text style={styles.heading}>EXTRA CHEESE</Text>
              <View style={styles.sizeView}>
                {extraCheese.map((item, index) => {
                  return (
                    <RenderBigCard
                      key={index}
                      boldPrice={true}
                      subTxt={`₹ ${item.price}`}
                      title={item.cheeseName}
                      seletedCheese={item.isSelected}
                      onPress={() => onPressCheese(item)}
                    />
                  );
                })}
              </View>
              <Text style={styles.heading}>VEG TOPPINGS</Text>
              <View style={styles.sizeView}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {vegToppings.map((item, index) => {
                    return (
                      <RenderBigCard
                        key={index}
                        boldPrice={true}
                        subTxt={`₹ ${item.price}`}
                        title={item.topppingName}
                        seletedCheese={item.isSelected}
                        onPress={() => onPressToppings(item)}
                      />
                    );
                  })}
                </ScrollView>
              </View>
              <Text style={styles.heading}>NON-VEG TOPPINGS</Text>
              <View style={styles.sizeView}>
                {nonVegToppings?.map((item, index) => {
                  return (
                    <RenderBigCard
                      image={
                        'https://toppng.com/uploads/preview/fried-chicken-png-11552945573sn657hxomw.png'
                      }
                      key={index}
                      boldPrice={true}
                      subTxt={`₹ ${item.price}`}
                      title={item.topppingName}
                      seletedCheese={item.isSelected}
                      onPress={() => onPressNonVegToppings(item)}
                    />
                  );
                })}
              </View>
            </ScrollView>
            <View style={styles.priceView}>
              <Text style={styles.totalTxt}>Total</Text>
              <Text style={styles.price}>₹ 599</Text>
            </View>
            <SubmitButton
              customTitleStyle={styles.addToCart}
              customBtnStyle={styles.addToCartTxt}
              title={'Add to Cart'}
            />
          </View>
        </View>
      </Modal>
    </DropShadow>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
  },
  smallView: {justifyContent: 'space-around'},
  modalView: {
    height: Dimensions.get('screen').height - 40,
    width: Dimensions.get('screen').width,
    justifyContent: 'center',
    alignItems: 'center',
    // marginTop: 22,
    backgroundColor: 'white',
    alignSelf: 'center',
    // marginTop: 60,
    // marginHorizontal: 30,
    borderWidth: 2,
    borderColor: 'red',
    margin: 16,
    marginRight: 16,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
  shadow1: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3,
    shadowOffset: {
      height: 2,
      width: 2,
    },
  },
  mainView: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  heightView: {
    height: '90%',
    marginHorizontal: 15,
    marginBottom: 20,
    marginTop: 'auto',
    backgroundColor: '#FFFFFF',
    padding: 10,
    paddingTop: 0,
  },
  crossImage: {
    height: 20,
    width: 20,
    resizeMode: 'contain',
    marginTop: -3,
    tintColor: '#000000',
  },
  crossView: {
    // width: 80,
    width: '28%',
    height: '100%',
    alignItems: 'flex-end',
    paddingRight: 10,
    // borderWidth: 1,
  },
  price: {
    fontSize: 14,
    fontWeight: '800',
    color: '#212121',
  },
  addToCart: {
    color: 'white',
    fontSize: 17,
    fontWeight: 'bold',
  },
  addToCartTxt: {
    marginBottom: 5,
    width: '90%',
    alignSelf: 'center',
    height: 52,
  },
  priceView: {
    flexDirection: 'row',
    width: '88%',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 9,
  },
  totalTxt: {
    fontSize: 17,
    fontWeight: '400',
    color: '#212121',
  },
  heading: {
    // width: '50%',
    textAlign: 'center',
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000000DE',
  },
  secTxt: {
    fontSize: 11,
    fontWeight: '600',
    color: '#00000066',
    marginTop: 3,
  },
  firTxt: {
    fontSize: 14,
    fontWeight: '600',
    color: '#495057',
  },
  bfirTxt: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#000000DE',
    textTransform: 'uppercase',
  },
  bInnerView: {
    marginTop: 69,
    width: '100%',
    alignItems: 'center',
  },
  sCardView: {
    // width: 100,
    width: (Dimensions.get('screen').width - 50) * 0.3,
    height: 50,
    borderWidth: 1.5,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: '#25A140',
    borderRadius: 5,
  },
  bCardView: {
    width: 90,
    height: 142,
    borderWidth: 1.5,
    backgroundColor: 'white',
    alignItems: 'center',
    // justifyContent: 'center',
    borderRadius: 5,
    marginLeft: 15,
  },
  sCardIcon: {
    position: 'absolute',
    top: 0,
    left: '86%',
    marginTop: 2,
  },
  bCardIcon: {
    position: 'absolute',
    top: 0,
    left: '86%',
    marginTop: 2,
    zIndex: 2,
  },
  innerB: {
    width: '100%',
    height: 60,
    // position: 'absolute',
    borderRadius: 5,
  },
  outerB: {
    width: '90%',
    height: 55,
    resizeMode: 'contain',
    position: 'absolute',
    alignSelf: 'center',
  },
  bSecTxt: {
    fontSize: 12,
    fontWeight: '600',
    color: '#000000CC',
  },
  bbSecTxt: {
    fontSize: 12,
    fontWeight: '600',
    color: '#000000CC',
    marginBottom: 5,
    marginTop: 3,
  },
  cheeseIcon: {
    width: '100%',
    height: 59,
    position: 'absolute',
    zIndex: 1,
    borderTopLeftRadius: 5,
    borderTopRightRadius: 5,
  },
  topView: {
    width: '100%',
    marginBottom: 10,
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    // borderWidth: 1,
  },
  pizzaImageView: {
    width: '28%',
  },
  sizeView: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
    paddingBottom: 20,
    // borderWidth: 1,
  },
  addBtn: {
    height: 22,
    paddingHorizontal: 8,
    marginTop: 5,
  },
});

export default ModalView;
