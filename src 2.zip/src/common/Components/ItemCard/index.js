import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import SubmitButton from '../SubmitButton';
import {
  FIRST_BACKDROUND,
  GREEN_CHECK,
  NONVEG,
  RED_CHECK,
  ROUND_CHECKED,
  ROUND_UNCHECKED,
  VEG,
} from '../../Assets/Constants';
import ModalView from '../Modal';
import AddtoCartIcon from '../AddtoCartIcon';
import itemData from './sample.json';
function SizeBtn({size, selectedSize, onPress, isSmallCard}) {
  const styles = Styles(isSmallCard);
  const tintColor = selectedSize ? 'green' : 'gray';
  return (
    <TouchableOpacity onPress={onPress} style={styles.sizeBtn}>
      <Image
        source={selectedSize ? ROUND_CHECKED : ROUND_UNCHECKED}
        style={[styles.sizeBtnImage, {tintColor}]}
      />
      <Text>{size}</Text>
    </TouchableOpacity>
  );
}

function PanType({typeName, selectedPan, onPress, isSmallCard}) {
  const styles = Styles(isSmallCard);
  const borderColor = selectedPan ? '#25A140' : '#00000029';
  const borderWidth = selectedPan ? 1.5 : 1;
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.panBtn, {borderColor, borderWidth}]}>
      <Image
        source={selectedPan ? GREEN_CHECK : RED_CHECK}
        style={styles.panIcon}
      />
      <Text style={styles.panName}>{typeName}</Text>
    </TouchableOpacity>
  );
}
const ItemCard = ({
  item = {},
  imgUrl,
  isVeg,
  itemName,
  price,
  customAdd = () => null,
  isPizza = false,
  customStyle = {},
  firstBackground = FIRST_BACKDROUND,
  isSmallCard = false,
}) => {
  // const [item, setItemData] = useState(itemData);
  const [itemPrice, setItemPrice] = useState(price);
  console.log('itemitemitemitem', item);
  useEffect(() => {
    setSelectedSize(item?.default_size_id);
    let sizesData = [];
    let sizesData_ = item?.size || item?.product_size;
    console.log('sizesData_sizesData_', sizesData_);
    sizesData_?.forEach(i => {
      sizesData.push({
        ...i,
        pans: item?.crust?.filter(i_ => i_.size_id === i.size_id),
      });
    });
    setSizes(sizesData);
    let panData_ = item?.crust || [];
    setPans(panData_?.filter(i_ => i_.size_id === item?.default_size_id));
    setSelectedPan(
      item?.crust?.find(i_ => i_.size_id === item?.default_size_id)
        ?.crust_name || '',
    );
  }, []);

  const styles = Styles(isSmallCard);
  const height = isPizza ? (isSmallCard ? 150 : 285) : isSmallCard ? 120 : 210;
  const [modalVisible, setModalVisible] = useState(false);
  const [sizes, setSizes] = useState([]);
  const [pans, setPans] = useState([]);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedPan, setSelectedPan] = useState('');
  const heightImage = {height: isPizza ? '40%' : '60%'};
  const [cartCount, setCartCount] = useState(0);
  function getItemPrice() {
    let selectedSize_ = sizes?.find(i_ => i_?.size_id === selectedSize);
    let selectedPan_ = selectedSize_?.pans?.find(
      i_ => i_?.crust_name === selectedPan,
    );
    return selectedPan_?.price || selectedSize_?.price || itemPrice;
  }
  return (
    <View style={[styles.cardContainer, {height}, customStyle]}>
      <Image
        source={isVeg ? VEG : NONVEG}
        style={isVeg ? styles.foodType : {...styles.foodType, ...styles.nonVeg}}
      />
      {isPizza && (
        <TouchableOpacity
          onPress={() => setModalVisible(true)}
          style={styles.customizeView}>
          <Text style={styles.customizeTxt}>Customise </Text>
        </TouchableOpacity>
      )}
      <Image
        source={firstBackground}
        style={[styles.firstImage, heightImage]}
      />
      <Image
        style={[styles.image, heightImage]}
        source={{
          uri: imgUrl,
        }}
      />
      <Text style={styles.itemName} ellipsizeMode="tail" numberOfLines={1}>
        {itemName}
      </Text>
      {isPizza && (
        <>
          <Text
            ellipsizeMode="tail"
            numberOfLines={1}
            style={styles.description}>
            {'GREEN CAPSICUM I ONION'}
          </Text>

          <View style={styles.sizeContainer}>
            {sizes?.map((sizeItem, sizeindex) => {
              return (
                <SizeBtn
                  key={sizeindex}
                  isSmallCard={isSmallCard}
                  size={sizeItem?.size_id}
                  selectedSize={sizeItem?.size_id === selectedSize}
                  onPress={() => {
                    setSelectedSize(sizeItem?.size_id);
                    setPans(sizeItem?.pans);
                    let panData = sizeItem?.pans?.find(
                      i_ => i_?.crust_name === selectedPan,
                    );
                    if (!panData) {
                      setSelectedPan(sizeItem?.pans[0]?.crust_name);
                    }
                  }}
                />
              );
            })}
          </View>

          <View style={styles.divider} />
          <View style={styles.panContainer}>
            {pans?.map((panItem, panIndex) => {
              return (
                <PanType
                  key={panIndex}
                  isSmallCard={isSmallCard}
                  typeName={panItem?.crust_name}
                  selectedPan={panItem?.crust_name === selectedPan}
                  onPress={() => setSelectedPan(panItem?.crust_name)}
                />
              );
            })}
          </View>
          <View style={styles.secondDevider} />
        </>
      )}
      <View style={styles.priceContainer}>
        <Text style={styles.price}>₹ {getItemPrice()}</Text>
        {cartCount === 0 ? (
          <SubmitButton
            onPress={() => {
              customAdd();
              setCartCount(cartCount + 1);
            }}
            title={'Add'}
            customBtnStyle={styles.addBtn}
            customTitleStyle={{fontSize: isSmallCard ? 12 : 14}}
          />
        ) : (
          <AddtoCartIcon
            isSmallCard={isSmallCard}
            cartCount={cartCount}
            onDelete={() => setCartCount(0)}
          />
        )}
      </View>
      {modalVisible && (
        <ModalView
          visible={modalVisible}
          onHide={() => setModalVisible(false)}
        />
      )}
    </View>
  );
};

export default ItemCard;
const Styles = isSmallCard =>
  StyleSheet.create({
    cardContainer: {
      height: isSmallCard ? 150 : 210,
      width: isSmallCard ? 120 : '40%',
      borderWidth: 2,
      borderColor: '#CED4DA',
      borderRadius: 6,
      marginLeft: 25,
      backgroundColor: 'white',
      marginBottom: 20,
    },
    foodType: {
      height: isSmallCard ? 10 : 20,
      width: isSmallCard ? 10 : 20,
      position: 'absolute',
      marginLeft: '80%',
      zIndex: 2,
      marginTop: isSmallCard ? 2 : 3,
      resizeMode: 'contain',
      // backgroundColor: 'white',
    },
    nonVeg: {
      height: isSmallCard ? 15 : 25,
      width: isSmallCard ? 15 : 25,
    },
    image: {
      height: '60%',
      width: '100%',
      resizeMode: 'contain',
    },
    itemName: {
      fontWeight: 'bold',
      fontSize: isSmallCard ? 10 : 14,
      textTransform: 'uppercase',
      marginVertical: 10,
      marginLeft: 7,
      color: 'black',
    },
    priceContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginHorizontal: 10,
      marginRight: 12,
      position: 'absolute',
      bottom: isSmallCard ? 4 : 10,
      width: '90%',
      height: isSmallCard ? 20 : 30,
      // borderWidth: 1,
    },
    addBtn: {
      width: isSmallCard ? 30 : 50,
      height: isSmallCard ? 20 : 25,
      borderRadius: 15,
    },
    price: {
      fontSize: isSmallCard ? 10 : 14,
      fontWeight: '600',
      color: 'black',
    },
    description: {
      color: '#808080',
      fontSize: isSmallCard ? 8 : 10,
      marginTop: -8,
      marginLeft: 7,
      marginBottom: 8,
    },
    sizeBtnImage: {
      width: 15,
      height: 15,
      resizeMode: 'contain',
      marginRight: 4,
    },
    sizeBtn: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    panBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 5,
      marginLeft: 5,
      borderRadius: 4,
      padding: 1,
    },
    panIcon: {marginLeft: 3},
    panName: {
      fontSize: 10,
      color: '#495057',
      fontWeight: '700',
      marginLeft: 2,
    },
    customizeView: {
      position: 'absolute',
      width: '55%',
      height: 27,
      backgroundColor: '#FFC107',
      zIndex: 2,
      alignItems: 'center',
      justifyContent: 'center',
    },
    customizeTxt: {fontSize: 12, color: '#495057', fontWeight: '600'},
    firstImage: {
      position: 'absolute',
      width: '100%',
    },
    secondDevider: {
      height: 1,
      width: '92%',
      backgroundColor: '#CED4DA',
      margin: 5,
      alignSelf: 'center',
      marginBottom: 10,
    },
    panContainer: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      justifyContent: 'flex-start',
      paddingLeft: 5,
      height: 44,
    },
    divider: {
      height: 1,
      width: '92%',
      backgroundColor: '#CED4DA',
      marginTop: 5,
      alignSelf: 'center',
    },
    sizeContainer: {
      flexDirection: 'row',
      justifyContent: 'space-evenly',
    },
  });
