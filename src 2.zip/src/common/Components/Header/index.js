import {
  Dimensions,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {CROSS_NAV, HEADER_LOGO, MENU_BUTTON} from '../../Assets/Constants';
import Modal from 'react-native-modal';
import {SafeAreaView, useSafeAreaInsets} from 'react-native-safe-area-context';
import {getValueByKey, logOut} from '../../Utils/localStrorageUtils';
import {ShowToast} from '../../Utils/toastUtils';
import {DrawerActions} from '@react-navigation/native';

function NavItem({onPress, title}) {
  return (
    <TouchableOpacity onPress={onPress} style={styles.navBtn}>
      <Text style={styles.navTxt}>{title}</Text>
    </TouchableOpacity>
  );
}
function NavBar({visible, onHide, navigation}) {
  const [userData, setUserData] = useState(null);
  function getCurrentUser(params) {
    getValueByKey('loggedUserData').then(res => {
      setUserData(res);
    });
  }
  useEffect(() => {
    getCurrentUser();
  }, []);
  const insets = useSafeAreaInsets();
  const marginTop = insets.top;
  function navigateTo(path, params) {
    onHide();
    navigation.navigate(path, params);
  }
  return (
    <Modal
      style={[styles.modalStyle, {marginTop}]}
      isVisible={visible}
      transparent={true}
      swipeDirection="left"
      animationIn={'slideInLeft'}
      animationOut={'slideOutLeft'}
      useNativeDriver={true}
      onSwipeComplete={e => onHide()}>
      <SafeAreaView style={styles.mainView}>
        <View style={styles.mainView}>
          <View style={[styles.heightView]}>
            <TouchableOpacity onPress={onHide} style={styles.crossView}>
              <Image source={CROSS_NAV} style={styles.cross} />
            </TouchableOpacity>
            {userData !== null && (
              <Text style={styles.userTxt}>Hi {userData?.name || ''} ...!</Text>
            )}
            <ScrollView bounces={false}>
              <View
                style={[
                  styles.pinkView,
                  {height: Dimensions.get('screen').height - 30},
                ]}>
                <NavItem
                  title={'Home'}
                  onPress={() => {
                    onHide();
                    navigation.push('Home');
                  }}
                />
                <NavItem title={'About'} onPress={() => navigateTo('About')} />
                <NavItem
                  title={'Order'}
                  onPress={() =>
                    navigateTo('ProfileDashboard', {
                      screen: 'My Order',
                    })
                  }
                />
                <NavItem
                  title={'For Franchise'}
                  onPress={() => navigateTo('Franchise')}
                />
                <NavItem
                  title={'Contact Us'}
                  onPress={() => navigateTo('QuickMsg')}
                />
                <NavItem
                  title={'My Account'}
                  onPress={() =>
                    navigateTo('ProfileDashboard', {screen: 'Dashboard'})
                  }
                />
                {userData === null ? (
                  <NavItem
                    title={'Login'}
                    onPress={() => navigateTo('Login')}
                  />
                ) : (
                  <NavItem
                    title={'Logout'}
                    onPress={() => {
                      logOut();
                      getCurrentUser();
                      onHide();
                      ShowToast({
                        type: 'success',
                        text1: 'Logout SuccessFully',
                      });
                    }}
                  />
                )}
              </View>
            </ScrollView>
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
}
const Header = ({navigation}) => {
  const [navVisible, setNavVisible] = useState(false);
  return (
    <>
      <View style={styles.headerView}>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <Image source={HEADER_LOGO} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            setNavVisible(true);
          }}>
          <Image source={MENU_BUTTON} />
        </TouchableOpacity>
      </View>
      {navVisible && (
        <NavBar
          navigation={navigation}
          visible={navVisible}
          onHide={() => setNavVisible(false)}
        />
      )}
    </>
  );
};

export default Header;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
  },
  headerView: {
    paddingHorizontal: 20,
    backgroundColor: 'black',
    height: 90,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  heightView: {
    height: '100%',
    width: '100%',
  },
  grayView: {
    marginLeft: '70%',
    width: '100%',
    height: '100%',
    backgroundColor: '#495057',
    position: 'absolute',
    zIndex: 1,
    overflow: 'hidden',
    borderLeftWidth: 5,
  },
  pinkView: {
    width: '70%',
    height: '100%',
    backgroundColor: '#FEDA2A',
    paddingTop: '10%',
    paddingLeft: 30,
  },
  cross: {
    width: 50,
    height: 40,
  },
  crossView: {
    position: 'absolute',
    marginLeft: Dimensions.get('screen').width - 70,
    marginTop: 15,
    zIndex: 2,
  },
  modalStyle: {
    margin: 0,
  },
  navTxt: {
    color: '#000000',
    fontSize: 18,
    fontWeight: 'bold',
  },
  navBtn: {
    marginBottom: 20,
    width: '60%',
    height: 30,
  },
  userTxt: {
    width: '70%',
    backgroundColor: '#FEDA2A',
    fontSize: 25,
    color: 'black',
    fontWeight: 'bold',
    padding: 10,
    textTransform: 'capitalize',
  },
});
