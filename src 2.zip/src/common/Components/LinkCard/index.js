import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useState} from 'react';
import {MINUS, PLUS_ICON} from '../../Assets/Constants';

const LinkCard = ({title, subLinks}) => {
  const [showLinks, setShowLinks] = useState(false);
  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => setShowLinks(!showLinks)}
        style={styles.mainBtn}>
        <Text style={styles.titleTxt}>{title}</Text>
        <Image source={showLinks ? MINUS : PLUS_ICON} style={styles.plusIcon} />
      </TouchableOpacity>
      {showLinks && (
        <View style={styles.subLinkContainer}>
          {subLinks?.map((item, index) => {
            return (
              <TouchableOpacity onPress={item.onPress} key={index}>
                <Text style={styles.linkTxt}>{item.linkName}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
      )}

      <View style={styles.divider} />
    </View>
  );
};

export default LinkCard;

const styles = StyleSheet.create({
  mainBtn: {
    flexDirection: 'row',
    marginHorizontal: 12,
    marginVertical: 12,
    justifyContent: 'space-between',
  },
  titleTxt: {
    color: '#FFC107',
    fontSize: 16,
    fontWeight: '700',
  },
  subLinkContainer: {
    marginHorizontal: 12,
  },
  linkTxt: {
    color: 'white',
    marginBottom: 5,
  },
  container: {
    width: '90%',
    alignSelf: 'center',
  },
  divider: {
    height: 1,
    width: '100%',
    marginBottom: 5,
    marginTop: 5,
    backgroundColor: 'white',
  },
  plusIcon: {
    height: 15,
    width: 15,
    resizeMode: 'contain',
    tintColor: '#FFCC00',
  },
});
