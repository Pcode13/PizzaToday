import {Image, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {PERSON} from '../../Assets/Constants';
import DropShadow from 'react-native-drop-shadow';

const ProfileCards = ({customStyle = {}}) => {
  return (
    <DropShadow style={styles.shadow}>
      <View style={[styles.contanier, customStyle]}>
        <Image style={styles.imageview} source={PERSON} />
        <View style={styles.Viewtxt}>
          <Text style={styles.name}>Ashish Singh</Text>
          <Text style={styles.phone}> Mobile : 91 1234567890</Text>
          <Text style={styles.email}> Email : rajesh @gmail.com</Text>
          <Text style={styles.address}>
            Address : Nawjeevan bihar sec 1 waidhan
          </Text>
        </View>
      </View>
    </DropShadow>
  );
};

export default ProfileCards;

const styles = StyleSheet.create({
  contanier: {
    width: '100%',
    backgroundColor: 'white',
    alignSelf: 'center',
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: {
      height: 3,
      width: 3,
    },
  },
  imageview: {
    width: 190,
    height: 190,
    alignSelf: 'center',
    marginVertical: 30,
    borderRadius: 90,
    borderColor: '#707070',
    borderWidth: 1,
  },
  name: {
    textAlign: 'center',
    fontSize: 24,
    color: 'black',
    fontWeight: 'bold',
    // fontFamily: 'Roboto Slab',
    marginBottom: 10,
  },
  phone: {
    textAlign: 'center',
    fontSize: 17,
    color: 'black',
    fontWeight: '700',
    // fontFamily: 'Roboto Slab',
    marginBottom: 5,
  },
  email: {
    textAlign: 'center',
    fontSize: 17,
    color: 'black',
    fontWeight: '700',
    // fontFamily: 'Roboto Slab',
    marginBottom: 5,
  },
  address: {
    textAlign: 'center',
    fontSize: 17,
    color: 'black',
    fontWeight: '700',
    // fontFamily: 'Roboto Slab',
    marginBottom: 5,
  },
  Viewtxt: {
    alignSelf: 'center',
    margin: 10,
  },
});
