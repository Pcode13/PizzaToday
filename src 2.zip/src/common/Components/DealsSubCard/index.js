import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useState} from 'react';
import {
  DELETE_ICON,
  GREEN_CHECK,
  MINUS,
  PLUS_ICON,
} from '../../Assets/Constants';
import ItemCard from '../ItemCard';
import DropShadow from 'react-native-drop-shadow';

const DealsSubCard = ({
  dealItem,
  isIncluded = true,
  onItemAdd,
  onDelete,
  itemList = ['SIMPLY VEG PIZZA', 'DOUBLE CHEESE PIZZA'],
  menuData = [],
}) => {
  console.log('dealItem', dealItem);
  const [showDescription, setShowDescription] = useState(false);
  const [dealItemName, setdealItemName] = useState(dealItem);
  const plusMinusIcon = showDescription ? MINUS : PLUS_ICON;
  const showDeleteIcon = dealItemName !== 'Choose a Option' && !isIncluded;
  const deleteIconStyle = showDeleteIcon ? styles.deleteIcon : null;
  console.log('menuDatamenuData', menuData);
  return (
    <>
      <DropShadow style={styles.shadow}>
        <TouchableOpacity
          disabled={isIncluded}
          onPress={() => setShowDescription(!showDescription)}
          style={styles.mainViewBtn}>
          <Text style={styles.dealName}>{dealItemName}</Text>
          {isIncluded && (
            <View style={styles.includeView}>
              <Image source={GREEN_CHECK} />
              <Text style={styles.includeTxt}>Included</Text>
            </View>
          )}
          {showDeleteIcon && (
            <TouchableOpacity
              onPress={() => {
                if (showDeleteIcon) {
                  setdealItemName('Choose a Option');
                  onDelete();
                }
              }}>
              <Image
                source={showDeleteIcon ? DELETE_ICON : plusMinusIcon}
                style={[styles.plusIcon, deleteIconStyle]}
              />
            </TouchableOpacity>
          )}
          {!showDeleteIcon && !isIncluded && (
            <Image
              source={plusMinusIcon}
              style={[styles.plusIcon, deleteIconStyle]}
            />
          )}
        </TouchableOpacity>
        {showDescription && (
          <View style={styles.cakeContainer}>
            {menuData?.map((item, index) => {
              console.log('item?.product?.image', item?.product?.image);
              return (
                <ItemCard
                  item={item}
                  customAdd={() => {
                    // onItemAdd({itemName: item});
                    // setdealItemName(item);
                    // setShowDescription(false);
                  }}
                  customStyle={styles.itemCard}
                  isPizza={true}
                  key={index}
                  itemName={item?.product?.product_name}
                  imgUrl={item?.product?.image}
                  price={'220'}
                  isVeg={true}
                />
              );
            })}
          </View>
        )}
      </DropShadow>
    </>
  );
};

export default DealsSubCard;

const styles = StyleSheet.create({
  cakeContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    backgroundColor: '#F2F2F2',
    alignSelf: 'center',
    width: '85%',
  },
  mainViewBtn: {
    height: 40,
    width: '85%',
    backgroundColor: 'white',
    // borderWidth: 1,
    alignSelf: 'center',
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  dealName: {
    fontSize: 14,
    fontWeight: '700',
    color: '#495057',
  },
  includeTxt: {
    marginLeft: 4,
    fontSize: 12,
    fontWeight: '700',
    color: '#495057',
  },
  itemCard: {
    width: '46%',
    marginLeft: 10,
    marginTop: 10,
    marginBottom: 10,
  },
  plusIcon: {
    tintColor: '#25A140',
    marginRight: 2,
  },
  shadow: {
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 3,
    shadowOffset: {
      height: 2,
      width: 2,
    },
    marginBottom: 10,
  },
  includeView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  deleteIcon: {
    height: 20,
    width: 15,
    // resizeMode: 'contain',
    // flex: 1,
    tintColor: 'red',
  },
});
