import {Image, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {FIRST_BACKDROUND} from '../../Assets/Constants';
import AddtoCartIcon from '../AddtoCartIcon';

const ProductItem = () => {
  return (
    <View style={styles.productItem}>
      <View style={styles.pizzaImageView}>
        <Image source={FIRST_BACKDROUND} style={styles.innerB} />
        <Image
          source={{
            uri: 'https://pizzatoday.in/public/web/product/ITALIAN_PIZZA.png',
          }}
          style={styles.outerB}
        />
      </View>
      <View style={styles.middleView}>
        <Text style={styles.itemName}>SIMPLY VEG PIZZA</Text>
        <Text style={styles.itemDiscription}>Green Capsicum Onion</Text>
        <Text style={[styles.price, styles.lightPrice]}>₹ 265</Text>
      </View>
      <View style={styles.leftView}>
        <Text style={styles.price}>₹ 265</Text>
        <AddtoCartIcon cartCount={1} onDelete={() => null} />
      </View>
    </View>
  );
};

export default ProductItem;

const styles = StyleSheet.create({
  pizzaImageView: {
    width: '25%',
  },
  productItem: {
    borderWidth: 1,
    width: '90%',
    alignSelf: 'center',
    padding: 10,
    flexDirection: 'row',
    borderColor: '#D4D4D5',
    borderRadius: 4,
    marginBottom: 12,
    backgroundColor: 'white',
  },
  itemName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000000DE',
  },
  itemDiscription: {
    fontSize: 11,
    fontWeight: '700',
    color: '#00000066',
  },
  leftView: {
    width: '26%',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  lightPrice: {
    color: '#ACACAC',
    marginTop: 10,
    fontSize: 13,
  },
  middleView: {
    width: '49%',
    paddingLeft: 8,
  },
  innerB: {
    width: '100%',
    height: 60,
    borderRadius: 5,
  },
  outerB: {
    width: 70,
    height: 55,
    resizeMode: 'contain',
    position: 'absolute',
    alignSelf: 'center',
  },
  price: {
    fontSize: 15,
    fontWeight: '800',
    color: '#000000',
  },
});
