import AsyncStorage from '@react-native-async-storage/async-storage';

export const getValueByKey = async key => {
  try {
    const jsonValue = await AsyncStorage.getItem(key);
    return jsonValue != null ? JSON.parse(jsonValue) : null;
  } catch (e) {
    // error reading value
    return null;
  }
};

export const getRegistredUsers = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem('registred_user');
    return jsonValue != null ? JSON.parse(jsonValue) : null;
  } catch (e) {
    // error reading value
    return null;
  }
};

export const storeRegistredUser = async value => {
  try {
    let newData = [];
    const registredUsers = await getRegistredUsers();
    if (registredUsers !== null) {
      newData = [...registredUsers, value];
    } else {
      newData = [value];
    }
    const jsonValue = JSON.stringify(newData);
    await AsyncStorage.setItem('registred_user', jsonValue);
    return 'success';
  } catch (e) {
    return 'fail';
  }
};

export const setLoggedUserData = async value => {
  try {
    const jsonValue = JSON.stringify(value);
    await AsyncStorage.setItem('loggedUserData', jsonValue);
    return 'success';
  } catch (e) {
    return 'fail';
  }
};

export const getLoggedUserData = () => {
  getValueByKey('loggedUserData').then(res => {
    return res;
  });
};

export const logOut = async () => {
  try {
    await AsyncStorage.removeItem('loggedUserData');
  } catch (e) {
    console.log(e);
  }
};
