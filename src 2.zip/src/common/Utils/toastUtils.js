import Toast from 'react-native-toast-message';

export function ShowToast(params) {
  Toast.show({
    visibilityTime: 4000,
    ...params,
  });
}
